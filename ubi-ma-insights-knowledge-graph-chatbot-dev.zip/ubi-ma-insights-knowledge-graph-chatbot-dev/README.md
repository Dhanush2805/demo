# Knowledge Graph Chatbot 🤖📊

A powerful agentic system for creating knowledge graphs from S3 data and enabling intelligent chat interactions using FastAPI, Neo4j, and multiple LLM providers (AWS Bedrock, Azure OpenAI).

## 🌟 Features

### 📤 Upload Workflow
- **S3 Integration**: Download CSV and Excel files from S3 buckets (supports both public and authenticated access)
- **Local File Upload**: Process CSV and Excel files from local file paths
- **Multipart Upload**: Upload files directly via browser using multipart form data
- **Smart Processing**: Convert Excel to CSV, analyze structure
- **Vector Creation**: Generate embeddings for semantic search
- **LLM-Powered**: Use AWS Bedrock or Azure OpenAI to generate Cypher queries
- **Graph Creation**: Automatically create nodes and relationships in Neo4j

### 💬 Chat Workflow  
- **Vector Search**: Find relevant context from uploaded data
- **Schema-Aware**: Understand current graph structure
- **Query Generation**: Convert natural language to Cypher
- **Smart Answers**: Summarize results into natural language

### 🤖 Agentic Architecture

The system uses autonomous agents that coordinate with each other:

- **Upload Agent**: Orchestrates the entire upload workflow
- **Chat Agent**: Handles question processing and response generation
- **S3 Agent**: Manages file discovery and download from S3
- **Processing Agent**: Handles file conversion and vector creation
- **LLM Agent**: Manages interactions with LLM providers (AWS Bedrock or Azure OpenAI)
- **Neo4j Agent**: Handles all database operations

## 🚀 Quick Start

### Prerequisites

- Python 3.11+
- Docker and Docker Compose
- LLM Provider access (AWS account with Bedrock OR Azure OpenAI subscription)
- Neo4j database (provided via Docker Compose)

### 🐳 Docker Setup (Recommended)

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd knowledge_graph_chatbot
   ```

2. **Set up environment variables**
   ```bash
   cp env_variables_example.txt .env
   # Edit .env with your LLM provider credentials and other configurations
   ```

3. **Start the services**
   ```bash
   docker-compose up -d
   ```

4. **Access the services**
   - API Documentation: http://localhost:8000/docs
   - Neo4j Browser: http://localhost:7474 (neo4j/password123)
   - API Health Check: http://localhost:8000/health

### 🐍 Local Development Setup

1. **Create virtual environment**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Set up environment variables**
   ```bash
   cp env_variables_example.txt .env
   # Edit .env with your configurations
   ```

4. **Start Neo4j** (using Docker)
   ```bash
   docker run -d \
     --name neo4j \
     -p 7474:7474 -p 7687:7687 \
     -e NEO4J_AUTH=neo4j/password123 \
     neo4j:5.15.0
   ```

5. **Run the application**
   ```bash
   python main.py
   ```

## 📚 API Usage

### Upload Data

#### Option 1: S3 Files
```bash
curl -X POST "http://localhost:8000/api/v1/upload/s3-knowledge-graph" \
  -H "Content-Type: application/json" \
  -d '{
    "bucket_name": "your-bucket",
    "object_key": "path/to/your/file.csv"
  }'
```

#### Option 2: Local Files
```bash
curl -X POST "http://localhost:8000/api/v1/upload/local-knowledge-graph" \
  -H "Content-Type: application/json" \
  -d '{
    "file_path": "/path/to/your/file.csv"
  }'
```

#### Option 3: Multipart Upload
```bash
curl -X POST "http://localhost:8000/api/v1/upload/multipart-knowledge-graph" \
  -F "file=@your-file.csv"
```

### Chat with Your Data

```bash
curl -X POST "http://localhost:8000/api/v1/chat/query" \
  -H "Content-Type: application/json" \
  -d '{
    "question": "What insights can you provide about the data?"
  }'
```

## 🏗️ Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   FastAPI App   │────│   Upload Agent  │────│   S3 Agent      │
│                 │    │                 │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         │                       ▼                       ▼
         │              ┌─────────────────┐    ┌─────────────────┐
         │              │ Processing Agent│────│   LLM Agent     │
         │              │                 │    │                 │
         │              └─────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Chat Agent    │────│   Neo4j Agent   │────│     Neo4j DB    │
│                 │    │                 │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │
         ▼                       ▼
┌─────────────────┐    ┌─────────────────┐
│  Vector Service │    │   FAISS Index   │
│                 │    │                 │
└─────────────────┘    └─────────────────┘
```

## 🔧 Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| **General Configuration** | | |
| `NEO4J_URI` | Neo4j connection URI | `bolt://localhost:7687` |
| `NEO4J_USER` | Neo4j username | `neo4j` |
| `NEO4J_PASSWORD` | Neo4j password | `00000000` |
| `VECTOR_DB_FOLDER` | Vector database storage path | `./vector_db` |
| `VECTOR_MODEL_NAME` | Sentence transformer model | `all-MiniLM-L6-v2` |
| `TEMP_FOLDER` | Temporary files storage | `./temp_files` |
| **LLM Configuration** | | |
| `LLM_PROVIDER` | LLM provider to use | `bedrock` |
| `LLM_MAX_TOKENS` | Maximum tokens for LLM responses | `4000` |
| `LLM_TEMPERATURE` | LLM temperature setting | `0.1` |
| **AWS Bedrock (when LLM_PROVIDER=bedrock)** | | |
| `BEDROCK_MODEL_ID` | AWS Bedrock model identifier | `us.anthropic.claude-sonnet-4-20250514-v1:0` |
| `BEDROCK_REGION` | AWS Bedrock region | `us-west-2` |
| **Azure OpenAI (when LLM_PROVIDER=azure_openai)** | | |
| `AZURE_OPENAI_ENDPOINT` | Azure OpenAI endpoint URL | `` |
| `AZURE_OPENAI_API_KEY` | Azure OpenAI API key | `` |
| `AZURE_OPENAI_MODEL_NAME` | Azure OpenAI model name | `gpt-4` |
| `AZURE_OPENAI_API_VERSION` | Azure OpenAI API version | `2024-02-01` |

### LLM Provider Configuration

#### AWS Bedrock Setup
Set up AWS credentials either through:
- Environment variables (`AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`)
- AWS CLI configuration (`aws configure`)
- IAM roles (recommended for production)

#### Azure OpenAI Setup
1. Set `LLM_PROVIDER=azure_openai` in your environment
2. Configure Azure OpenAI variables:
   ```bash
   AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
   AZURE_OPENAI_API_KEY=your-api-key-here
   AZURE_OPENAI_MODEL_NAME=gpt-4
   ```
3. Install OpenAI dependency: `pip install openai==1.3.7`

## 📁 Project Structure

```
knowledge_graph_chatbot/
├── app/
│   ├── agents/           # Autonomous agents
│   ├── core/            # Core utilities and models
│   ├── router/          # API route handlers
│   ├── services/        # Business logic services
│   └── utils/           # Utility functions
├── logs/                # Application logs
├── temp_files/          # Temporary file storage
├── vector_db/           # Vector database storage
├── docker-compose.yml   # Docker orchestration
├── Dockerfile          # Container configuration
├── main.py             # Application entry point
├── requirements.txt    # Python dependencies
└── README.md           # This file
```

## 🔍 API Endpoints

### Upload Endpoints
- `POST /api/v1/upload/s3-knowledge-graph` - Upload from S3
- `POST /api/v1/upload/local-knowledge-graph` - Upload local files
- `POST /api/v1/upload/multipart-knowledge-graph` - Multipart upload

### Chat Endpoints
- `POST /api/v1/chat/query` - Query the knowledge graph

### Dashboard Endpoints
- `GET /api/insights` - Get insights for publications and projects
- `GET /api/publications` - Get publications with filters
- `GET /api/projects` - Get projects by IDs
- `GET /api/kols` - Get Key Opinion Leaders by year and therapeutic area
- `GET /api/kol` - Get individual KOL details
- `GET /api/search` - **NEW** Unified search across authors, publications, and projects

### Health Endpoints
- `GET /health` - Application health check
- `GET /` - API information

## 🔍 Unified Search API

### Overview
The unified search API provides intelligent search across NIH authors, publications, and projects with exact and partial text matching.

### Quick Start

```bash
# Search for authors
curl "http://localhost:8000/api/search?type=author&text=smith"

# Search for publications
curl "http://localhost:8000/api/search?type=publication&text=cancer"

# Search for projects
curl "http://localhost:8000/api/search?type=project&text=diabetes"
```

### Features

- **Two-tier Matching Strategy**:
  1. Exact match on IDs (highest priority)
  2. Partial text match (case-insensitive using ILIKE)

- **Intelligent Sorting**: Results sorted by match type and relevance
- **Top 10 Results**: Returns most relevant matches
- **Compatible Format**: Returns same format as existing APIs (KOLResponse, PublicationResponse, ProjectResponse)
- **Auto-Insights**: Generates insights for publications/projects if not cached

### Examples

```bash
# Exact ID match
curl "http://localhost:8000/api/search?type=author&text=R123456"

# Partial text match
curl "http://localhost:8000/api/search?type=publication&text=cancer"

# Search in author names
curl "http://localhost:8000/api/search?type=author&text=smith"
```

## 🧪 Testing

```bash
# Install test dependencies
pip install pytest pytest-asyncio httpx

# Run tests
pytest
```

## 🐛 Troubleshooting

### Common Issues

1. **Neo4j Connection Failed**
   - Ensure Neo4j is running
   - Check credentials in environment variables
   - Verify network connectivity

2. **AWS Bedrock Access Denied**
   - Verify AWS credentials
   - Check IAM permissions for Bedrock
   - Ensure model is available in your region

3. **File Upload Issues**
   - Check file size limits
   - Verify file format (CSV/Excel)
   - Ensure temp directories exist

### Logs

Check application logs in the `logs/` directory for detailed error information.

Made with ❤️ for intelligent data exploration and knowledge graph creation.

## 🧩 Chunk-wise Processing

### Overview
The system now supports **chunk-wise Cypher query generation and execution** for improved accuracy and incremental knowledge graph building.

### Key Benefits
- **Improved Accuracy**: Process data in smaller, manageable chunks
- **Incremental Updates**: Uses MERGE statements to update existing nodes/relationships
- **Configurable Performance**: Adjustable chunk size (1-1000 rows, default: 10)
- **Better Error Handling**: Failed chunks don't affect the entire upload
- **Schema Awareness**: Each chunk considers existing graph structure

### New API Endpoints

#### Local File Upload (Chunked)
```bash
POST /api/v1/upload/local-knowledge-graph-chunked
```

**Request Body:**
```json
{
  "file_paths": ["/path/to/your/data.csv"],
  "chunk_size": 10,
  "create_vectors": false
}
```

#### S3 File Upload (Chunked)
```bash
POST /api/v1/upload/s3-knowledge-graph-chunked
```

**Request Body:**
```json
{
  "s3_url": "https://your-bucket.s3.amazonaws.com/folder/",
  "aws_access_key_id": "your_key",
  "aws_secret_access_key": "your_secret",
  "chunk_size": 10,
  "region_name": "us-west-2"
}
```

### How It Works

1. **File Processing**: Converts Excel/CSV files to standardized CSV format
2. **Chunk Creation**: Splits CSV data into configurable chunks (default: 10 rows)
3. **Schema Awareness**: Fetches current Neo4j schema before each chunk
4. **Query Generation**: LLM generates MERGE-based Cypher queries for each chunk
5. **Incremental Execution**: Executes queries chunk by chunk, updating the graph incrementally
6. **Context Updates**: Updates schema context between chunks for accurate relationships

### Parameters

- **chunk_size**: Number of rows per chunk (1-1000, default: 10)
  - Smaller chunks: More accurate, slower processing
  - Larger chunks: Faster processing, potentially less accurate
- **create_vectors**: Whether to create vector embeddings for semantic search

### Example Workflow

```python
# For a 100-row CSV with chunk_size=10:
# 1. Creates 10 chunks of 10 rows each
# 2. Processes chunk 1 → updates schema → processes chunk 2 → etc.
# 3. Each chunk uses MERGE to avoid duplicates
# 4. Final result: Complete knowledge graph with all relationships
```

### Use Cases

- **Large Datasets**: Break down large CSV files into manageable pieces
- **Incremental Updates**: Add new data to existing knowledge graphs
- **Data Quality**: Better handling of complex relationships and edge cases
- **Performance Tuning**: Adjust chunk size based on data complexity and system resources
