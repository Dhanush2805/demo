import requests
from app.services.config_service import config
from app.agents.postgresql_agent import postgresql_agent, init_db_connection
import json
from app.core.logger import get_logger

logger = get_logger('data_bricks_agent')

class DatabricksAgent:
    def __init__(self, base_url: str, token: str, default_job: str):
        self.base_url = base_url
        self.token = token
        self.default_job = default_job
        self.headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }

    def update_token(self, new_token: str):
        """Update Databricks personal access token."""
        self.token = new_token
        self.headers["Authorization"] = f"Bearer {new_token}"

    def get(self, endpoint: str, params: dict = None):
        """Send a GET request to Databricks."""
        try:
            url = f"{self.base_url}{endpoint}"
            response = requests.get(url, headers=self.headers, params=params)
            return response
        except Exception as e:
            logger.error(f" Unexpected Databricks error: {str(e)}")
            raise e

    def post(self, endpoint: str, body: dict = None):
        """Send a POST request to Databricks."""
        try:
            url = f"{self.base_url}{endpoint}"
            response = requests.post(url, headers=self.headers, json=body)
            return response
        except Exception as e:
           logger.error(f" Unexpected Databricks error: {str(e)}")
           raise e

    def get_notebook_params(self, ingestion_id: str) -> dict:
        """
        Fetch pipeline details for a given ingestion_id and
        return only the 'notebook_params' dictionary.
        """
        try:
            if not postgresql_agent.connection_pool:
                init_db_connection()

            query = f"""
                SELECT 
                    json_build_object(
                        'source_type', source,
                        'source_details', source_details,
                        'target_type', target,
                        'target_details', target_details,
                        'mapping_list', mapping_data
                    ) AS json_config
                FROM "{postgresql_agent.schema}".data_ingestion_pipelines
                WHERE id = %(id)s;
            """

            params = {"id": ingestion_id}
            result = postgresql_agent.execute_query(query, params)

            if not result.data:
                raise ValueError(f"No ingestion pipeline found for id: {ingestion_id}")

            json_config = result.data[0]["json_config"]

            if isinstance(json_config.get("mapping_list"), dict) and "mapping_list" in json_config["mapping_list"]:
                json_config["mapping_list"] = json_config["mapping_list"]["mapping_list"]

            notebook_params = {
                "json_config": json.dumps(json_config)
            }

            logger.info(f"notebook_params built successfully for ingestion_id={ingestion_id}")
            return notebook_params

        except Exception as e:
            logger.exception("Failed to build notebook_params")
            raise e

databricks = DatabricksAgent(
    base_url=config.databricks.base_url,
    token=config.databricks.token,
    default_job= config.databricks.default_job
)