import posixpath
import boto3
from io import BytesIO, StringIO
from dotenv import load_dotenv
from collections import defaultdict
from app.services.config_service import config, AWSConfig
import uuid
import pandas as pd
from app.core.logger import get_logger

load_dotenv()
MAX_FILES_LIMIT = 5000

logger = get_logger('s3_agent')
class S3Agent:
    def __init__(self):
        """Initialize AWS credentials and region."""

        creds = config.get_aws_credentials_from_env() or {}

        s3_config = AWSConfig(
            aws_access_key_id=creds.get("AWS_ACCESS_KEY_ID", "AKIAQLVQQO4CNIA4ALG3"),
            aws_secret_access_key=creds.get("AWS_SECRET_ACCESS_KEY", "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"),
            region_name=creds.get("AWS_DEFAULT_REGION", "ap-south-1"),
        )

        self.aws_access_key_id = s3_config.aws_access_key_id
        self.aws_secret_access_key = s3_config.aws_secret_access_key
        self.region_name = s3_config.region_name
        self.s3_client = self.connect()

    def connect(self):
        """Establish a connection to AWS S3."""
        try:
            return boto3.client(
                "s3",
                aws_access_key_id=self.aws_access_key_id,
                aws_secret_access_key=self.aws_secret_access_key,
                region_name=self.region_name,
            )

        except Exception as e:
           logger.error(f" Unexpected AWS S3 connection error: {str(e)}")
           raise e 
        
    def get_s3_file_columns(self, bucket_name, file_path):

        try:  
            obj = self.s3_client.get_object(Bucket=bucket_name, Key=file_path)
            body = obj["Body"].read()

            if file_path.lower().endswith(".csv"):
                df = pd.read_csv(StringIO(body.decode("utf-8")))
            elif file_path.lower().endswith(".xlsx") or file_path.lower().endswith(".xls"):
                df = pd.read_excel(BytesIO(body), engine="openpyxl")
            elif file_path.lower().endswith(".parquet"):
                df = pd.read_parquet(BytesIO(body), engine="pyarrow")
            else:
                raise ValueError(f"Unsupported file type: {file_path}")
            
            return [{ "id": str(uuid.uuid4()), "name": obj} for obj in list(df.columns)] 
        
        except Exception as e:
            logger.error(f" Unexpected error while reading file columns from S3: {str(e)}")
            raise e

    def get_all_buckets(self):
        """List all S3 buckets."""
        try:
            response = self.s3_client.list_buckets()
            buckets = response.get("Buckets", [])

            bucket_list = []

            for b in buckets:
                if isinstance(b, dict) and "Name" in b:
                    bucket_list.append({
                        "id": str(uuid.uuid4()),
                        "name": b["Name"]
                    })

            return bucket_list
        
        except Exception as e:
           logger.error(f"Unexpected error occurred while listing S3 buckets: {str(e)}")
           raise e

    def get_bucket_objects(self, bucket_name: str,prefix=""):
        """
        List all objects in a specific S3 bucket.
        Returns list of object metadata dicts, not just keys.
        """
        try:

            paginator = self.s3_client.get_paginator("list_objects_v2")
            page_iterator = paginator.paginate(Bucket=bucket_name, Prefix=prefix)

            files = []
            i = 0
            for page in page_iterator:
                contents = page.get("Contents", [])
                for obj in contents:
                    i+=1
                    key = obj["Key"]

                    if key.endswith("/"):
                        continue

                    files.append({
                        "key": key,
                        "etag": obj.get("ETag", "").strip('"')
                    })

            return files

        except Exception as e:
           logger.error(f"Unexpected error occurred while listing objects in S3 bucket: {str(e)}")
           raise e  

    def build_tree_with_metadata(self, objects):
        """
        Build a hierarchical tree structure from S3 object metadata list.
        Each node contains: key (ETag), name, objectType, children.
        """
        try:
            node_map = {}
            roots = []

            for obj in objects:
                key = obj.get("key")

                parts = key.split("/")
                is_file = not key.endswith("/")
                etag = obj.get("etag")

                for i in range(len(parts)):
                    path = "/".join(parts[: i + 1])
                    name = parts[i]
                    parent_path = "/".join(parts[:i]) if i > 0 else None

                    if path not in node_map:
                        node_map[path] = {
                            "id": etag.strip('"') if is_file and i == len(parts) - 1 and etag else path,
                            "name": name,
                            "path": path,
                            "objectType": "file" if is_file and i == len(parts) - 1 else "folder",
                            "children": []
                        }

                        if parent_path and parent_path in node_map:
                            node_map[parent_path]["children"].append(node_map[path])
                        elif not parent_path:
                            roots.append(node_map[path])
            return roots
            
        except Exception as e:
           logger.error(f"Unexpected error occurred while listing objects tree in S3 bucket: {str(e)}")
           raise e
        
s3_agent = S3Agent()