import os
import shutil
from typing import List, Dict, Any, Optional
from pathlib import Path
from app.core.logger import get_logger

logger = get_logger('local_file_agent')

class LocalFileAgent:
    """
    Local File Agent - Handles local file operations
    Similar to S3Agent but for local filesystem operations
    """
    
    def __init__(self):
        """Initialize local file agent"""
        logger.info("Initializing Local File Agent")
        self.temp_dir = "temp_files"
        self.supported_extensions = {'.csv', '.xlsx', '.xls'}
        self._ensure_temp_directory()
        logger.info("Local File Agent initialized successfully")
    
    def _ensure_temp_directory(self):
        """Ensure temp directory exists"""
        os.makedirs(self.temp_dir, exist_ok=True)
        os.makedirs(os.path.join(self.temp_dir, "csvs"), exist_ok=True)
    
    def validate_file_paths(self, file_paths: List[str]) -> Dict[str, Any]:
        """
        Validate that all file paths exist and are supported file types
        
        Args:
            file_paths: List of file paths to validate
            
        Returns:
            Dictionary with validation results
        """
        logger.info(f"Validating {len(file_paths)} file paths")
        
        validation_results = {
            'valid': True,
            'files_found': [],
            'files_missing': [],
            'files_unsupported': [],
            'total_files': len(file_paths),
            'errors': []
        }
        
        for file_path in file_paths:
            try:
                # Convert to Path object for easier handling
                path = Path(file_path)
                
                # Check if file exists
                if not path.exists():
                    validation_results['files_missing'].append(str(path))
                    validation_results['errors'].append(f"File not found: {file_path}")
                    continue
                
                # Check if it's a file (not directory)
                if not path.is_file():
                    validation_results['files_unsupported'].append(str(path))
                    validation_results['errors'].append(f"Path is not a file: {file_path}")
                    continue
                
                # Check file extension
                if path.suffix.lower() not in self.supported_extensions:
                    validation_results['files_unsupported'].append(str(path))
                    validation_results['errors'].append(f"Unsupported file type: {file_path} (supported: {', '.join(self.supported_extensions)})")
                    continue
                
                # File is valid
                validation_results['files_found'].append({
                    'path': str(path),
                    'name': path.name,
                    'size': path.stat().st_size,
                    'extension': path.suffix.lower()
                })
                
            except Exception as e:
                validation_results['files_missing'].append(file_path)
                validation_results['errors'].append(f"Error accessing file {file_path}: {str(e)}")
        
        # Update validation status
        if validation_results['files_missing'] or validation_results['files_unsupported']:
            validation_results['valid'] = False
        
        logger.info(f"Validation completed: {len(validation_results['files_found'])} valid files, "
                   f"{len(validation_results['files_missing'])} missing, "
                   f"{len(validation_results['files_unsupported'])} unsupported")
        
        return validation_results
    
    def copy_files_to_temp(self, file_paths: List[str]) -> List[str]:
        """
        Copy local files to temp directory for processing
        
        Args:
            file_paths: List of file paths to copy
            
        Returns:
            List of copied file paths in temp directory
        """
        logger.info(f"Copying {len(file_paths)} files to temp directory")
        
        copied_files = []
        
        for file_path in file_paths:
            try:
                source_path = Path(file_path)
                
                # Skip if file doesn't exist or is not supported
                if not source_path.exists() or source_path.suffix.lower() not in self.supported_extensions:
                    logger.warning(f"Skipping file: {file_path}")
                    continue
                
                # Create destination path in temp directory
                dest_path = Path(self.temp_dir) / source_path.name
                
                # Handle duplicate filenames
                counter = 1
                original_dest = dest_path
                while dest_path.exists():
                    name = original_dest.stem
                    suffix = original_dest.suffix
                    dest_path = original_dest.parent / f"{name}_{counter}{suffix}"
                    counter += 1
                
                # Copy file
                shutil.copy2(source_path, dest_path)
                copied_files.append(str(dest_path))
                
                logger.info(f"Copied {source_path.name} to {dest_path}")
                
            except Exception as e:
                logger.error(f"Error copying file {file_path}: {str(e)}")
                continue
        
        logger.info(f"Successfully copied {len(copied_files)} files to temp directory")
        return copied_files
    
    def process_uploaded_files(self, uploaded_files: List[bytes], filenames: List[str]) -> List[str]:
        """
        Process uploaded files from multipart form data
        
        Args:
            uploaded_files: List of file contents as bytes
            filenames: List of original filenames
            
        Returns:
            List of saved file paths
        """
        logger.info(f"Processing {len(uploaded_files)} uploaded files")
        
        saved_files = []
        
        for file_content, filename in zip(uploaded_files, filenames):
            try:
                # Validate file extension
                file_path = Path(filename)
                if file_path.suffix.lower() not in self.supported_extensions:
                    logger.warning(f"Skipping unsupported file: {filename}")
                    continue
                
                # Create destination path in temp directory
                dest_path = Path(self.temp_dir) / filename
                
                # Handle duplicate filenames
                counter = 1
                original_dest = dest_path
                while dest_path.exists():
                    name = original_dest.stem
                    suffix = original_dest.suffix
                    dest_path = original_dest.parent / f"{name}_{counter}{suffix}"
                    counter += 1
                
                # Save file
                with open(dest_path, 'wb') as f:
                    f.write(file_content)
                
                saved_files.append(str(dest_path))
                logger.info(f"Saved uploaded file: {dest_path}")
                
            except Exception as e:
                logger.error(f"Error saving uploaded file {filename}: {str(e)}")
                continue
        
        logger.info(f"Successfully saved {len(saved_files)} uploaded files")
        return saved_files
    
    def cleanup_temp_files(self, file_paths: List[str]):
        """
        Clean up temporary files
        
        Args:
            file_paths: List of file paths to delete
        """
        logger.info(f"Cleaning up {len(file_paths)} temporary files")
        
        for file_path in file_paths:
            try:
                if os.path.exists(file_path):
                    os.remove(file_path)
                    logger.debug(f"Deleted temporary file: {file_path}")
            except Exception as e:
                logger.warning(f"Error deleting temporary file {file_path}: {str(e)}")
        
        logger.info("Temporary file cleanup completed")
    
    def get_file_info(self, file_paths: List[str]) -> List[Dict[str, Any]]:
        """
        Get information about files
        
        Args:
            file_paths: List of file paths
            
        Returns:
            List of file information dictionaries
        """
        logger.info(f"Getting info for {len(file_paths)} files")
        
        file_info_list = []
        
        for file_path in file_paths:
            try:
                path = Path(file_path)
                if path.exists() and path.is_file():
                    file_info = {
                        'path': str(path),
                        'name': path.name,
                        'size': path.stat().st_size,
                        'extension': path.suffix.lower(),
                        'modified_time': path.stat().st_mtime
                    }
                    file_info_list.append(file_info)
            except Exception as e:
                logger.error(f"Error getting info for file {file_path}: {str(e)}")
        
        return file_info_list 