import json
import boto3
import re
from typing import List, Dict, Any, Optional, Tuple
from app.core.logger import get_logger
from app.core.models import FileInfo, VectorSearchResult
from app.services.config_service import config
from app.services.metrics_service import MetricsService
import time

# Import Azure OpenAI - with fallback handling
try:
    from openai import AzureOpenAI
    AZURE_AVAILABLE = True
except ImportError:
    AZURE_AVAILABLE = False

logger = get_logger('llm_agent')

class LLMAgent:
    """
    Modular LLM Agent supporting both AWS Bedrock and Azure OpenAI
    Provider is selected based on configuration
    """
    
    def __init__(self, aws_credentials: Optional[Dict[str, str]] = None):
        """
        Initialize LLM agent with provider-specific configuration
        
        Args:
            aws_credentials: Dictionary containing AWS credentials (required for Bedrock)
        """
        logger.info("Initializing Modular LLM Agent")
        
        self.max_retries = 3
        self.provider = config.llm.provider.lower()
        self.last_token_input = 0
        self.last_token_output = 0
        
        # Initialize based on provider
        if self.provider == "azure_openai":
            self._initialize_azure_openai()
        elif self.provider == "bedrock":
            self._initialize_bedrock(aws_credentials)
        else:
            raise ValueError(f"Unsupported LLM provider: {self.provider}")
        
        logger.info(f"LLM Agent initialized with provider: {self.provider}")
    
    def _initialize_azure_openai(self):
        """Initialize Azure OpenAI client"""
        if not AZURE_AVAILABLE:
            raise ImportError("Azure OpenAI package not installed. Install with: pip install openai")
        
        if not config.llm.azure_endpoint or not config.llm.azure_api_key:
            raise ValueError("Azure OpenAI endpoint and API key must be configured")
        
        try:
            self.azure_client = AzureOpenAI(
                azure_endpoint=config.llm.azure_endpoint,
                api_key=config.llm.azure_api_key,
                api_version=config.llm.azure_api_version
            )
            self.model_name = config.llm.azure_model_name
            logger.info(f"Azure OpenAI client initialized with model: {self.model_name}")
            
        except Exception as e:
            error_msg = f"Failed to initialize Azure OpenAI client: {str(e)}"
            logger.error(error_msg)
            raise ValueError(error_msg)
    
    def _initialize_bedrock(self, aws_credentials: Optional[Dict[str, str]]):
        """Initialize AWS Bedrock client"""
        if not aws_credentials:
            raise ValueError("AWS credentials required for Bedrock provider")
        
        self.aws_credentials = aws_credentials
        self.model_id = config.llm.bedrock_model_id
        
        try:
            session = boto3.Session(
                aws_access_key_id=aws_credentials.get('aws_access_key_id'),
                aws_secret_access_key=aws_credentials.get('aws_secret_access_key'),
                aws_session_token=aws_credentials.get('aws_session_token'),
                region_name=aws_credentials.get('region_name', config.llm.bedrock_region)
            )
            
            self.bedrock_client = session.client(
                service_name='bedrock-runtime',
                region_name=aws_credentials.get('region_name', config.llm.bedrock_region)
            )
            
            logger.info(f"Bedrock client initialized with model: {self.model_id}")
            
        except Exception as e:
            error_msg = f"Failed to initialize Bedrock client: {str(e)}"
            logger.error(error_msg)
            raise ValueError(error_msg)
    
    def generate_cypher_queries(self, files_info: List[FileInfo]) -> List[str]:
        """
        Generate LOAD CSV Cypher queries with error handling and retries
        Uses the exact prompt from the notebook CypherGenerationAgent
        """
        logger.info(f"Generating LOAD CSV queries for {len(files_info)} files")
        
        # Prepare files summary for prompt
        files_summary = []
        for file_info in files_info:
            files_summary.append({
                "filename": file_info.filename,
                "file_path": file_info.file_path,  # Include file path (local or URL)
                "columns": file_info.columns,
                "row_count": file_info.row_count,
                "sample_data": file_info.sample_data  # All sample data
            })
        
        prompt = self._build_cypher_generation_prompt(files_summary)
        # Retry logic for query generation
        for attempt in range(self.max_retries):
            logger.info(f"Cypher generation attempt {attempt + 1}/{self.max_retries}")
            
            response = self._generate_llm_response(prompt)
            if response:
                queries = self.extract_queries_from_llm_response(response)
                if queries:
                    logger.info(f"Successfully generated {len(queries)} valid Cypher queries")
                    return queries
                else:
                    logger.warning(f"Generated queries failed validation on attempt {attempt + 1}")
            else:
                logger.warning(f"No response from LLM on attempt {attempt + 1}")
        
        logger.error("Failed to generate valid Cypher queries after all retries")
        return []
    def _build_cypher_generation_prompt(self, files_summary: List[Dict]) -> str:
        """
        Build the exact prompt from notebook CypherGenerationAgent._build_prompt()
  
        """

        return f"""
You are a Neo4j 5.x expert and your task is to generate **valid Cypher queries** to import data from one or more CSV files into a graph database.

## GOAL:
Convert CSV files into a Neo4j knowledge graph by:
- Creating meaningful nodes and relationships
- Handling duplicate and null values properly
- Ensuring schema flexibility so new files or columns can be mapped without error

---

## CSV INPUT:
You will be given one or more CSV file samples — including **column headers** and a few **sample rows**.

---

##  Your Task:
Do not use any APOC procedures or functions — only use built-in Cypher functions.
1. **Parse the column headers** and infer logical groupings:
   - For example, group HCP-related fields into a `:HealthcareProfessional` node
   - Group project-related fields into `:NIH_Project`
   - Group interactions into `:Interaction`, PIs into `:PrincipalInvestigator`, and so on

2. **Detect Relationships**:
   - Use shared or semantically linked fields (like `therapeutic_area`, `HCP_ID`, `PI_Name`) to infer relationships
   - Examples:
     - `(:HCP)-[:ENGAGED_IN]->(:Interaction)`
     - `(:Interaction)-[:COVERS]->(:TherapeuticArea)`
     - `(:HCP)-[:ASSOCIATED_WITH]->(:NIH_Project)` via shared therapeutic_area
     - `(:NIH_Project)-[:LEAD_BY]->(:PI)`
     - `(:NIH_Project)-[:FUNDED_AT]->(:Organization)`
     - `(:SalesRep)-[:INTERACTED_WITH]->(:HCP)`

3. **Normalize Fields**:
   - Convert commonly repeating string values (e.g., `therapeutic_area`, `SalesRep`, `CITY`) into separate nodes
   - Create relationships like `(:Interaction)-[:BELONGS_TO]->(:City)`, etc.

4. **Generate Cypher Queries**:
   - Each query must:
    - Start with: `LOAD CSV WITH HEADERS FROM '$file_path' AS row
                    WITH row
                    WHERE NOT row.`PMID` IN $idsToSkip AND NOT toInteger(trim(row.`PMID`)) IS NULL
                    CALL {{
                    WITH row
                    MERGE (n: `Publication` {{ `pmid`: toInteger(trim(row.`PMID`)) }})
                    SET n.`pmid` = toInteger(trim(row.`PMID`))
                    SET n.`title` = row.`TITLE`
                    }} IN TRANSACTIONS OF 2000 ROWS;`
     - Follow with: `WITH row`  
     - Then: `WHERE row.some_key IS NOT NULL`  
     - Then: `MERGE` or `CREATE` statements to create nodes and relationships
   - Use `MERGE` instead of `CREATE` to prevent duplicates
   - Avoid syntax issues like:
     - `LOAD CSV` or `MATCH` without anything after it
     - `WHERE` without a preceding `WITH row`
     - Using undefined variables
   - No `RETURN` statements needed


5.  Date/Time Handling:
   - For date fields, use simple string format validation in WHERE clauses
   - Use `date(row.date_field)` only if the field is already in YYYY-MM-DD format
   - For date comparisons, use: `WHERE row.date_field >= "2023-01-01"`
   - Example: `WHERE row.interaction_date IS NOT NULL AND row.interaction_date >= "2023-01-01"`
   - CRITICAL: NEVER use APOC functions or complex date conversions
   - Do not use any APOC procedures or functions — only use built-in Cypher functions
   - Avoid epoch/timestamp conversions that can cause parsing errors
6. **DO NOT** return any explanation or comment.



---
##  Common Errors to Avoid:     
- `Query cannot conclude with LOAD CSV`
- `Invalid input 'WHERE'` due to missing `WITH`
- `Variable not defined` like `project`, `hcp`, `interaction`
- Broken `UNWIND` or undefined identifiers
- Do not use any APOC procedures or functions — only use built-in Cypher functions.
---
FILES TO PROCESS:
{json.dumps(files_summary, indent=2, default=str)}

## Output Format:

Return the output as a JSON object matching this structure: 
{{
  items: [
    {{
      filename: string,
      queries: string[]
    }}
  ]
}}

Only return raw JSON, no markdown formatting, no explanations, no comments.raph.
"""




    def generate_cypher_queries_with_schema(self, files_info: List[FileInfo], current_schema: Dict[str, Any]) -> List[str]:
        """
        NEW: Generate Cypher queries with existing database schema context
        This method creates queries that can relate new data to existing nodes and relationships
        """
        logger.info(f"Generating Cypher queries for {len(files_info)} files with schema context")
        
        # Prepare files summary for prompt
        files_summary = []
        for file_info in files_info:
            files_summary.append({
                "filename": file_info.filename,
                "file_path": file_info.file_path,  # Include file path (local or URL)
                "columns": file_info.columns,
                "row_count": file_info.row_count,
                "sample_data": file_info.sample_data  # All sample data
            })
        
        # Build prompt with schema context
        prompt = self._build_cypher_generation_prompt_with_schema(files_summary, current_schema)
        # Generate queries with retries
        for attempt in range(self.max_retries):
            logger.info(f"Schema-aware query generation attempt {attempt + 1}/{self.max_retries}")
            
            response = self._generate_llm_response(prompt)
            if response:
                queries = self.extract_queries_from_llm_response(response)
                if queries:
                    logger.info(f"Successfully generated {len(queries)} valid schema-aware Cypher queries")
                    return queries
                else:
                    logger.warning(f"Generated queries failed validation on attempt {attempt + 1}")
            else:
                logger.warning(f"No response from LLM on attempt {attempt + 1}")
        
        logger.error("Failed to generate valid schema-aware Cypher queries after all retries")
        return []
    
   
    def _build_cypher_generation_prompt_with_schema(self, files_summary: List[Dict], current_schema: Dict[str, Any]) -> str:
        """
        NEW: Build prompt with existing database schema context for creating relations
        """

        return f"""
You are a Neo4j 5.x expert and your task is to generate **valid Cypher queries** to import data from one or more CSV files into a graph database.

## 🎯 GOAL:
Convert CSV files into a Neo4j knowledge graph by:
- Creating meaningful nodes and relationships
- Handling duplicate and null values properly
- Ensuring schema flexibility so new files or columns can be mapped without error

---

##  CSV INPUT:
You will be given one or more CSV file samples — including **column headers** and a few **sample rows**.


---
##  Your Task:
Do not use any APOC procedures or functions — only use built-in Cypher functions.
1. **Parse the column headers** and infer logical groupings:
   - For example, group HCP-related fields into a `:HealthcareProfessional` node
   - Group project-related fields into `:NIH_Project`
   - Group interactions into `:Interaction`, PIs into `:PrincipalInvestigator`, and so on

2. **Detect Relationships**:
   - Use shared or semantically linked fields (like `therapeutic_area`, `HCP_ID`, `PI_Name`) to infer relationships
   - Examples:
     - `(:HCP)-[:ENGAGED_IN]->(:Interaction)`
     - `(:Interaction)-[:COVERS]->(:TherapeuticArea)`
     - `(:HCP)-[:ASSOCIATED_WITH]->(:NIH_Project)` via shared therapeutic_area
     - `(:NIH_Project)-[:LEAD_BY]->(:PI)`
     - `(:NIH_Project)-[:FUNDED_AT]->(:Organization)`
     - `(:SalesRep)-[:INTERACTED_WITH]->(:HCP)`

3. **Normalize Fields**:
   - Convert commonly repeating string values (e.g., `therapeutic_area`, `SalesRep`, `CITY`) into separate nodes
   - Create relationships like `(:Interaction)-[:BELONGS_TO]->(:City)`, etc.

4. **Generate Cypher Queries**:
   - Each query must:
    - Start with: `LOAD CSV WITH HEADERS FROM '$file_path' AS row
                    WITH row
                    WHERE NOT row.`PMID` IN $idsToSkip AND NOT toInteger(trim(row.`PMID`)) IS NULL
                    CALL {{
                    WITH row
                    MERGE (n: `Publication` {{ `pmid`: toInteger(trim(row.`PMID`)) }})
                    SET n.`pmid` = toInteger(trim(row.`PMID`))
                    SET n.`title` = row.`TITLE`
                    }} IN TRANSACTIONS OF 10000 ROWS;`
    - Follow with: `WITH row`  
    - Then: `WHERE row.some_key IS NOT NULL`  
    - call statement to create nodes and relationships
     - Then: `MERGE` or `CREATE` statements to create nodes and relationships
   - Use `MERGE` instead of `CREATE` to prevent duplicates
   - Avoid syntax issues like:
     - `LOAD CSV` or `MATCH` without anything after it
     - `WHERE` without a preceding `WITH row`
     - Using undefined variables
   - No `RETURN` statements needed

5. Date/Time Handling:
   - For date fields, use simple string format validation in WHERE clauses
   - Use `date(row.date_field)` only if the field is already in YYYY-MM-DD format
   - For date comparisons, use: `WHERE row.date_field >= "2023-01-01"`
   - Example: `WHERE row.interaction_date IS NOT NULL AND row.interaction_date >= "2023-01-01"`
   - CRITICAL: NEVER use APOC functions or complex date conversions
   - Do not use any APOC procedures or functions — only use built-in Cypher functions
   - Avoid epoch/timestamp conversions that can cause parsing errors
6. **DO NOT** return any explanation or comment.



---

## Common Errors to Avoid:
- `Query cannot conclude with LOAD CSV`
- `Invalid input 'WHERE'` due to missing `WITH`
- `Variable not defined` like `project`, `hcp`, `interaction`
- Broken `UNWIND` or undefined identifiers
- Do not use any APOC procedures or functions — only use built-in Cypher functions.
---
FILES TO PROCESS:
{json.dumps(files_summary, indent=2, default=str)}
---
Existing Schema:
{current_schema}

## Output Format:

Return the output as a JSON object matching this structure: 
{{
  items: [
    {{
      filename: string,
      queries: string[]
    }}
  ]
}}

Only return raw JSON, no markdown formatting, no explanations, no comments.raph.
"""


    def generate_chat_query(self, question: str, vector_context: List[VectorSearchResult], 
                          schema_info: Dict[str, Any]) -> List[str]:
        """
        Generate Cypher query for chat questions using context and schema
        """
        logger.info(f"Generating chat query for question: '{question}'")
        
        prompt = self._build_chat_query_prompt(question, vector_context, schema_info)
        
        # Generate query with retries
        for attempt in range(self.max_retries):
            logger.info(f"Chat query generation attempt {attempt + 1}/{self.max_retries}")
            
            response = self._generate_llm_response(prompt)
            logger.info(f"Response: {response}, {type(response)}")
            if response:
                queries = self.extract_queries_from_llm_response(response)
                if queries:
                    logger.info(f"Successfully generated chat query: {queries[0]}...")
                    return queries
                else:
                    logger.warning(f"Generated query failed validation on attempt {attempt + 1}")
        
        logger.error("Failed to generate valid chat query after all retries")
        return ""
    def _build_chat_query_prompt(self, question: str,context: str, schema: str) -> str:
        return f"""
    You are a Neo4j Cypher query generation expert.

    ---

    ## Task

    Generate executable Cypher queries (Neo4j v5.x compatible) based ONLY on Question provided by user and keep the below things in mind:
    
    - The **graph schema** (Cypher-style label and relationship description)
    - The **natural language question**
    - Generate multiple queries if needed to answer the question.
    - try all possible queries to get answer and generate multiple queries.
    - Always keep query limit to 5 rows if not specified by user.

    ## STRICT Cypher Rules

    - Start every query with `MATCH` or `OPTIONAL MATCH`
    - Every variable in `RETURN` must be declared earlier
    - Use correct relationship direction as defined
    - NEVER invent labels or relationships not in the schema
    - Do NOT use deprecated syntax or APOC functions
    - Use WHERE for any filtering logic
    - Use aliases if necessary, e.g., `i.name AS interactionName`
    - In Cypher, exists(variable.property) is no longer supported. Please use variable.property IS NOT NULL instead for property existence checks.
    ---

    ## Graph Schema Format

    All nodes and relationships are defined in this format:
    `(:Label {{prop1, prop2}})-[:REL_TYPE]->(:OtherLabel {{propX}})`

    Schema:
    {schema}

    ## Question:
    "{question}"

    ---

    ## Output Format (JSON only):

    {{
    "items": [
        {{
        "filename": "generated.cypher",
        "queries": [
            "<Your Cypher query here>"
            "<Your Cypher query here>"...
        ]
        }}
    ]
    }}

    Return raw JSON only. Do not include markdown or explanations.
    """
    def check_answer_accuracy(self, question: str,answer: str, query_results: List[Dict], schema: Dict[str, Any]):
        """
        Check if the answer is accurate based on the query results
        """
        prompt = f"""
You are a highly skilled analyst. Your task is to evaluate the accuracy of a provided answer based on the corresponding query results.

Carefully read the following inputs:

Question: {question}

Provided Answer: {answer}


Instructions:
1. Consider the accuracy of facts, completeness, and relevance to the question.
2. Ignore grammatical issues or writing style — focus only on factual correctness.
3. If the answer is completely correct and aligns perfectly with the query results, return 100%.
4. If partially correct, assign an appropriate lower percentage and briefly explain why (optional).
5. If completely incorrect or not grounded in the query/schema, assign a very low accuracy (e.g., < 20%).

Return your output strictly in the following JSON format:

{{
  "accuracy": <integer percentage from 0 to 100>
}}
""" 
        response = self._generate_llm_response(prompt)
        if response:
            logger.info("Successfully checked answer accuracy")
            try:
                import json
                data = json.loads(response)
                accuracy = float(data.get("accuracy", 0.0))
            except Exception as e:
                logger.error(f"Failed to parse accuracy from LLM response: {e}")
                accuracy = 0.0
            return accuracy
        else:
            logger.error("Failed to check answer accuracy")
            return 0.0


    def summarize_chat_response(self, question: str, query_results: List[Dict],
                               original_query: str, vector_context: List[VectorSearchResult], schema:  Dict[str, Any] ) -> Tuple[str, List[str], List[str]]:
        """
        Summarize query results into natural language response
        """
        logger.info(f"Summarizing chat response for {len(query_results)} results")
        

        
        prompt = f"""
Answer the user's question using **only** the provided Cypher query results. Do **not** infer beyond the data or include unrelated results. 
Exclude any content that is not relevant to the user's question.

---

## Context:
This response is intended for **medical affairs** communication. Maintain a **professional**, **objective**, and **evidence-based** tone.
Ensure alignment with **scientific accuracy**, **compliance**, and **clarity**.  
Avoid any technical references to data retrieval, systems, or processes.
---

## User Question:
{question}

## Cypher Query Used:
{original_query}

## Cypher Query Results:
{query_results}

## Database Schema (Nodes and Relationships):
{schema}

---

### Response Construction Guidelines:

1. **Apply Data Privacy Masking (First Step)**  
   - **Phone Numbers:** show first 4 digits only (e.g., 9876xxxxxx).  
   - **Email Addresses:** show first 2 characters, mask rest + partial domain (e.g., jo********@****.com).  
   - **Birthdates:** mask all but first two digits of the year and partial month/day (e.g., 19******** or 20********).  
   - Ensure no unmasked personal identifiers remain.

2. **Apply Formatting Rules**  
   - Use **Markdown** for structure and readability.  
   - Headers (`##`, `###`) for sections.  
   - **Bold** for key terms and values.  
   - Use **bullets or numbers** for clarity.  
   - Avoid code formatting or escape characters.  
   - Maintain consistent structure:
     - Summary  
     - Detailed Findings  
     - Actionable Insights  
     - Reference (if applicable) in answer section.

3. **Provide a concise, neutral summary**  
   - Briefly state what was found or inferred from the data in an analytical, professional tone.  
   - Avoid references to backend systems or data sources.

4. **Provide a structured, point-wise answer**  
   - Summarize the **key medical or scientific findings** relevant to the question.  
   - Highlight **therapeutic focus**, **clinical relevance**, or **expert insights** clearly and objectively.  
   - Keep the tone **neutral, factual, and evidence-based**.

5. **Include an "Actionable Insights" section**  
   - If action terms appear (e.g., *recommend, update, monitor, engage, follow-up*), list them as **bullet points**.  
   - If none, state **No actionable insights.**

6. **Publications and References (Do Not Include Links in Answer)**  
   - Detect any **PubMed IDs** (e.g., `PMID: 12345678`, `PubMed:12345678`, or 8-digit patterns).  
   - Do **not** insert links inside the text.  
   - For each PubMed ID, prepare:  
     `https://pubmed.ncbi.nlm.nih.gov/<PUBMED_ID>/`  
   - For NIH projects, prepare:  
     `https://reporter.nih.gov/project-details/<PROJECT_ID>/`  



---

### Expected Response Format:
{{
  "answer": "string (well-structured Markdown-formatted summary of findings, with actionable insights, masked data, and Reference section with node labels and relationships used)",
  "publications_links": [
    "https://pubmed.ncbi.nlm.nih.gov/<PUBMED_ID>/",
    "https://pubmed.ncbi.nlm.nih.gov/<PUBMED_ID>/"
  ],
  "project_links": [
    "https://project-id.nih.gov/",
    "https://project-id.nih.gov/"
  ]
}}
"""

        response = self._generate_llm_response(prompt)
        if response:
            logger.info("Successfully summarized chat response")
            try:
                import json
                data = json.loads(response)
                answer = data.get("answer", "")
                publications_links = data.get("publications_links", [])
                project_links = data.get("project_links", [])
                return answer, publications_links, project_links
            except Exception as e:
                logger.error(f"Failed to parse response: {e}")
                return (
                    "I found some results but couldn't summarize them properly. Please try rephrasing your question.",
                    [],
                    []
                )
        else:
            logger.error("Failed to generate response summary")
            return (
                "I found some results but couldn't summarize them properly. Please try rephrasing your question.",
                [],
                []
            )
    
    def generate_sql_from_nlq(self, question: str, schema_info: Dict[str, Any], max_results: int = 100) -> str:
        """
        Generate SQL query from natural language question using PostgreSQL schema
        
        Args:
            question: Natural language question
            schema_info: Dictionary containing table schemas
            max_results: Maximum number of results to return
            
        Returns:
            Generated SQL query string
        """
        logger.info(f"Generating SQL query from NLQ: '{question}'")
        
        prompt = self._build_sql_query_prompt(question, schema_info, max_results)
        
        # Generate query with retries
        for attempt in range(self.max_retries):
            logger.info(f"SQL query generation attempt {attempt + 1}/{self.max_retries}")
            
            response = self._generate_llm_response(prompt)
            if response:
                try:
                    # Extract SQL query from response
                    import json
                    data = json.loads(response)
                    sql_query = data.get("sql_query", "").strip()
                    
                    if sql_query:
                        logger.info(f"Successfully generated SQL query: {sql_query[:100]}...")
                        return sql_query
                    else:
                        logger.warning(f"Empty SQL query generated on attempt {attempt + 1}")
                except Exception as e:
                    logger.warning(f"Failed to parse SQL response on attempt {attempt + 1}: {e}")
            else:
                logger.warning(f"No response from LLM on attempt {attempt + 1}")
        
        logger.error("Failed to generate valid SQL query after all retries")
        return ""
    
    def _build_sql_query_prompt(self, question: str, schema_info: Dict[str, Any], max_results: int) -> str:
        """Build prompt for SQL query generation"""
        
        # Format schema information
        schema_text = ""
        for table_name, table_info in schema_info.items():
            # Handle both old format (list) and new format (dict with metadata)
            if isinstance(table_info, dict) and 'columns' in table_info:
                # New format with comments and metadata
                table_comment = table_info.get('table_comment', '')
                columns = table_info.get('columns', [])
                row_count = table_info.get('row_count', 0)
                
                schema_text += f"\nTable: {table_name}"
                if table_comment:
                    schema_text += f" -- {table_comment}"
                schema_text += f" ({row_count} rows)\n"
                
                for column in columns:
                    if isinstance(column, dict):
                        col_name = column.get('name', '')
                        col_type = column.get('dataType', '')
                        nullable = column.get('isNullable', True)
                        col_comment = column.get('comment', '')
                        null_text = "NULL" if nullable else "NOT NULL"
                        
                        schema_text += f"  - {col_name}: {col_type} ({null_text})"
                        if col_comment:
                            schema_text += f" -- {col_comment}"
                        schema_text += "\n"
            elif isinstance(table_info, list):
                # Old format (backward compatibility)
                schema_text += f"\nTable: {table_name}\n"
                for column in table_info:
                    if isinstance(column, dict):
                        col_name = column.get('name', '')
                        col_type = column.get('dataType', '')
                        nullable = column.get('isNullable', True)
                        col_comment = column.get('comment', '')
                        null_text = "NULL" if nullable else "NOT NULL"
                        
                        schema_text += f"  - {col_name}: {col_type} ({null_text})"
                        if col_comment:
                            schema_text += f" -- {col_comment}"
                        schema_text += "\n"
            schema_text += "\n"
        
        return f"""
You are a PostgreSQL SQL query generation expert.

## Task

Generate executable PostgreSQL SQL queries based on the natural language question and database schema provided.

## Rules

1. Generate ONLY valid PostgreSQL SQL syntax
2. Use proper table and column names from the schema
3. Always include a LIMIT clause (max {max_results} rows)
4. Use appropriate WHERE clauses for filtering
5. Use JOINs when querying multiple tables
6. Handle NULL values appropriately
7. Use proper data type casting when needed
8. Return results in a logical order (ORDER BY)

## Database Schema

Available tables and columns (use JOINs only when tables have clear relationships):
{schema_text}

## Question

"{question}"

## Output Format

Return your response as JSON in this exact format:

{{
  "sql_query": "SELECT ... FROM table_name WHERE ... ORDER BY ... LIMIT {max_results}",
  "explanation": "Brief explanation of what the query does"
}}

Return raw JSON only. Do not include markdown formatting, code blocks, or explanations outside the JSON.
"""
    
    def _generate_llm_response(self, prompt: str) -> str:
        """Generate response from configured LLM provider"""
        try:
            if self.provider == "azure_openai":
                return self._generate_azure_response(prompt)
            elif self.provider == "bedrock":
                return self._generate_bedrock_response(prompt)
            else:
                raise ValueError(f"Unsupported provider: {self.provider}")
                
        except Exception as e:
            error_msg = f"LLM generation failed: {str(e)}"
            logger.error(error_msg, exc_info=True)
            raise RuntimeError(error_msg) from e
    
    def _generate_azure_response(self, prompt: str) -> str:
        """Generate response from Azure OpenAI with improved error handling and output formatting"""
        start_time = time.time()
        logger.info("Sending request to Azure OpenAI")
        logger.info(f"Using model: {self.model_name}")
        logger.info(f"Endpoint: {config.llm.azure_endpoint}")
        logger.info(f"API Version: {config.llm.azure_api_version}")
        
        try:
            # Create the chat completion request similar to the test script
            response = self.azure_client.chat.completions.create(
                model=self.model_name,
                messages=[
                    {"role": "system", "content": "You are a helpful assistant specialized in generating Neo4j Cypher queries and analyzing graph data."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=config.llm.max_tokens,
                temperature=config.llm.temperature,
                top_p=1,
            )
            
            # Extract and validate response
            if response.choices and len(response.choices) > 0:
                response_text = response.choices[0].message.content
                if response_text:
                    logger.info(f"✅ Successfully received Azure OpenAI response (length: {len(response_text)} characters)")
                    logger.info(f"Response preview: {response_text[:200]}...")
                    
                    # Log response statistics
                    self._log_response_statistics(response)
                    
                    # Store token usage
                    if hasattr(response, 'usage') and response.usage:
                        self.last_token_input = getattr(response.usage, 'prompt_tokens', 0)
                        self.last_token_output = getattr(response.usage, 'completion_tokens', 0)
                    else:
                        self.last_token_input = 0
                        self.last_token_output = 0
                    # Update metrics for every LLM call
                    MetricsService.update_metrics(
                        accuracy=None,
                        response_time=time.time() - start_time,
                        token_input=self.last_token_input,
                        token_output=self.last_token_output
                    )
                    return response_text
                else:
                    raise ValueError("Empty response content from Azure OpenAI")
            else:
                raise ValueError("No choices returned from Azure OpenAI")
            
        except Exception as e:
            error_msg = f"❌ Azure OpenAI request failed: {str(e)}"
            logger.error(error_msg)
            logger.error(f"Model: {self.model_name}")
            logger.error(f"Endpoint: {config.llm.azure_endpoint}")
            logger.error(f"Prompt length: {len(prompt)} characters")
            
            # Log additional context for debugging
            if hasattr(e, 'response'):
                logger.error(f"HTTP Status: {getattr(e.response, 'status_code', 'Unknown')}")
                logger.error(f"Response content: {getattr(e.response, 'text', 'No response content')}")
            
            raise RuntimeError(error_msg) from e
    
    def _log_response_statistics(self, response):
        """Log detailed statistics about the Azure OpenAI response"""
        try:
            if hasattr(response, 'usage') and response.usage:
                logger.info(f"📊 Token usage - Prompt: {response.usage.prompt_tokens}, "
                           f"Completion: {response.usage.completion_tokens}, "
                           f"Total: {response.usage.total_tokens}")
            
            if hasattr(response, 'model') and response.model:
                logger.info(f"🤖 Model used: {response.model}")
                
            if hasattr(response, 'created') and response.created:
                logger.info(f"⏱️ Response created at: {response.created}")
                
        except Exception as e:
            logger.warning(f"Could not log response statistics: {str(e)}")
    

    
    def _generate_bedrock_response(self, prompt: str) -> str:
        """Generate response from AWS Bedrock"""
        start_time = time.time()
        logger.info("Sending request to AWS Bedrock")
        
        try:
            body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": config.llm.max_tokens,
                "temperature": config.llm.temperature,
                "messages": [{"role": "user", "content": prompt}]
            }
            
            response = self.bedrock_client.invoke_model(
                modelId=self.model_id,
                body=json.dumps(body)
            )
            
            result = json.loads(response['body'].read())
            response_text = result['content'][0]['text']
            
            logger.info(f"Received Bedrock response (length: {len(response_text)})")
            # Bedrock does not provide token usage in this implementation
            self.last_token_input = 0
            self.last_token_output = 0
            MetricsService.update_metrics(
                accuracy=None,
                response_time=time.time() - start_time,
                token_input=self.last_token_input,
                token_output=self.last_token_output
            )
            return response_text
            
        except Exception as e:
            error_msg = f"Bedrock request failed: {str(e)}"
            logger.error(error_msg)
            raise RuntimeError(error_msg) from e
    



    
    def extract_queries_from_llm_response(self, llm_response: str):
        """
        Takes a JSON string from an LLM response and extracts all Cypher queries into a flat list.
        """
        logger.info(f"Extracting queries from LLM response (type: {type(llm_response)})")
        logger.info(f"Response preview: {str(llm_response)[:200]}...")
        
        # Step 1: Parse JSON string to dictionary
        try:
            parsed_data = json.loads(llm_response)
            logger.info(f"Parsed data type: {type(parsed_data)}")
            logger.info(f"Parsed data keys: {parsed_data.keys() if isinstance(parsed_data, dict) else 'Not a dict'}")
        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error: {str(e)}")
            logger.error(f"Raw response: {llm_response}")
            raise ValueError(f"Invalid JSON string. Fix formatting. Error: {str(e)}") from e

        # Step 2: Extract queries
        all_queries = []
        
        try:
            items = parsed_data.get("items", [])
            logger.info(f"Found {len(items)} items in parsed data")
            
            for i, item in enumerate(items):
                logger.info(f"Processing item {i}: {type(item)}")
                if isinstance(item, dict):
                    queries = item.get("queries", [])
                    logger.info(f"Item {i} has {len(queries)} queries")
                    for j, query in enumerate(queries):
                        logger.info(f"Query {j} type: {type(query)}")
                        if isinstance(query, str):
                            all_queries.append(query)
                        else:
                            logger.warning(f"Query {j} is not a string: {type(query)} - {query}")
                else:
                    logger.warning(f"Item {i} is not a dict: {type(item)} - {item}")
                    
        except Exception as e:
            logger.error(f"Error extracting queries: {str(e)}")
            logger.error(f"Parsed data: {parsed_data}")
            raise e
        
        logger.info(f"Extracted {len(all_queries)} total queries")
        return all_queries
 


    def generate_chunked_cypher_queries(self, file_info: FileInfo, chunk_data: List[Dict[str, Any]], 
                                      chunk_number: int, total_chunks: int, 
                                      existing_schema: Optional[Dict[str, Any]] = None) -> List[str]:
        """
        Generate Cypher queries for a specific chunk of CSV data
        Uses MERGE statements for incremental updates to existing knowledge graph
        
        Args:
            file_info: Information about the CSV file (columns, filename, etc.)
            chunk_data: List of dictionaries representing rows in this chunk
            chunk_number: Current chunk number (1-based)
            total_chunks: Total number of chunks
            existing_schema: Existing Neo4j schema to build upon
            
        Returns:
            List of Cypher queries for this chunk
        """
        logger.info(f"Generating Cypher queries for chunk {chunk_number}/{total_chunks} "
                   f"of {file_info.filename} ({len(chunk_data)} rows)")

        # Build prompt for chunk-specific query generation
        prompt = self._build_chunked_cypher_prompt(file_info, chunk_data, chunk_number, 
                                                 total_chunks, existing_schema)

        # Generate queries with retries
        for attempt in range(self.max_retries):
            logger.info(f"Chunk {chunk_number} query generation attempt {attempt + 1}/{self.max_retries}")
            response = self._generate_llm_response(prompt)
            if response:
                queries = self.extract_queries_from_llm_response(response)
                if queries:
                    logger.info(f"Successfully generated {len(queries)} Cypher queries for chunk {chunk_number}")
                    return queries
                else:
                    logger.warning(f"Generated queries failed validation for chunk {chunk_number}, attempt {attempt + 1}")
            else:
                logger.warning(f"No response from LLM for chunk {chunk_number}, attempt {attempt + 1}")
        
        logger.error(f"Failed to generate valid Cypher queries for chunk {chunk_number} after all retries")
        return []

    def _build_chunked_cypher_prompt(self, file_info: FileInfo, chunk_data: List[Dict[str, Any]], 
                                   chunk_number: int, total_chunks: int, 
                                   existing_schema: Optional[Dict[str, Any]] = None) -> str:
        """
        Build prompt for generating Cypher queries for a specific chunk of data
        Emphasizes MERGE usage for incremental updates
        """

        return f"""
You are a Cypher expert (Neo4j 5.x). Your task is to generate Cypher statements for **incrementally updating** a knowledge graph from a CSV file.

---

## 🧠 OBJECTIVE:
For each row in this chunk:
- Use **MERGE** to insert or update nodes and relationships.
- Organize fields into **logical entities** (nodes) and connect them with **semantically meaningful relationships**.
- Normalize repeating fields into nodes (e.g., cities, roles, reps, areas).
- Detect relationships using shared fields and context.

---

## 🔍 FIELD GROUPING SUGGESTIONS:
- Group fields like `HCP_ID`, `HCP_Name` → `:HealthcareProfessional`
- Fields like `project_id`, `project_title` → `:NIH_Project`
- `PI_Name`, `PI_ID` → `:PrincipalInvestigator`
- `therapeutic_area` → `:TherapeuticArea`
- `Interaction_ID`, `Date`, `Outcome` → `:Interaction`
- `SalesRep`, `City`, etc. → separate dimension nodes

---

## 🔗 RELATIONSHIP PATTERNS (EXAMPLES):
- `(:HCP)-[:ENGAGED_IN]->(:Interaction)`
- `(:Interaction)-[:COVERS]->(:TherapeuticArea)`
- `(:NIH_Project)-[:LEAD_BY]->(:PrincipalInvestigator)`
- `(:HCP)-[:ASSOCIATED_WITH]->(:NIH_Project)`
- `(:NIH_Project)-[:FUNDED_AT]->(:Organization)`
- `(:SalesRep)-[:INTERACTED_WITH]->(:HCP)`
- `(:Interaction)-[:LOCATED_IN]->(:City)`

---

## ❗ RULES:
1. Only use **built-in Cypher**, no APOC.
2. Each row must generate a valid Cypher query using `MERGE`.
3. Avoid common Cypher mistakes:
   - Undefined variables
   - Improper use of `WITH`
   - Incomplete `UNWIND`
   - `LOAD CSV` syntax (not allowed)
4. Use **consistent variable naming** for readability.



---

## CHUNK DETAILS:
- File: **{file_info.filename}**
- Chunk: **{chunk_number} of {total_chunks}**
- Rows: **{len(chunk_data)}**
- Columns: {file_info.columns}
- rows: {json.dumps(chunk_data, indent=2, default=str)}

{existing_schema}

---

## 🚀 OUTPUT FORMAT:

Return a raw JSON object:

```json
{{
  "items": [
    {{
      "filename": "{file_info.filename}",
      "queries": [
        "...Cypher query for row 1...",
        "...Cypher query for row 2...",
        "...etc..."
      ]
    }}
  ]
}}
DO NOT include any Markdown, explanations, or comments — return raw JSON only.


"""
    
    def generate_text_insights(self, text: str) -> Dict[str, Any]:
        """
        Generate meaningful insights from text using LLM with graph visualization
        
        Args:
            text: Text content to analyze
            
        Returns:
            Dictionary with consolidated insights, key insights, and graph data
        """
        logger.info(f"Generating text insights for {len(text)} characters")
        
        # Build analysis prompt
        prompt = self._build_text_insights_prompt(text)
        
        # Generate insights with retries
        for attempt in range(self.max_retries):
            logger.info(f"Text insights generation attempt {attempt + 1}/{self.max_retries}")
            
            response = self._generate_llm_response(prompt)
            if response:
                # Parse the JSON response
                insights_data = self._parse_text_insights_response(response)
                if insights_data:
                    logger.info("Successfully generated text insights with graph analysis")
                    return insights_data
                else:
                    logger.warning(f"Failed to parse insights response on attempt {attempt + 1}")
            else:
                logger.warning(f"No response from LLM on attempt {attempt + 1}")
        
        logger.error("Failed to generate text insights after all retries")
        return {
            "consolidated_insights": "Unable to generate insights from the provided text.",
            "is_graph": False,
            "html_code": ""
        }
    
    def _build_text_insights_prompt(self, text: str) -> str:
        """Build enhanced prompt for insights extraction with graph visualization"""
        
        return f"""
You are an expert in **text analytics and data visualization**.  
Your job is to:
1. Extract meaningful insights from the input text  
2. Detect any references to PubMed IDs and link insights to their publications  
3. Determine if the text contains data suitable for visualization, and if yes, generate a complete ApexCharts HTML visualization  
Do **not** use phrases like “The text summarizes findings from...” or “According to the text.”  

Return the result strictly in the JSON schema below.  

---

## INPUT TEXT:
```
{text}
```

## PHASE 1: TEXT ANALYSIS
1. Read and summarize the main meaning of the text in 3–5 sentences. 
2. Identify all key data, numbers, temporal patterns, categories, and relationships.  
3. Extract **PubMed IDs** (formatted like `PMID: 12345678`, `PubMed:12345678`, or any 8-digit PubMed pattern).  
4. For each detected PubMed ID, create a corresponding URL:
   `https://pubmed.ncbi.nlm.nih.gov/<PUBMED_ID>/`
5. Where possible, indicate which key insight or finding came from which publication.

---

## PHASE 2: GRAPH LOGIC & GENERATION (Merged)
Create a graph **only if** the text includes data such as:
- **Quantitative values** (numbers, counts, percentages)
- **Temporal patterns** (dates, trends, or sequences)
- **Categorical comparisons** (groups, categories)
- **Relationships or distributions** (correlations, proportions)

If such data exists:
1. Choose the correct chart type:
   - **Bar Chart** → category or count comparisons  
   - **Line Chart** → temporal trends  
   - **Pie Chart** → proportions or shares  
   - **Scatter Plot** → relationships or correlations  
   - **Timeline** → chronological events  
2. Build a **self-contained ApexCharts HTML** visualization.
3. If **no visualizable data**, output an empty string in `"html_code"`.


## OUTPUT FORMAT (JSON):

```json
{{
  "consolidated_insights": "
  ##  Consolidated Insights:
A short paragraph summarizing the text.

###  Key Insights:
  - First key takeaway  
  - Second major point  
  - Third valuable observation  
  - Fourth data-driven insight  
  - Fifth important implication
  ,
  "publications_links": [
    "https://pubmed.ncbi.nlm.nih.gov/publication_id/",
    "https://pubmed.ncbi.nlm.nih.gov/publication_id/"
  ],
  "graph": {{
    "html_code": "Complete self-contained HTML with Chart.js (empty string if no meaningful graph possible)"
  }}
}}
```

## HTML TEMPLATE EXAMPLE:
For graphs, use this Chart.js template structure:
```html
<!DOCTYPE html>
<html>
<head>
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<style>
        body {{
            font-family: Arial, sans-serif;
            padding: 20px;
        }}
        .chart-container {{
            width: 800px;
            height: 400px;
            margin: 0 auto;
        }}
</style>
</head>
<body>
<div class="chart-container">
<div id="myChart"></div>
</div>
 
    <script>
        var options = {{
            chart: {{
                type: 'bar',
                height: 400
            }},
            series: [{{
                name: 'Dataset Label',
                data: [12, 19, 3]
            }}],
            xaxis: {{
                categories: ['Label1', 'Label2', 'Label3']
            }},
            title: {{
                text: 'Chart Title',
                align: 'center'
            }},
            plotOptions: {{
                bar: {{
                  borderRadius: 4,
                  endingShape: "rounded"
                }}
            }},
            colors: ['#FF6384', '#36A2EB', '#FFCE56']
        }};
 
        var chart = new ApexCharts(document.querySelector("#myChart"), options);
        chart.render();
</script>
</body>
</html>
```

## GUIDELINES:
- **Consolidated insights**: 3-5 sentences covering main themes + Key insights 3-8 bullet points, clear and actionable in markdown format   `
- **Graph meaningful**: Only true if clear quantitative/temporal patterns exist
- **HTML code**: Complete, self-contained, ready to render
- **Data extraction**: Parse actual numbers, dates, categories from text
- **No speculation**: Only visualize data explicitly mentioned in text

Return ONLY the JSON object, no additional text or markdown formatting.
"""
    
    def _parse_text_insights_response(self, response: str) -> Dict[str, Any]:
        """Parse and validate the enhanced text insights response with graph data"""
        try:
            # Clean response - remove any markdown or extra text
            cleaned_response = response.strip()
            
            # Find JSON content
            json_start = cleaned_response.find('{')
            json_end = cleaned_response.rfind('}') + 1
            
            if json_start == -1 or json_end == 0:
                logger.error("No JSON object found in response")
                return {}
            
            json_content = cleaned_response[json_start:json_end]
            
            # Parse JSON
            insights = json.loads(json_content)
            
            # Validate structure
            if not isinstance(insights, dict):
                logger.error("Response is not a dictionary")
                return {}
            
            # Ensure all expected fields are present with defaults
            validated_insights = {
                'consolidated_insights': insights.get('consolidated_insights', ''),
                'publications_links': insights.get('publications_links', []),
                'graph': {
                    'html_code': insights.get('graph', {}).get('html_code', '')
                }
            }
            # Validate graph data if meaningful
            if validated_insights['graph']['html_code']:
                logger.info("Graph meaningful: True")
            else:
                logger.warning("Graph marked as meaningless")
                        
            return validated_insights
            
        except json.JSONDecodeError as e:
            logger.error(f"JSON parsing error: {e}")
            logger.error(f"Response content: {response[:500]}...")
            return {}
        except Exception as e:
            logger.error(f"Error parsing insights response: {e}")
            return {}
    
    def analyze_text_basic_stats(self, text: str) -> Dict[str, int]:
        """Calculate basic text statistics"""
        import re
        
        # Word count
        words = re.findall(r'\b\w+\b', text.lower())
        word_count = len(words)
        
        # Sentence count (approximation)
        sentences = re.split(r'[.!?]+', text)
        sentence_count = len([s for s in sentences if s.strip()])
        
        # Paragraph count
        paragraphs = text.split('\n\n')
        paragraph_count = len([p for p in paragraphs if p.strip()])
        
        return {
            'word_count': word_count,
            'sentence_count': sentence_count,
            'paragraph_count': paragraph_count
        }


    def check_for_blocked_keywords(self, question: str) -> str:

        prompt = f"""You are an AI assistant following KITE's compliance guidelines. 
You must block certain responses if sensitive terms appear.

**Block if BOTH:**
1. Query contains keywords:
   - Safety: "adverse event", "ae", "sae", "safety report", "adr", "pharmacovigilance", "lactic acidosis"
   - Treatment: "treat patient", "dose for patient", "hiv patient", "treatment recommendation"
   - Promotional: "increase", "market share", "promote product", "marketing campaign"
   - HCP Payment: "speaker fee", "consulting payment", "transfer of value"
   - Competitor: "competitor data", "market intelligence", "abbvie", "merck"
2. User asks for a recommendation, action, or decision ("should", "how can we", "what’s the best way", "recommend","Can you provide", "can you provide details", etc.).

**Compliance Responses:**
- Safety: "I cannot provide information about adverse events or safety reporting. Please contact KITE's Drug Safety department."
- Treatment: "I cannot provide treatment recommendations for individual patients. Clinical decisions should be based on judgment and labeling."
- Promotional: "I cannot provide promotional information. I only support Medical Affairs with educational content."
- HCP Payment: "I cannot discuss transfers of value to healthcare professionals. Please consult Compliance."
- Competitor: "I cannot provide competitor intelligence. Refer to public sources or KITE’s CI team."

**Rules:**
- If unclear → respond "false"
- If only informational/general → respond "false"
- Do not generate cypher queries if blocked

**User question:**  
{question}"""
        
        response = self._generate_llm_response(prompt)
        if response:
            logger.info("Successfully checked for blocked keywords")
            if response.strip() != "false":
                return response.strip()
            else:
                return ""
        else:
            logger.error("Failed to check for blocked keywords")
            return "false"





    def generate_insights_from_text(self, text: str) -> dict:
        """
        Generate insights from text using LLM
        """
        prompt = f"""
        You are an expert at extracting insights from text.
        Extract the most important insights from the text.
        and return the insights in a JSON object with the following fields:
        - insights_one_liner: one liner insight
        - insights_points: points of insight

        **Input text:**
        {text}  

        **Output format:**
        ```json
        {{
            "insights_one_liner": "one liner insight",
            "insights_points": "points of insight"
        }}
        ```

        """
        response = self._generate_llm_response(prompt)
        if response:
            try:
                # Clean response - remove markdown code blocks if present
                cleaned_response = response.strip()

                # Check if response starts with markdown code block
                if cleaned_response.startswith('```'):
                    # Remove markdown code blocks (```json or ```)
                    lines = cleaned_response.split('\n')
                    # Remove first line (```json or ```)
                    lines = lines[1:]
                    # Remove last line if it's ```
                    if lines and lines[-1].strip() == '```':
                        lines = lines[:-1]
                    cleaned_response = '\n'.join(lines).strip()

                # Parse JSON
                insights = json.loads(cleaned_response)

                # Handle insights_points - convert list to string if needed
                insights_points = insights.get('insights_points', '')
                if isinstance(insights_points, list):
                    # Convert list to bullet-point string
                    insights_points = '\n'.join([f"• {str(point).strip()}" for point in insights_points if str(point).strip()])
                elif isinstance(insights_points, str):
                    # If it's already a string, use as-is
                    pass
                else:
                    # Convert to string if it's something else
                    insights_points = str(insights_points)

                # Return structured response
                return {
                    'insights_one_liner': insights.get('insights_one_liner', ''),
                    'insights_points': insights_points
                }

            except (json.JSONDecodeError, KeyError, TypeError) as e:
                logger.error(f"Failed to parse insights JSON: {e}")
                return {
                    "insights_one_liner": "",
                    "insights_points": ""
                }
        else:
            return {
                "insights_one_liner": "",
                "insights_points": ""
            }

    def generate_insights_pointers(self, text: str) -> list:
        """
        Generate insights pointers from text using LLM
        """
        response = self._generate_llm_response(text)
        if response:
            try:
                # Clean response - remove markdown code blocks (```json or ```) if present
                cleaned_response = response.strip()

                # Check if response starts with markdown code block
                if cleaned_response.startswith('```'):
                    # Remove markdown code blocks (```json or ```)
                    lines = cleaned_response.split('\n')
                    # Remove first line (```json or ```)
                    lines = lines[1:]
                    # Remove last line if it's ```
                    if lines and lines[-1].strip() == '```':
                        lines = lines[:-1]
                    cleaned_response = '\n'.join(lines).strip()
                insights_pointers = json.loads(cleaned_response)
                return insights_pointers
            except (json.JSONDecodeError, KeyError, TypeError) as e:
                logger.error(f"Failed to parse insights pointers JSON: {e}")
                return []
            except Exception as e:
                logger.error(f"Failed to generate insights pointers: {e}")
                return []
        else:
            logger.error("Failed to generate insights pointers")
            return []