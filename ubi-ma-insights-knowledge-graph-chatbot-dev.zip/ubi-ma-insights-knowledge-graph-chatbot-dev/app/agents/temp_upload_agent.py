import os
import io
import time
import boto3
import requests
import json
from typing import List, Dict, Any, Optional
from fastapi import UploadFile
from app.core.logger import get_logger
from app.core.models import TempUploadResponse, FileUploadInfo
from app.services.config_service import config
from app.services.vector_service import VectorService

logger = get_logger('temp_upload_agent')

class TempUploadAgent:
    """
    Temp Upload Agent for handling PDF and video file uploads to S3
    Only processes PDFs for vector creation using filenames, uploads videos to S3 only
    """
    
    def __init__(self):
        self.vector_service = VectorService()
        
        # Load configuration from environment variables
        self.s3_bucket = os.getenv('S3_BUCKET', 'json-data-storage')
        self.s3_prefix = os.getenv('S3_TEMP_PREFIX', 'temp-uploads/')
        self.region_name = os.getenv('S3_REGION', os.getenv('AWS_DEFAULT_REGION', 'us-west-2'))
        
        self.supported_pdf_extensions = ['.pdf']
        self.supported_video_extensions = ['.mp4']
        self.supported_extensions = self.supported_pdf_extensions + self.supported_video_extensions
        
        self.max_file_size = 50 * 1024 * 1024  # 50MB
        
        # Transcript API configuration from environment variables
        self.transcript_api_url = os.getenv('TRANSCRIPT_API_URL', 'https://genai-studio.usefulbi.com/workflow-api/v2/pipeline/')
        self.transcript_agent_id = os.getenv('TRANSCRIPT_AGENT_ID', '26IDHLJRHY')
        
        # AWS credentials configuration (supports temporary credentials)
        self.aws_access_key_id = os.getenv('AWS_ACCESS_KEY_ID')
        self.aws_secret_access_key = os.getenv('AWS_SECRET_ACCESS_KEY')
        self.aws_session_token = os.getenv('AWS_SESSION_TOKEN')  # For temporary credentials
        

    
    def validate_request(self, files: List[UploadFile]) -> Dict[str, Any]:
        """Validate temp upload files"""

        validation_results = {
            'valid': False,
            'errors': [],
            'warnings': []
        }
        
        try:
            if not files:
                validation_results['errors'].append("At least one file is required")
                return validation_results
            
            pdf_count = 0
            video_count = 0
            
            for file in files:
                file_ext = os.path.splitext(file.filename)[1].lower()
                
                if file_ext not in self.supported_extensions:
                    validation_results['errors'].append(
                        f"Unsupported file type: {file.filename} ({file_ext}). "
                        f"Supported types: {', '.join(self.supported_extensions)}"
                    )
                    continue
                
                if file.size > self.max_file_size:
                    validation_results['errors'].append(
                        f"File too large: {file.filename} ({file.size / (1024*1024):.1f}MB). "
                        f"Maximum size: {self.max_file_size / (1024*1024):.0f}MB"
                    )
                
                if file_ext in self.supported_pdf_extensions:
                    pdf_count += 1
                elif file_ext in self.supported_video_extensions:
                    video_count += 1
            
            logger.info(f"File validation summary: {pdf_count} PDFs, {video_count} videos")
            
            if pdf_count == 0 and video_count == 0 and not validation_results['errors']:
                validation_results['errors'].append("No valid PDF or video files found")
            
            validation_results['valid'] = len(validation_results['errors']) == 0
            
            if validation_results['valid']:
                logger.info("Temp upload request validation passed")
            else:
                logger.error(f"Temp upload request validation failed: {validation_results['errors']}")
            
        except Exception as e:
            validation_results['errors'].append(f"Validation error: {str(e)}")
            logger.error(f"Error during validation: {str(e)}")
        
        return validation_results
    
    def process_temp_upload(self, files: List[UploadFile]) -> TempUploadResponse:
        """Upload files to S3 and process PDFs and videos for vector creation"""
        start_time = time.time()
        logger.info(f"Starting temp upload processing for {len(files)} files")
        
        response = TempUploadResponse(
            success=False,
            message="Temp upload processing started"
        )
        
        try:
            # Create S3 client with credentials if available
            # s3_client_kwargs = {'region_name': self.region_name}
            
            # if self.aws_access_key_id and self.aws_secret_access_key:
            #     s3_client_kwargs.update({
            #         'aws_access_key_id': self.aws_access_key_id,
            #         'aws_secret_access_key': self.aws_secret_access_key,
                    
            #     })
                
            #     # Add session token if available (for temporary credentials)
            #     if self.aws_session_token:
            #         s3_client_kwargs['aws_session_token'] = self.aws_session_token
            #         logger.info("Using temporary AWS credentials from environment variables (with session token)")
            #     else:
            #         logger.info("Using permanent AWS credentials from environment variables")
            # else:
            #     logger.info("Using default AWS credentials (IAM role or AWS CLI)")
            
            # s3_client = boto3.client('s3', config=Config(signature_version=UNSIGNED))
            s3_client = None
            files_info = []
            pdf_files_processed = 0
            video_files_processed = 0
            errors = []
            
            for file in files:
                try:
                    file_info = self._process_single_file(file, s3_client)
                    files_info.append(file_info)
                    
                    if file_info.file_type == 'pdf' and file_info.processing_status == 'processed':
                        pdf_files_processed += 1
                    elif file_info.file_type == 'video' and file_info.processing_status == 'processed':
                        video_files_processed += 1
                    
                except Exception as e:
                    error_msg = f"Error processing file {file.filename}: {str(e)}"
                    logger.error(error_msg)
                    errors.append(error_msg)
                    
                    files_info.append(FileUploadInfo(
                        filename=file.filename,
                        file_type=self._get_file_type(file.filename),
                        file_size=file.size,
                        s3_url="",
                        processing_status="error",
                        error_message=str(e)
                    ))
            
            processing_time = time.time() - start_time
            
            response = TempUploadResponse(
                success=len(errors) == 0 or len(files_info) > len(errors),
                message=f"Processed {len(files_info)} files in {processing_time:.2f}s - "
                       f"PDFs: {pdf_files_processed}, Videos: {video_files_processed}",
                files_processed=len(files_info),
                pdf_files_processed=pdf_files_processed,
                video_files_uploaded=video_files_processed,  # Keep the field name for compatibility
                files_info=files_info,
                errors=errors if errors else None
            )
            
            if response.success:
                logger.info(f"Temp upload completed successfully: {response.message}")
            else:
                logger.warning(f"Temp upload completed with errors: {response.message}")
                
        except Exception as e:
            error_msg = f"Temp upload processing failed: {str(e)}"
            logger.error(error_msg)
            response = TempUploadResponse(
                success=False,
                message=error_msg,
                errors=[error_msg]
            )
        
        return response
    
    def _process_single_file(self, file: UploadFile, s3_client) -> FileUploadInfo:
        """Process a single file - upload to S3 and handle PDF processing for vectors"""
        logger.info(f"Processing file: {file.filename} ({file.size} bytes)")
        
        file_type = self._get_file_type(file.filename)
        s3_key = f"{self.s3_prefix.rstrip('/')}/{file.filename}"
        
        file_content = file.file.read()
        file.file.seek(0)
        
        # try:
        #     # s3_client.put_object(
        #     #     Bucket=self.s3_bucket,
        #     #     Key=s3_key,
        #     #     Body=file_content,
        #     #     ContentType=file.content_type or 'application/octet-stream'
        #     # )
            
        #     # s3_url = f"https://{self.s3_bucket}.s3.{self.region_name}.amazonaws.com/{s3_key}"
        #     # logger.info(f"Successfully uploaded {file.filename} to S3: {s3_url}")
            
        # except Exception as e:
        #     logger.error(f"Failed to upload {file.filename} to S3: {str(e)}")
        #     raise Exception(f"S3 upload failed: {str(e)}")
        
        file_info = FileUploadInfo(
            filename=file.filename,
            file_type=file_type,
            file_size=file.size,
            s3_url="",
            processing_status="uploaded"
        )
        
        # Process PDF for vectors
        if file_type == 'pdf':
            try:
                self._process_pdf_for_vectors(file_content, file.filename)
                file_info.processing_status = "processed"
                logger.info(f"Successfully processed PDF {file.filename} for vectors")
                
            except Exception as e:
                logger.error(f"Failed to process PDF {file.filename} for vectors: {str(e)}")
                file_info.processing_status = "uploaded"
                file_info.error_message = f"Vector processing failed: {str(e)}"
        
        # Process video for transcript and vectors
        elif file_type == 'video':
            try:
                self._process_video_for_vectors(file.filename)
                file_info.processing_status = "processed"
                logger.info(f"Successfully processed video {file.filename} for transcript vectors")
                
            except Exception as e:
                logger.error(f"Failed to process video {file.filename} for transcript: {str(e)}")
                file_info.processing_status = "uploaded"
                file_info.error_message = f"Transcript processing failed: {str(e)}"
        
        return file_info
    
    def _get_file_type(self, filename: str) -> str:
        """Determine file type based on extension"""
        file_ext = os.path.splitext(filename)[1].lower()
        
        if file_ext in self.supported_pdf_extensions:
            return 'pdf'
        elif file_ext in self.supported_video_extensions:
            return 'video'
        else:
            return 'unknown'
    
    def _process_pdf_for_vectors(self, pdf_content: bytes, filename: str) -> None:
        """Extract text from PDF and create vector embeddings"""
        logger.info(f"Processing PDF {filename} for vector creation")
        
        try:
            import PyPDF2
            
            # Extract text from PDF
            pdf_reader = PyPDF2.PdfReader(io.BytesIO(pdf_content))
            text_content = ""
            
            for page_num in range(len(pdf_reader.pages)):
                page = pdf_reader.pages[page_num]
                text_content += page.extract_text() + "\n"
            
            if not text_content.strip():
                raise Exception("No text content extracted from PDF")
            
            logger.info(f"Extracted {len(text_content)} characters from PDF {filename}")
            
            # Create chunks from text content
            chunks = self._create_text_chunks(text_content, filename)
            
            # Create vector embeddings using append method to preserve existing vectors
            vector_stats = self.vector_service.append_chunks_to_index(chunks)
            
            # Log internally but don't return count
            chunks_added = vector_stats.get('chunks_added', 0)
            logger.info(f"Added {chunks_added} vector chunks for {filename}")
            
        except ImportError:
            raise Exception("PyPDF2 library not installed. Run: pip install PyPDF2")
        except Exception as e:
            logger.error(f"Error processing PDF {filename}: {str(e)}")
            raise e
    
    def _process_video_for_vectors(self, filename: str) -> None:
        """Get transcript from video via external API and create vector embeddings"""
        logger.info(f"Processing video {filename} for transcript and vector creation")
        
        try:
            # Get transcript from external API
            transcript_text = self._get_video_transcript(filename)
            
            if not transcript_text or not transcript_text.strip():
                raise Exception("No transcript content received from video")
            
            logger.info(f"Received transcript with {len(transcript_text)} characters for video {filename}")
            
            # Create chunks from transcript content
            chunks = self._create_transcript_chunks(transcript_text, filename)
            
            # Create vector embeddings using append method to preserve existing vectors
            vector_stats = self.vector_service.append_chunks_to_index(chunks)
            
            # Log internally but don't return count
            chunks_added = vector_stats.get('chunks_added', 0)
            logger.info(f"Added {chunks_added} vector chunks for video transcript {filename}")
            
        except Exception as e:
            logger.error(f"Error processing video {filename} for transcript: {str(e)}")
            raise e
    
    def _get_video_transcript(self, filename: str) -> str:
        """Call external API to get video transcript"""
        logger.info(f"Requesting transcript for video: {filename}")
        
        try:
            # Prepare API request payload
            payload = {
                "steps": [
                    {
                        "agent_id": self.transcript_agent_id,
                        "alias": "datasource-connector",
                        "input_key": "inputText",
                        "output_key": "datasource-connector",
                        "provider": "bedrock",
                        "datasource": {
                            "s3": {
                                "s3_bucket": self.s3_bucket,
                                "s3_region": self.region_name,
                                "s3_prefix": self.s3_prefix
                            },
                            "source_type": "s3"
                        }
                    }
                ],
                "input": {
                    "input": f"Give me entire transcript for video titled {filename}"
                }
            }
            
            headers = {
                'Content-Type': 'application/json'
            }
            
            logger.info(f"Calling transcript API for {filename}")
            logger.debug(f"API payload: {json.dumps(payload, indent=2)}")
            
            # Make API request
            response = requests.post(
                self.transcript_api_url,
                headers=headers,
                json=payload,
                timeout=300  # 5 minutes timeout for video processing
            )
            
            if response.status_code != 200:
                raise Exception(f"Transcript API returned status {response.status_code}: {response.text}")
            
            # Parse response
            response_data = response.json()
            logger.debug(f"API response: {json.dumps(response_data, indent=2)}")
            
        
            if 'final_output' in response_data:
                transcript = response_data['final_output']
            else:
                transcript = str(response_data)
            
            if isinstance(transcript, dict):
                transcript = str(transcript)
            
            logger.info(f"Successfully extracted transcript for {filename} ({len(transcript)} characters)")
            return transcript
            
        except requests.exceptions.Timeout:
            raise Exception("Transcript API request timed out (5 minutes)")
        except requests.exceptions.RequestException as e:
            raise Exception(f"Transcript API request failed: {str(e)}")
        except json.JSONDecodeError as e:
            raise Exception(f"Failed to parse transcript API response: {str(e)}")
        except Exception as e:
            logger.error(f"Error getting transcript for {filename}: {str(e)}")
            raise e
    
    def _create_transcript_chunks(self, transcript_text: str, filename: str) -> List[Dict[str, Any]]:
        """Create paragraph-wise chunks from video transcript"""
        logger.info(f"Creating chunks from transcript for {filename}")
        
        # Split transcript into paragraphs (similar to PDF processing)
        paragraphs = [p.strip() for p in transcript_text.split('\n\n') if p.strip()]
        
        # If no paragraph breaks, split by lines
        if len(paragraphs) <= 1:
            paragraphs = [p.strip() for p in transcript_text.split('\n') if p.strip()]
        
        # Create chunk objects from paragraphs
        chunks = []
        for i, paragraph in enumerate(paragraphs):
            chunks.append({
                'source': filename,
                'chunk_id': f"{filename}_transcript_chunk_{i}",
                'chunk_type': 'video_transcript',
                'content': f"Transcript from video {filename}, chunk {i+1}:\n{paragraph}",
                'metadata': {
                    'file_type': 'video',
                    'chunk_index': i,
                    'chunk_length': len(paragraph),
                    'filename': filename,
                    'content_type': 'transcript'
                }
            })
        
        logger.info(f"Created {len(chunks)} transcript chunks from {filename}")
        return chunks

    def _create_text_chunks(self, text_content: str, filename: str) -> List[Dict[str, Any]]:
        """Create paragraph-wise chunks from PDF text content"""
        
        # Split text into paragraphs
        paragraphs = [p.strip() for p in text_content.split('\n\n') if p.strip()]
        
        # Create chunk objects from paragraphs
        chunks = []
        for i, paragraph in enumerate(paragraphs):
                chunks.append({
                    'source': filename,
                    'chunk_id': f"{filename}_chunk_{i}",
                    'chunk_type': 'pdf_text',
                    'content': f"Text from {filename}, chunk {i+1}:\n{paragraph}",
                    'metadata': {
                        'file_type': 'pdf',
                        'chunk_index': i,
                        'chunk_length': len(paragraph),
                        'filename': filename
                    }
                })
        
        logger.info(f"Created {len(chunks)} paragraph chunks from {filename}")
        return chunks 