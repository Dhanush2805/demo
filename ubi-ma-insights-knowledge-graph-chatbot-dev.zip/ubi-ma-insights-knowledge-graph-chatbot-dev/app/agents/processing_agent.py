import os
import pandas as pd
from typing import List, Dict, Any
from app.core.logger import get_logger
from app.core.models import FileInfo
from app.services.config_service import config
from app.services.vector_service import VectorService
from app.utils.csv_cleaner import clean_csv_file

logger = get_logger('processing_agent')

class ProcessingAgent:
    """
    Processing Agent for file conversion, analysis, and vector creation
    Combines Excel->CSV conversion with vector database creation
    Extracted and enhanced from notebook CSVAnalysisAgent
    """
    
    def __init__(self):
        """Initialize processing agent"""
        logger.info("Initializing Processing Agent")
        
        self.temp_folder = config.files.temp_folder
        self.csv_folder = config.files.csv_folder
        self.vector_service = VectorService()
        
        # Ensure CSV folder exists
        os.makedirs(self.csv_folder, exist_ok=True)
        
        logger.info(f"Processing Agent initialized - CSV folder: {self.csv_folder}")
    
    def process_files(self, downloaded_files: List[str]) -> Dict[str, Any]:
        """
        Main processing workflow: convert files, analyze, and create vectors
        Returns comprehensive processing results
        """
        logger.info(f"Starting file processing for {len(downloaded_files)} files")
        
        results = {
            'files_processed': 0,
            'csv_files_created': 0,
            'total_rows': 0,
            'files_info': [],
            'vector_stats': {},
            'errors': []
        }
        
        try:
            # Step 1: Convert Excel files to CSV
            csv_files = self._convert_excel_to_csv(downloaded_files)
            results['csv_files_created'] = len(csv_files)
            
            if not csv_files:
                logger.error("No CSV files created from downloaded files")
                return results
            
            # Step 2: Analyze CSV files
            files_info = self._analyze_csv_files(csv_files)
            results['files_info'] = files_info
            results['files_processed'] = len(files_info)
            results['total_rows'] = sum(f.row_count for f in files_info)
            
            # Step 3: Create vector embeddings
            logger.info("Creating vector embeddings for CSV files")
            vector_stats = self.vector_service.create_csv_vectors(csv_files)
            results['vector_stats'] = vector_stats
            
            logger.info(f"File processing completed successfully: "
                       f"{results['files_processed']} files, "
                       f"{results['total_rows']} total rows, "
                       f"{vector_stats.get('total_chunks', 0)} vector chunks")
            
        except Exception as e:
            error_msg = f"File processing failed: {str(e)}"
            logger.error(error_msg)
            results['errors'].append(error_msg)
        
        return results
    
    def process_files_without_vectors(self, downloaded_files: List[str]) -> Dict[str, Any]:
        """
        Processing workflow without vector creation: convert files and analyze only
        Returns processing results without vector embeddings
        """
        logger.info(f"Starting file processing (no vectors) for {len(downloaded_files)} files")
        
        results = {
            'files_processed': 0,
            'csv_files_created': 0,
            'total_rows': 0,
            'files_info': [],
            'vector_stats': {'total_chunks': 0},  # Empty stats for consistency
            'errors': []
        }
        
        try:
            # Step 1: Convert Excel files to CSV
            csv_files = self._convert_excel_to_csv(downloaded_files)
            results['csv_files_created'] = len(csv_files)
            
            if not csv_files:
                logger.error("No CSV files created from downloaded files")
                return results
            
            # Step 2: Analyze CSV files
            files_info = self._analyze_csv_files(csv_files)
            results['files_info'] = files_info
            results['files_processed'] = len(files_info)
            results['total_rows'] = sum(f.row_count for f in files_info)
            
            # Step 3: Skip vector creation
            logger.info("Skipping vector embeddings creation")
            
            logger.info(f"File processing (no vectors) completed successfully: "
                       f"{results['files_processed']} files, "
                       f"{results['total_rows']} total rows")
            
        except Exception as e:
            error_msg = f"File processing (no vectors) failed: {str(e)}"
            logger.error(error_msg)
            results['errors'].append(error_msg)
        
        return results
    
    def _convert_excel_to_csv(self, file_paths: List[str]) -> List[str]:
        """
        Convert Excel files to CSV format
        Extracted from notebook CSVAnalysisAgent.convert_excel_to_csv()
        """
        logger.info(f"Converting Excel files to CSV from {len(file_paths)} files")
        
        csv_files = []
        
        for file_path in file_paths:
            file_name = os.path.basename(file_path)
            file_ext = os.path.splitext(file_name)[1].lower()
            
            try:
                if file_ext in ['.xlsx', '.xls']:
                    # Handle Excel files
                    logger.info(f"Converting Excel file: {file_name}")
                    excel_csv_files = self._convert_single_excel_file(file_path)
                    csv_files.extend(excel_csv_files)
                    
                elif file_ext == '.csv':
                    # Copy CSV files to CSV folder and clean them
                    logger.info(f"Processing CSV file: {file_name}")
                    csv_file = self._copy_csv_file(file_path)
                    if csv_file:
                        # Clean the CSV file to handle null values and formatting issues
                        cleaning_result = clean_csv_file(csv_file, csv_file)
                        if cleaning_result['success']:
                            logger.info(f"Cleaned CSV file: {cleaning_result['null_values_fixed']} nulls fixed, "
                                      f"{cleaning_result['quote_issues_fixed']} quote issues fixed, "
                                      f"{cleaning_result['string_issues_fixed']} string issues fixed")
                        csv_files.append(csv_file)
                
                else:
                    logger.warning(f"Unsupported file type: {file_name}")
                    
            except Exception as e:
                logger.error(f"Error processing file {file_name}: {str(e)}")
                continue
        
        logger.info(f"Excel to CSV conversion completed: {len(csv_files)} CSV files created")
        return csv_files
    
    def _convert_single_excel_file(self, excel_path: str) -> List[str]:
        """Convert a single Excel file to CSV(s), handling multiple sheets"""
        csv_files = []
        file_name = os.path.basename(excel_path)
        base_name = os.path.splitext(file_name)[0]
        
        try:
            # Read Excel file
            excel_file = pd.ExcelFile(excel_path)
            logger.info(f"Excel file {file_name} has {len(excel_file.sheet_names)} sheets")
            
            for sheet_name in excel_file.sheet_names:
                try:
                    # Read sheet data
                    df = pd.read_excel(excel_path, sheet_name=sheet_name)
                    
                    # Skip empty sheets
                    if df.empty:
                        logger.warning(f"Skipping empty sheet: {sheet_name}")
                        continue
                    
                    # Create safe filename
                    safe_sheet_name = self._sanitize_filename(sheet_name)
                    csv_filename = f"{base_name}_{safe_sheet_name}.csv"
                    csv_path = os.path.join(self.csv_folder, csv_filename)
                    
                    # Save to CSV
                    df.to_csv(csv_path, index=False)
                    
                    # Clean the CSV file to handle any null values or formatting issues
                    cleaning_result = clean_csv_file(csv_path, csv_path)
                    if cleaning_result['success']:
                        logger.info(f"Cleaned converted CSV: {cleaning_result['null_values_fixed']} nulls fixed, "
                                  f"{cleaning_result['string_issues_fixed']} string issues fixed")
                    
                    csv_files.append(csv_path)
                    
                    logger.info(f"Converted sheet '{sheet_name}' to {csv_filename} "
                               f"({len(df)} rows, {len(df.columns)} columns)")
                    
                except Exception as e:
                    logger.error(f"Error converting sheet '{sheet_name}' in {file_name}: {str(e)}")
                    continue
            
        except Exception as e:
            logger.error(f"Error reading Excel file {file_name}: {str(e)}")
        
        return csv_files
    
    def _copy_csv_file(self, csv_path: str) -> str:
        """Copy CSV file to CSV folder and return new path"""
        try:
            file_name = os.path.basename(csv_path)
            destination_path = os.path.join(self.csv_folder, file_name)
            
            # Copy file
            import shutil
            shutil.copy2(csv_path, destination_path)
            
            logger.info(f"Copied CSV file: {file_name}")
            return destination_path
            
        except Exception as e:
            logger.error(f"Error copying CSV file {csv_path}: {str(e)}")
            return ""
    
    def _sanitize_filename(self, filename: str) -> str:
        """Sanitize filename to be safe for file system"""
        # Replace problematic characters
        invalid_chars = ['<', '>', ':', '"', '/', '\\', '|', '?', '*', ' ']
        sanitized = filename
        
        for char in invalid_chars:
            sanitized = sanitized.replace(char, '_')
        
        # Remove consecutive underscores
        while '__' in sanitized:
            sanitized = sanitized.replace('__', '_')
        
        # Remove leading/trailing underscores
        sanitized = sanitized.strip('_')
        
        # Ensure not empty
        if not sanitized:
            sanitized = "unnamed"
        
        return sanitized
    
    def _analyze_csv_files(self, csv_files: List[str]) -> List[FileInfo]:
        """
        Analyze CSV files and return file information
        Extracted from notebook CSVAnalysisAgent.analyze_csv_files()
        """
        logger.info(f"Analyzing {len(csv_files)} CSV files")
        
        files_info = []
        
        for csv_file in csv_files:
            try:
                logger.info(f"Analyzing file: {os.path.basename(csv_file)}")
                
                # Read CSV file
                df = pd.read_csv(csv_file)
                
                # Handle empty files
                if df.empty:
                    logger.warning(f"Skipping empty CSV file: {os.path.basename(csv_file)}")
                    continue
                
                # Get sample data (first 5 rows, handle NaN values)
                sample_df = df.head(5).fillna("")
                sample_data = sample_df.to_dict('records')
                
                # Create FileInfo object
                file_info = FileInfo(
                    filename=os.path.basename(csv_file),
                    file_path=csv_file,  # Include file path
                    file_size=os.path.getsize(csv_file),  # Include file size
                    columns=list(df.columns),
                    row_count=len(df),
                    sample_data=sample_data
                )
                
                files_info.append(file_info)
                
                logger.info(f"Analysis complete for {file_info.filename}: "
                           f"{len(file_info.columns)} columns, {file_info.row_count} rows")
                
            except Exception as e:
                logger.error(f"Error analyzing CSV file {csv_file}: {str(e)}")
                continue
        
        logger.info(f"CSV analysis completed: {len(files_info)} files analyzed")
        return files_info
    
    def get_processing_stats(self) -> Dict[str, Any]:
        """Get statistics about processed files and vectors"""
        logger.info("Getting processing statistics")
        
        try:
            # Count CSV files
            csv_files_count = 0
            if os.path.exists(self.csv_folder):
                csv_files_count = len([f for f in os.listdir(self.csv_folder) if f.endswith('.csv')])
            
            # Get vector database stats
            vector_stats = self.vector_service.get_database_stats()
            
            stats = {
                'csv_folder': self.csv_folder,
                'csv_files_count': csv_files_count,
                'vector_stats': vector_stats,
                'temp_folder': self.temp_folder
            }
            
            logger.info(f"Processing stats: {csv_files_count} CSV files, "
                       f"vector status: {vector_stats.get('status', 'unknown')}")
            return stats
            
        except Exception as e:
            logger.error(f"Error getting processing stats: {str(e)}")
            return {'error': str(e)}
    
    def cleanup_processed_files(self):
        """Clean up processed CSV files and vectors"""
        logger.info("Cleaning up processed files")
        
        try:
            # Clean CSV folder
            if os.path.exists(self.csv_folder):
                import shutil
                shutil.rmtree(self.csv_folder)
                os.makedirs(self.csv_folder, exist_ok=True)
                logger.info("CSV folder cleaned")
            
            # Clean vector database
            self.vector_service.clear_database()
            logger.info("Vector database cleared")
            
            logger.info("Cleanup completed successfully")
            
        except Exception as e:
            logger.error(f"Error during cleanup: {str(e)}")
    

    
    def process_csv_in_chunks(self, csv_file_path: str, chunk_size: int = 10) -> Dict[str, Any]:
        """
        Process a CSV file in chunks for chunk-wise Cypher query generation
        
        Args:
            csv_file_path: Path to the CSV file to process
            chunk_size: Number of rows per chunk (default: 10)
            
        Returns:
            Dictionary with file info and chunks data
        """
        logger.info(f"Processing CSV file in chunks: {os.path.basename(csv_file_path)} "
                   f"(chunk size: {chunk_size})")
        
        try:
            # Read CSV file
            df = pd.read_csv(csv_file_path, dtype=str)  # Read as strings to preserve original values
            
            # Skip if empty
            if df.empty:
                logger.warning(f"CSV file is empty: {csv_file_path}")
                return {'file_info': None, 'chunks': []}
            
            # Prepare file info
            file_info = FileInfo(
                filename=os.path.basename(csv_file_path),
                file_path=csv_file_path,  # Include file path
                file_size=os.path.getsize(csv_file_path),  # Include file size
                columns=df.columns.tolist(),
                row_count=len(df),
                sample_data=df.head(3).fillna('').to_dict('records')  # Sample for context
            )
            
            # Split data into chunks
            chunks = []
            total_chunks = (len(df) + chunk_size - 1) // chunk_size
            
            for chunk_idx in range(0, len(df), chunk_size):
                chunk_end = min(chunk_idx + chunk_size, len(df))
                chunk_df = df.iloc[chunk_idx:chunk_end]
                chunk_number = (chunk_idx // chunk_size) + 1
                
                # Convert chunk to list of dictionaries, handling NaN values
                chunk_data = chunk_df.fillna('').to_dict('records')
                
                chunks.append({
                    'chunk_number': chunk_number,
                    'total_chunks': total_chunks,
                    'data': chunk_data,
                    'row_range': f"{chunk_idx + 1}-{chunk_end}"
                })
                
                logger.info(f"Created chunk {chunk_number}/{total_chunks} "
                           f"with {len(chunk_data)} rows (rows {chunk_idx + 1}-{chunk_end})")
            
            logger.info(f"CSV file processed into {len(chunks)} chunks "
                       f"({len(df)} total rows)")
            
            return {
                'file_info': file_info,
                'chunks': chunks,
                'total_rows': len(df),
                'total_chunks': len(chunks)
            }
            
        except Exception as e:
            error_msg = f"Error processing CSV file in chunks: {str(e)}"
            logger.error(error_msg)
            return {'file_info': None, 'chunks': [], 'error': error_msg}

