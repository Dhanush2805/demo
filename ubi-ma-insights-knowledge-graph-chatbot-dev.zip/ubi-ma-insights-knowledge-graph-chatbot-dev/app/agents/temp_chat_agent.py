import time
from typing import Dict, List, Any, Optional
from app.core.logger import get_logger
from app.core.models import TempChatRequest, TempChatResponse
from app.services.vector_service import VectorService
from app.agents.llm_agent import LLMAgent

logger = get_logger('temp_chat_agent')

class TempChatAgent:
    """
    Agent for answering questions about uploaded PDF files using vector search and Azure LLM
    """
    
    def __init__(self):
        """Initialize the temp chat agent"""
        logger.info("Initializing TempChatAgent")
        
        self.vector_service = VectorService()
        self.llm_agent = LLMAgent() 
            
    def process_temp_chat(self, request: TempChatRequest) -> TempChatResponse:
        """
        Process temp chat request and generate answer based on file content
        
        Args:
            request: TempChatRequest with question and source filename
            
        Returns:
            TempChatResponse with answer and metadata
        """
        start_time = time.time()
        logger.info(f"Processing temp chat for file: {request.source_filename}")
        logger.info(f"Question: {request.question}")
        
        try:
            search_results = self.vector_service.similarity_search_by_source(
                query=request.question,
                source_filename=request.source_filename,
                top_k=10
            )
            
            if not search_results:
                logger.warning(f"No content found for file: {request.source_filename}")
                return TempChatResponse(
                    success=False,
                    question=request.question,
                    source_filename=request.source_filename,
                    answer="",
                    sources_found=0,
                    processing_time=time.time() - start_time,
                    error=f"No content found for file '{request.source_filename}'. Please ensure the file was uploaded via /temp-upload and is a PDF file."
                )
            
            logger.info(f"Found {len(search_results)} relevant chunks from {request.source_filename}")
            
            context = self._build_context_from_results(search_results)
            answer = self._generate_answer(request.question, context, request.source_filename)
            
            processing_time = time.time() - start_time
            logger.info(f"Temp chat completed successfully in {processing_time:.2f} seconds")
            
            return TempChatResponse(
                success=True,
                question=request.question,
                source_filename=request.source_filename,
                answer=answer,
                sources_found=len(search_results),
                processing_time=processing_time
            )
            
        except Exception as e:
            processing_time = time.time() - start_time
            error_msg = f"Error processing temp chat: {str(e)}"
            logger.error(error_msg, exc_info=True)
            
            return TempChatResponse(
                success=False,
                question=request.question,
                source_filename=request.source_filename,
                answer="",
                sources_found=0,
                processing_time=processing_time,
                error=error_msg
            )
    
    def _build_context_from_results(self, search_results: List[Dict[str, Any]]) -> str:
        """
        Build context string from vector search results
        
        Args:
            search_results: List of search result dictionaries
            
        Returns:
            Formatted context string
        """        
        context_parts = []
        for i, result in enumerate(search_results, 1):
            content = result.get('content', '')
            score = result.get('similarity_score', 0.0)
            
            context_parts.append(f"[Chunk {i} - Relevance: {score:.3f}]\n{content}\n")
        
        context = "\n".join(context_parts)        
        return context
    
    def _generate_answer(self, question: str, context: str, source_filename: str) -> str:
        """
        Generate answer using Azure LLM based on question and context
        
        Args:
            question: User's question
            context: Relevant content from the file
            source_filename: Name of the source file
            
        Returns:
            Generated answer
        """
        logger.info("Building prompt for Azure LLM")
        
        prompt = f"""
You are an expert assistant that answers questions strictly based on the content of a provided document.

**Task**: Provide a clear and concise answer to the user's question using ONLY the content from the document.

**Source Document**: {source_filename}

**User Question**:
{question}

**Document Content**:
{context}

**Instructions**:
- Base your answer solely on the provided document content.
- Ensure the response is accurate, well-structured, and easy to understand.
- Do NOT include any information that is not present in the document.

Create a small on point summary paragraph first and then give point wise answer to the question, and Only generate point wise actionable pointers as Actionable Insights if the input contains one or more of the following keywords: "implement", "execute", "address", "resolve", "prioritize", "develop", "launch", "optimize", "review", "initiate", "insights", "actionable".
do not use any external things. 
Always mask all mobile numbers and email addresses in the output to protect privacy.
Mobile numbers: Show only the first 4 digits, mask the rest: 9876xxxxxx.
Email addresses (primary, secondary, or otherwise): Show only the first 2 characters of the username, mask the rest fully with *, and partially mask the domain name. Keep only the top-level domain visible.
Example: jo********@****.com or ma********@***.co.uk.
Birthday: Show only the first 2 digits of the year, mask the rest fully with *, and partially mask the month and day. Keep only the top-level domain visible.
Example: 19******** or 20********.

Please answer using clean, readable Markdown.
Use ### or ## for section headers.
Use **bold** to highlight key topics, important points, and scores.
Use bullet points or numbered lists where appropriate for clarity.
Do NOT wrap the output in code blocks (no triple backticks).
Ensure the output includes real line breaks, not escaped characters (do not use \n).
highlight topic and numbers in bold.
The final output should be ready to render in a Markdown viewer or save as a .md file with no extra formatting required.

"""


        logger.info(f"Prompt length: {len(prompt)} characters")
        
        try:
            response = self.llm_agent._generate_llm_response(prompt)
            
            if response:
                logger.info(f"Successfully generated answer (length: {len(response)} characters)")
                return response.strip()
            else:
                logger.error("LLM returned empty response")
                return "I'm unable to generate an answer at the moment. Please try again."
                
        except Exception as e:
            logger.error(f"Error generating answer with LLM: {str(e)}")
            return f"Error generating answer: {str(e)}" 