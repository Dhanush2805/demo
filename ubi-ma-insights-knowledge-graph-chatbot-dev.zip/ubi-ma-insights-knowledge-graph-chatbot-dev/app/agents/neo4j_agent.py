import time
from typing import List, Dict, Any, Optional
from neo4j import GraphDatabase
from app.core.logger import get_logger
from app.core.models import Neo4jExecutionResult
from app.services.config_service import config

logger = get_logger('neo4j_agent')

class Neo4jAgent:
    """
    Neo4j Agent for handling all database operations
    Extracted and enhanced from the notebook Neo4jExecutionAgent
    """
    
    def __init__(self):
        """Initialize Neo4j agent with configuration"""
        logger.info("Initializing Neo4j Agent")
        
        self.uri = config.neo4j.uri
        self.user = config.neo4j.user
        self.password = config.neo4j.password
        self.driver = None
        
        logger.info(f"Neo4j Agent configured for: {self.uri}")
    
    def connect(self) -> bool:
        """
        Connect to Neo4j database with error handling
        Returns True if connection successful, False otherwise
        """
        try:
            logger.info(f"Connecting to Neo4j at {self.uri}")
            
            self.driver = GraphDatabase.driver(
                self.uri,
                auth=(self.user, self.password)
            )
            
            # Test connection
            with self.driver.session() as session:
                result = session.run("RETURN 1 as test")
                test_value = result.single()["test"]
                
            if test_value == 1:
                logger.info("Neo4j connection established successfully")
                return True
            else:
                logger.error("Neo4j connection test failed")
                return False
                
        except Exception as e:
            logger.error(f"Neo4j connection failed: {str(e)}")
            return False
    
    def disconnect(self):
        """Close Neo4j connection"""
        if self.driver:
            self.driver.close()
            logger.info("Neo4j connection closed")
    
    def clear_database(self) -> Dict[str, int]:
        """
        Clear all data from the database
        Returns statistics about deleted nodes and relationships
        """
        logger.info("Clearing Neo4j database")
        
        try:
            with self.driver.session() as session:
                # Get counts before deletion
                nodes_before = session.run("MATCH (n) RETURN COUNT(n) as count").single()["count"]
                rels_before = session.run("MATCH ()-[r]->() RETURN COUNT(r) as count").single()["count"]
                
                logger.info(f"Before deletion: {nodes_before} nodes, {rels_before} relationships")
                
                # Delete all nodes and relationships
                result = session.run("MATCH (n) DETACH DELETE n")
                summary = result.consume()
                
                nodes_deleted = summary.counters.nodes_deleted
                rels_deleted = summary.counters.relationships_deleted
                
                logger.info(f"Database cleared: {nodes_deleted} nodes, {rels_deleted} relationships deleted")
                
                return {
                    "nodes_deleted": nodes_deleted,
                    "relationships_deleted": rels_deleted
                }
                
        except Exception as e:
            logger.error(f"Error clearing database: {str(e)}")
            return {"nodes_deleted": 0, "relationships_deleted": 0}
    

    def execute_cypher_queries(self, queries: List[str]) -> Dict[str, Any]:
        """
        Execute multiple Cypher queries with comprehensive error handling
        Returns detailed execution results
        """
        logger.info(f"Executing {len(queries)} Cypher queries")
        
        results = {
            'successful': 0,
            'failed': 0,
            'total_nodes': 0,
            'total_relationships': 0,
            'query_results': [],
            'errors': []
        }
        
        for i, query in enumerate(queries, 1):
            logger.info(f"Executing query {i}/{len(queries)}, Query: {query}")
            
            # Skip empty queries
            if not query.strip():
                logger.warning(f"Skipping empty query {i}")
                continue

            execution_result = self._execute_single_query(query, i)
            if execution_result.success:
                results['successful'] += 1
                results['total_nodes'] += execution_result.nodes_created
                results['total_relationships'] += execution_result.relationships_created
                
                logger.info(f"Query {i} executed successfully: "
                           f"{execution_result.nodes_created} nodes, "
                           f"{execution_result.relationships_created} relationships")
            else:
                results['failed'] += 1
                error_msg = f"Query {i} failed: {execution_result.error}"
                results['errors'].append(error_msg)
                results["failed_queries"].append(query)
                logger.error(error_msg)
            
            results['query_results'].append(execution_result)
        
        logger.info(f"Query execution completed: {results['successful']} successful, "
                   f"{results['failed']} failed")
        return results
    
    def _execute_single_query(self, query: str, query_num: int) -> Neo4jExecutionResult:
        """Execute a single Cypher query and return detailed results"""
        start_time = time.time()
        
        try:
            with self.driver.session() as session:
                result = session.run(query)
                summary = result.consume()


                execution_time = time.time() - start_time
                
                return Neo4jExecutionResult(
                    query=query,
                    success=True,
                    nodes_created=summary.counters.nodes_created,
                    relationships_created=summary.counters.relationships_created,
                    records_returned=0,  # For LOAD CSV queries, this is typically 0
                    execution_time=execution_time
                )
                
        except Exception as e:
            execution_time = time.time() - start_time
            return Neo4jExecutionResult(
                query=query,
                success=False,
                execution_time=execution_time,
                error=str(e)
            )
    def run_query(self, query, parameters=None):
        """Run a Cypher query"""
        with self.driver.session() as session:
            result = session.run(query, parameters or {})
            try:
                return [record.data() for record in result]
            except Exception:
                return None
    def execute_read_query(self, query: str, parameters: Optional[Dict] = None) -> List[Dict[str, Any]]:
        """
        Execute a read-only Cypher query and return results
        Used for chat queries that retrieve data
        """
        logger.info(f"Executing read query: {query[:100]}...")
        
        try:
            with self.driver.session() as session:
                start_time = time.time()
                result = session.run(query, parameters or {})
                records = [record.data() for record in result]
                execution_time = time.time() - start_time
                
                logger.info(f"Read query completed: {len(records)} records returned "
                           f"in {execution_time:.3f}s")
                return records
                
        except Exception as e:
            logger.error(f"Read query failed: {str(e)}")
            return []
        
    def fetch_schema(self):
        """
        Fetch schema information from the database
        Returns schema information
        """
        logger.info("Fetching Neo4j schema information")
        
        with self.driver.session() as session:
            labels = session.run("CALL db.labels()").data()
            relationships = session.run("""
                MATCH (a)-[r]->(b)
                UNWIND labels(a) AS fromLabel
                UNWIND labels(b) AS toLabel
                RETURN DISTINCT fromLabel AS from, type(r) AS rel, toLabel AS to
            """).data()

            schema = {
                "nodes": {},
                "relationships": relationships
            }

            for label_record in labels:
                label = label_record['label']
                try:
                    props = session.run(f"""
                    MATCH (a)-[r]->(b)
                    UNWIND labels(a) AS fromLabel
                    UNWIND labels(b) AS toLabel
                    RETURN DISTINCT fromLabel AS from, type(r) AS rel, toLabel AS to
                    """).single()
                    schema["nodes"][label] = props["props"] if props else []
                except Exception as e:
                    schema["nodes"][label] = []

            return schema

    def get_database_stats(self) -> Dict[str, Any]:
        """Get general database statistics"""
        logger.info("Getting database statistics")
        
        try:
            with self.driver.session() as session:
                # Total nodes
                total_nodes_result = session.run("MATCH (n) RETURN COUNT(n) as count")
                total_nodes = total_nodes_result.single()["count"]
                
                # Total relationships
                total_rels_result = session.run("MATCH ()-[r]->() RETURN COUNT(r) as count")
                total_relationships = total_rels_result.single()["count"]
                
                stats = {
                    'total_nodes': total_nodes,
                    'total_relationships': total_relationships,
                    'database_connected': True,
                    'uri': self.uri
                }
                
                logger.info(f"Database stats: {stats}")
                return stats
                
        except Exception as e:
            logger.error(f"Error getting database stats: {str(e)}")
            return {
                'total_nodes': 0,
                'total_relationships': 0,
                'database_connected': False,
                'error': str(e)
            }
            
    def fetch_schema_1(self):
        """
        Fetch node labels, their properties, and relationships from Neo4j.
        Returns structured schema information.
        """
        logger.info("Fetching Neo4j schema information")
        
        schema = {
            "nodes": {},
            "relationships": []
        }

        with self.driver.session() as session:
            # Fetch all labels
            labels = session.run("CALL db.labels()").data()

            # Fetch properties for each label
            for record in labels:
                label = record["label"]
                props_query = f"""
                    MATCH (n:`{label}`)
                    WITH n LIMIT 100
                    UNWIND keys(n) AS key
                    RETURN collect(DISTINCT key) AS props
                """
                try:
                    props_result = session.run(props_query).single()
                    schema["nodes"][label] = props_result["props"] if props_result else []
                except Exception as e:
                    logger.warning(f"Failed to fetch properties for label {label}: {e}")
                    schema["nodes"][label] = []

            # Fetch relationships with from/to labels
            rel_query = """
                MATCH (a)-[r]->(b)
                UNWIND labels(a) AS fromLabel
                UNWIND labels(b) AS toLabel
                RETURN DISTINCT fromLabel AS from, type(r) AS rel, toLabel AS to
            """
            rel_result = session.run(rel_query).data()
            schema["relationships"] = rel_result
        return schema