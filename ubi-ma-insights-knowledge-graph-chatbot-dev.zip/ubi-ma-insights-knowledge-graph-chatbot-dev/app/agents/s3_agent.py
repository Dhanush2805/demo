import os
import boto3
from urllib.parse import urlparse
from typing import List, Dict, Any, Optional
from app.core.logger import get_logger
from app.services.config_service import config

logger = get_logger('s3_agent')

class S3Agent:
    """
    S3 Agent for intelligent file discovery and download operations
    Handles AWS S3 operations with smart filtering and error handling
    Supports both authenticated and public S3 access
    """
    
    def __init__(self, aws_credentials: Optional[Dict[str, str]] = None):
        """Initialize S3 agent with optional AWS credentials"""
        logger.info("Initializing S3 Agent")
        
        # Initialize S3 client with or without credentials
        if aws_credentials and aws_credentials.get('aws_access_key_id'):
            logger.info("Using authenticated S3 access with provided credentials")
            self.s3_client = boto3.client('s3', **aws_credentials)
            self.public_access = False
        else:
            logger.info("Using anonymous S3 access for public URLs")
            # Create unsigned S3 client for public access
            from botocore import UNSIGNED
            from botocore.config import Config
            self.s3_client = boto3.client('s3', config=Config(signature_version=UNSIGNED))
            self.public_access = True
        
        self.temp_folder = config.files.temp_folder
        self.max_file_size_mb = config.files.max_file_size_mb
        
        # Supported file types
        self.supported_extensions = ['.csv', '.xlsx', '.xls']
        
        access_type = "public" if self.public_access else "authenticated"
        logger.info(f"S3 Agent initialized - access type: {access_type}, temp folder: {self.temp_folder}")
        
    def download_files_from_s3(self, s3_url: str) -> List[str]:
        """
        Intelligently download CSV and Excel files from S3 URL
        Returns list of downloaded file paths
        """
        logger.info(f"Starting S3 file download from: {s3_url}")
        
        # Parse S3 URL
        bucket_name, prefix = self._parse_s3_url(s3_url)
        if not bucket_name:
            logger.error(f"Invalid S3 URL: {s3_url}")
            return []
        
        logger.info(f"Parsed S3 URL - Bucket: {bucket_name}, Prefix: {prefix}")
        
        # Discover files in S3
        file_list = self._discover_files(bucket_name, prefix)
        if not file_list:
            logger.warning("No supported files found in S3 location")
            return []
        
        logger.info(f"Found {len(file_list)} supported files in S3")
        
        # Download files
        downloaded_files = self._download_file_list(bucket_name, file_list)
        
        logger.info(f"Successfully downloaded {len(downloaded_files)} files")
        return downloaded_files
    
    def parse_s3_url(self, s3_url: str) -> Dict[str, str]:
        """
        Parse S3 URL to extract bucket name and prefix
        Returns dictionary with 'bucket' and 'prefix' keys
        """
        bucket_name, prefix = self._parse_s3_url(s3_url)
        if not bucket_name:
            return {}
        return {
            'bucket': bucket_name,
            'prefix': prefix
        }
    
    def discover_files(self, bucket_name: str, prefix: str) -> List[Dict[str, Any]]:
        """
        Public method to discover CSV and Excel files in S3 bucket
        Returns list of file objects with metadata
        """
        return self._discover_files(bucket_name, prefix)
    
    def download_files(self, bucket_name: str, prefix: str) -> List[str]:
        """
        Download files from S3 bucket with given bucket name and prefix
        Returns list of downloaded file paths
        """
        # Discover files first
        file_list = self._discover_files(bucket_name, prefix)
        if not file_list:
            logger.warning("No supported files found in S3 location")
            return []
        
        # Download files
        return self._download_file_list(bucket_name, file_list)
    
    def _parse_s3_url(self, s3_url: str) -> tuple[str, str]:
        """
        Parse S3 URL to extract bucket name and prefix
        Returns (bucket_name, prefix)
        """
        try:
            # Handle different S3 URL formats
            if s3_url.startswith('s3://'):
                # s3://bucket-name/path/to/files/
                parsed = urlparse(s3_url)
                bucket_name = parsed.netloc
                prefix = parsed.path.lstrip('/')
            elif 'amazonaws.com' in s3_url:
                # https://bucket-name.s3.region.amazonaws.com/path/to/files/
                # or https://s3.region.amazonaws.com/bucket-name/path/to/files/
                parsed = urlparse(s3_url)
                if parsed.netloc.startswith('s3.'):
                    # Format: https://s3.region.amazonaws.com/bucket-name/path
                    path_parts = parsed.path.strip('/').split('/', 1)
                    bucket_name = path_parts[0] if path_parts else ''
                    prefix = path_parts[1] if len(path_parts) > 1 else ''
                else:
                    # Format: https://bucket-name.s3.region.amazonaws.com/path
                    bucket_name = parsed.netloc.split('.')[0]
                    prefix = parsed.path.lstrip('/')
            else:
                logger.error(f"Unsupported S3 URL format: {s3_url}")
                return '', ''
            
            logger.info(f"Parsed S3 URL - Bucket: {bucket_name}, Prefix: {prefix}")
            return bucket_name, prefix
            
        except Exception as e:
            logger.error(f"Error parsing S3 URL {s3_url}: {str(e)}")
            return '', ''
    
    def _discover_files(self, bucket_name: str, prefix: str) -> List[Dict[str, Any]]:
        """
        Discover CSV and Excel files in S3 bucket with intelligent filtering
        Returns list of file objects with metadata
        """
        logger.info(f"Discovering files in bucket '{bucket_name}' with prefix '{prefix}'")
        
        file_list = []
        
        try:
            # List objects in bucket
            paginator = self.s3_client.get_paginator('list_objects_v2')
            page_iterator = paginator.paginate(Bucket=bucket_name, Prefix=prefix)
            
            for page in page_iterator:
                if 'Contents' not in page:
                    continue
                    
                for obj in page['Contents']:
                    file_key = obj['Key']
                    file_size = obj['Size']
                    
                    # Filter by file extension
                    if not any(file_key.lower().endswith(ext) for ext in self.supported_extensions):
                        continue
                    
                    # Filter by file size (convert bytes to MB)
                    file_size_mb = file_size / (1024 * 1024)
                    if file_size_mb > self.max_file_size_mb:
                        logger.warning(f"Skipping large file: {file_key} ({file_size_mb:.1f}MB)")
                        continue
                    
                    # Skip directories (keys ending with /)
                    if file_key.endswith('/'):
                        continue
                    
                    file_info = {
                        'key': file_key,
                        'size': file_size,
                        'size_mb': file_size_mb,
                        'filename': os.path.basename(file_key),
                        'extension': os.path.splitext(file_key)[1].lower()
                    }
                    
                    file_list.append(file_info)
                    logger.info(f"Found file: {file_info['filename']} ({file_info['size_mb']:.1f}MB)")
            
            logger.info(f"File discovery completed: {len(file_list)} files found")
            return file_list
            
        except Exception as e:
            logger.error(f"Error discovering files in S3: {str(e)}")
            return []
    
    def _download_file_list(self, bucket_name: str, file_list: List[Dict[str, Any]]) -> List[str]:
        """
        Download list of files from S3 to local temp folder
        Returns list of local file paths
        """
        logger.info(f"Downloading {len(file_list)} files from S3")
        
        # Ensure temp folder exists
        os.makedirs(self.temp_folder, exist_ok=True)
        
        downloaded_files = []
        
        for i, file_info in enumerate(file_list, 1):
            file_key = file_info['key']
            filename = file_info['filename']
            
            # Create local file path
            local_file_path = os.path.join(self.temp_folder, filename)
            
            # Handle filename conflicts
            if os.path.exists(local_file_path):
                base_name, ext = os.path.splitext(filename)
                local_file_path = os.path.join(self.temp_folder, f"{base_name}_{i}{ext}")
                logger.info(f"Filename conflict resolved: {local_file_path}")
            
            try:
                logger.info(f"Downloading {i}/{len(file_list)}: {filename}")
                
                # Download file
                self.s3_client.download_file(bucket_name, file_key, local_file_path)
                
                # Verify download
                if os.path.exists(local_file_path):
                    local_size = os.path.getsize(local_file_path)
                    if local_size == file_info['size']:
                        downloaded_files.append(local_file_path)
                        logger.info(f"Successfully downloaded: {filename}")
                    else:
                        logger.error(f"Size mismatch for {filename}: "
                                   f"expected {file_info['size']}, got {local_size}")
                else:
                    logger.error(f"Download failed: {filename} not found locally")
                    
            except Exception as e:
                logger.error(f"Error downloading {filename}: {str(e)}")
                continue
        
        logger.info(f"Download completed: {len(downloaded_files)}/{len(file_list)} files successful")
        return downloaded_files
    
    def validate_s3_access(self, s3_url: str) -> bool:
        """
        Validate S3 access and check if URL is accessible
        Returns True if accessible, False otherwise
        """
        logger.info(f"Validating S3 access for: {s3_url}")
        
        bucket_name, prefix = self._parse_s3_url(s3_url)
        if not bucket_name:
            return False
        
        try:
            # Try to list objects to check access
            response = self.s3_client.list_objects_v2(
                Bucket=bucket_name,
                Prefix=prefix,
                MaxKeys=1
            )
            
            logger.info("S3 access validation successful")
            return True
            
        except Exception as e:
            logger.error(f"S3 access validation failed: {str(e)}")
            return False
    
    def get_s3_info(self, s3_url: str) -> Dict[str, Any]:
        """
        Get information about S3 location without downloading
        Returns metadata about available files
        """
        logger.info(f"Getting S3 info for: {s3_url}")
        
        bucket_name, prefix = self._parse_s3_url(s3_url)
        if not bucket_name:
            return {"error": "Invalid S3 URL"}
        
        try:
            # Discover files
            file_list = self._discover_files(bucket_name, prefix)
            
            # Calculate statistics
            total_files = len(file_list)
            total_size_mb = sum(f['size_mb'] for f in file_list)
            
            # Group by file type
            file_types = {}
            for file_info in file_list:
                ext = file_info['extension']
                if ext not in file_types:
                    file_types[ext] = {'count': 0, 'size_mb': 0}
                file_types[ext]['count'] += 1
                file_types[ext]['size_mb'] += file_info['size_mb']
            
            info = {
                'bucket': bucket_name,
                'prefix': prefix,
                'total_files': total_files,
                'total_size_mb': round(total_size_mb, 2),
                'file_types': file_types,
                'max_file_size_mb': self.max_file_size_mb,
                'supported_extensions': self.supported_extensions
            }
            
            logger.info(f"S3 info retrieved: {total_files} files, {total_size_mb:.1f}MB total")
            return info
            
        except Exception as e:
            logger.error(f"Error getting S3 info: {str(e)}")
            return {"error": str(e)}
    
    def get_csv_urls_from_s3(self, s3_url: str) -> List[Dict[str, Any]]:
        """
        Get direct HTTPS URLs for CSV files in S3 without downloading
        Returns list of file info with direct URLs for Neo4j LOAD CSV
        """
        logger.info(f"Getting CSV URLs from S3: {s3_url}")
        
        bucket_name, prefix = self._parse_s3_url(s3_url)
        if not bucket_name:
            return []
        
        # Discover files
        file_list = self._discover_files(bucket_name, prefix)
        if not file_list:
            return []
        
        # Convert S3 file keys to direct HTTPS URLs
        csv_urls = []
        for file_info in file_list:
            # Only process CSV files for direct loading
            if file_info['extension'] == '.csv':
                # Generate presigned URL for private access or public URL
                if self.public_access:
                    https_url = f"https://{bucket_name}.s3.amazonaws.com/{file_info['key']}"
                else:
                    # Generate presigned URL for authenticated access
                    try:
                        https_url = self.s3_client.generate_presigned_url(
                            'get_object',
                            Params={'Bucket': bucket_name, 'Key': file_info['key']},
                            ExpiresIn=3600  # 1 hour expiry
                        )
                    except Exception as e:
                        logger.error(f"Error generating presigned URL for {file_info['key']}: {str(e)}")
                        continue
                
                csv_info = {
                    'filename': file_info['filename'],
                    'url': https_url,
                    'size_mb': file_info['size_mb'],
                    'original_key': file_info['key']
                }
                csv_urls.append(csv_info)
                logger.info(f"CSV URL ready: {file_info['filename']} -> {https_url[:100]}...")
        
        logger.info(f"Generated {len(csv_urls)} CSV URLs for direct Neo4j loading")
        return csv_urls
    
    def analyze_csv_from_url(self, csv_url: str, filename: str) -> Optional['FileInfo']:
        """
        Analyze a CSV file directly from S3 URL without downloading
        Returns FileInfo object for the CSV file
        """
        logger.info(f"Analyzing CSV from URL: {filename}")
        
        try:
            import pandas as pd
            
            # Read CSV directly from URL
            df = pd.read_csv(csv_url)
            
            if df.empty:
                logger.warning(f"CSV file {filename} is empty")
                return None
            
            # Create FileInfo object
            from app.core.models import FileInfo
            
            file_info = FileInfo(
                filename=filename,
                file_path=csv_url,  # Use URL as path for Neo4j LOAD CSV
                file_size=0,  # Size not needed for URL-based loading
                columns=list(df.columns),
                row_count=len(df),
                sample_data=df.head(5).to_dict('records')  # First 5 rows as sample
            )
            
            logger.info(f"CSV analysis complete: {filename} - {len(df.columns)} columns, {len(df)} rows")
            return file_info
            
        except Exception as e:
            logger.error(f"Error analyzing CSV from URL {filename}: {str(e)}")
            return None

    def process_s3_files_optimized(self, s3_url: str) -> Dict[str, Any]:
        """
        Optimized S3 processing: Load CSVs directly, download only Excel files
        Returns processing results with mixed file sources
        """
        logger.info(f"Starting optimized S3 file processing for: {s3_url}")
        
        results = {
            'csv_files_direct': [],  # CSV files loaded directly from URLs
            'excel_files_downloaded': [],  # Excel files that were downloaded and converted
            'files_info': [],
            'total_csv_direct': 0,
            'total_excel_converted': 0,
            'errors': []
        }
        
        try:
            bucket_name, prefix = self._parse_s3_url(s3_url)
            if not bucket_name:
                results['errors'].append("Invalid S3 URL")
                return results
            
            # Discover all files
            file_list = self._discover_files(bucket_name, prefix)
            if not file_list:
                results['errors'].append("No supported files found in S3 location")
                return results
            
            # Separate CSV and Excel files
            csv_files = [f for f in file_list if f['extension'] == '.csv']
            excel_files = [f for f in file_list if f['extension'] in ['.xlsx', '.xls']]
            
            logger.info(f"Found {len(csv_files)} CSV files and {len(excel_files)} Excel files")
            
            # Process CSV files directly (no download)
            for csv_file in csv_files:
                try:
                    # Generate direct URL
                    if self.public_access:
                        csv_url = f"https://{bucket_name}.s3.amazonaws.com/{csv_file['key']}"
                    else:
                        csv_url = self.s3_client.generate_presigned_url(
                            'get_object',
                            Params={'Bucket': bucket_name, 'Key': csv_file['key']},
                            ExpiresIn=3600
                        )
                    
                    # Analyze CSV from URL
                    file_info = self.analyze_csv_from_url(csv_url, csv_file['filename'])
                    if file_info:
                        results['csv_files_direct'].append(csv_url)
                        results['files_info'].append(file_info)
                        results['total_csv_direct'] += 1
                        logger.info(f"✅ CSV ready for direct loading: {csv_file['filename']}")
                
                except Exception as e:
                    error_msg = f"Error processing CSV {csv_file['filename']}: {str(e)}"
                    logger.error(error_msg)
                    results['errors'].append(error_msg)
            
            # Process Excel files (download and convert)
            if excel_files:
                logger.info(f"Downloading and converting {len(excel_files)} Excel files...")
                downloaded_excel = self._download_file_list(bucket_name, excel_files)
                
                if downloaded_excel:
                    # Convert Excel to CSV using existing processing logic
                    from app.utils.csv_cleaner import clean_csv_file
                    
                    for excel_path in downloaded_excel:
                        try:
                            # Convert Excel to CSV (simplified version)
                            import pandas as pd
                            file_name = os.path.basename(excel_path)
                            base_name = os.path.splitext(file_name)[0]
                            
                            excel_file = pd.ExcelFile(excel_path)
                            for sheet_name in excel_file.sheet_names:
                                df = pd.read_excel(excel_path, sheet_name=sheet_name)
                                if df.empty:
                                    continue
                                    
                                csv_filename = f"{base_name}_{sheet_name}.csv"
                                csv_path = os.path.join(self.temp_folder, csv_filename)
                                df.to_csv(csv_path, index=False)
                                
                                # # Clean CSV
                                # clean_csv_file(csv_path, csv_path)
                                
                                # Analyze converted CSV
                                from app.core.models import FileInfo
                                file_info = FileInfo(
                                    filename=csv_filename,
                                    file_path=csv_path,
                                    file_size=os.path.getsize(csv_path),
                                    columns=list(df.columns),
                                    row_count=len(df),
                                    sample_data=df.head(5).to_dict('records')
                                )
                                
                                results['excel_files_downloaded'].append(csv_path)
                                results['files_info'].append(file_info)
                                results['total_excel_converted'] += 1
                                logger.info(f"✅ Excel converted: {csv_filename}")
                                
                        except Exception as e:
                            error_msg = f"Error converting Excel {excel_path}: {str(e)}"
                            logger.error(error_msg)
                            results['errors'].append(error_msg)
            
            logger.info(f"Optimized processing complete: {results['total_csv_direct']} CSVs direct, "
                       f"{results['total_excel_converted']} Excel converted")
            
        except Exception as e:
            error_msg = f"Optimized S3 processing failed: {str(e)}"
            logger.error(error_msg)
            results['errors'].append(error_msg)
        
        return results

    def cleanup_temp_files(self, file_paths: Optional[List[str]] = None):
        """
        Clean up temporary downloaded files
        If file_paths is None, cleans entire temp folder
        """
        if file_paths is None:
            logger.info(f"Cleaning up entire temp folder: {self.temp_folder}")
            try:
                if os.path.exists(self.temp_folder):
                    import shutil
                    shutil.rmtree(self.temp_folder)
                    os.makedirs(self.temp_folder, exist_ok=True)
                logger.info("Temp folder cleaned successfully")
            except Exception as e:
                logger.error(f"Error cleaning temp folder: {str(e)}")
        else:
            logger.info(f"Cleaning up {len(file_paths)} specific files")
            for file_path in file_paths:
                try:
                    if os.path.exists(file_path):
                        os.remove(file_path)
                        logger.info(f"Removed: {file_path}")
                except Exception as e:
                    logger.error(f"Error removing {file_path}: {str(e)}") 