import time
from typing import Dict, Any, List, Optional
from app.core.logger import get_logger
from app.core.models import ChatRequest, ChatResponse, VectorSearchResult
from app.services.config_service import config
from app.services.vector_service import VectorService
from app.agents.llm_agent import LLMAgent
from app.agents.neo4j_agent import Neo4jAgent
from app.services.metrics_service import MetricsService
from app.services.cache_service import CacheService

logger = get_logger('chat_agent')

class ChatAgent:
    """
    Chat Agent - Main orchestrator for the chat workflow
    Coordinates VectorService, LLMAgent, and Neo4jAgent for question answering
    Implements the agentic chat workflow from the text diagram
    """
    
    def __init__(self):
        """Initialize chat agent"""
        logger.info("Initializing Chat Agent")
        
        self.vector_service = VectorService()
        self.neo4j_agent = Neo4jAgent()
        self.cache_service = CacheService.get_instance()
        
        # Define keyword checks for restricted queries
        self.keyword_checks = [
            {
                "keywords": [
                    "adverse event", "ae", "serious adverse event", "sae",
                    "side effect", "safety report", "drug reaction", "adr",
                    "adverse drug reaction", "safety signal", "pharmacovigilance",
                    "report adverse", "safety reporting", "medwatch", "safety data",
                    "hepatotoxicity", "nephrotoxicity", "lactic acidosis" 
                ],
                "response": "I cannot provide information about adverse events or safety reporting. For all safety-related queries, please contact KITE's Drug Safety department or refer to established KITE adverse event reporting procedures."
            },
            {
                "keywords": [
                    "treat patient", "prescribe for", "dose for patient", "my patient",
                    "this patient", "individual patient", "specific patient",
                    "patient treatment", "clinical decision", "treatment recommendation",
                    "therapy selection", "patient management", "adjust dose",
                    "hiv patient", "hcv patient", "nash patient", "oncology patient"  
                ],
                "response": "I cannot provide treatment recommendations for individual patients. Clinical decisions should be based on professional medical judgment, established clinical guidelines, and KITE product labeling."
            },
            {
                "keywords": [
                    "increase sales","increased sales", "sales increase","sales growth","increased by", "increased to" "boost prescriptions", "market share", "promote product",
                    "selling strategy", "commercial objective", "revenue", "prescription volume",
                    "market penetration", "competitive advantage", "sales target",
                    "promotional activity", "marketing campaign", "detailing",
                    "market access", "payer strategy", "formulary placement"  
                ],
                "response": "I cannot provide information that could be considered promotional or sales-driven. My role is limited to providing scientific and educational information in support of KITE's Medical Affairs mission."
            },
            {
                "keywords": [
                    "speaker fee", "consulting payment", "advisory board payment",
                    "hcp payment", "physician payment", "transfer of value",
                    "speaker bureau", "key opinion leader fee", "educational grant tied to sales",
                    "payment for prescriptions", "incentive payment", "sunshine act reporting"
                ],
                "response": "I cannot suggest arrangements that involve transfers of value to healthcare professionals. Please consult KITE's Compliance team regarding appropriate HCP engagement per KITE's Third Party Engagement policies."
            },
            {
                "keywords": [
                    "competitor data", "competitive analysis", "market intelligence",
                    "abbvie", "bristol myers squibb", "janssen", "merck", "pfizer",
                    "competitive product", "competitor pricing", "competitive strategy"
                ],
                "response": "I cannot provide competitive intelligence or analysis of competitor products. Please refer to publicly available information or contact KITE's Competitive Intelligence team."
            }
        ]
        
        logger.info("Chat Agent initialized successfully")
    
    def _check_keywords(self, question: str) -> Optional[str]:
        """
        Check if the question contains any restricted keywords
        
        Args:
            question: The user's question
            
        Returns:
            Response message if keywords found, None otherwise
        """
        question_lower = question.lower()
        
        for check in self.keyword_checks:
            for keyword in check["keywords"]:
                if keyword.lower() in question_lower:
                    logger.info(f"Keyword check triggered: '{keyword}' found in question")
                    return check["response"]
        
        return None
    
    def _initialize_llm_agent(self, aws_credentials: Optional[Dict[str, str]] = None) -> LLMAgent:
        """
        Initialize LLM agent based on configured provider
        
        Args:
            aws_credentials: AWS credentials (required for Bedrock)
            
        Returns:
            Initialized LLM agent
        """
        if config.llm.provider.lower() == "azure_openai":
            # Azure OpenAI doesn't need AWS credentials
            logger.info("Initializing LLM Agent with Azure OpenAI provider")
            return LLMAgent()
        elif config.llm.provider.lower() == "bedrock":
            # Bedrock requires AWS credentials
            logger.info("Initializing LLM Agent with AWS Bedrock provider")
            if not aws_credentials:
                raise ValueError("AWS credentials required for Bedrock provider")
            return LLMAgent(aws_credentials)
        else:
            raise ValueError(f"Unsupported LLM provider: {config.llm.provider}")
    

    def process_question(self, request: ChatRequest, aws_credentials: Optional[Dict[str, str]] = None) -> ChatResponse:
        """
        Main orchestration method for chat workflow
        Follows the exact chat workflow from the text diagram
        
        Args:
            request: ChatRequest containing the user's question and options
            aws_credentials: Optional AWS credentials (only required for Bedrock provider)
        """
        start_time = time.time()
        
        # Log agent input
        logger.info("=" * 80)
        logger.info("CHAT AGENT - INPUT")
        logger.info(f"Question: {request.question}")
        logger.info(f"Include Context: {request.include_context}")
        logger.info(f"Max Results: {request.max_results}")
        logger.info(f"LLM Provider: {config.llm.provider}")
        logger.info("=" * 80)
        
        # Step 0: Check cache first
        cached_response = self.cache_service.get_cached_response(request)
        if cached_response:
            cached_response.processing_time = time.time() - start_time
            cached_response.from_cache = True
            return cached_response
        
        # Step 1: Check for restricted keywords before any processing
        logger.info("Step 1: Checking for restricted keywords")
        keyword_response = self._check_keywords(request.question)
        if keyword_response:
            logger.info("Keyword check triggered - returning restricted response")
            response = ChatResponse(
                success=True,
                question=request.question,
                answer=keyword_response,
                processing_time=time.time() - start_time,
                error="Blocked keywords found",
            )
            # Cache the keyword response as well
            self.cache_service.cache_response(request, response)
            return response
        
        # Initialize response
        response = ChatResponse(
            success=False,
            question=request.question,
            answer="Processing your question..."
        )
        
        try:
            # Initialize LLM agent based on provider
            try:
                llm_agent = self._initialize_llm_agent(aws_credentials)
            except ValueError as e:
                return ChatResponse(
                    success=False,
                    question=request.question,
                    answer=f"LLM provider configuration error: {str(e)}",
                    error=str(e)
                )
            

            check_blocked_keywords = llm_agent.check_for_blocked_keywords(request.question)
            if check_blocked_keywords:
                response = ChatResponse(
                    success=True,
                    question=request.question,
                    answer=check_blocked_keywords,
                    error="Blocked keywords found",
                    processing_time=time.time() - start_time,
                )
                self.cache_service.cache_response(request, response)
                return response
            
            # Step 2: Connect to Neo4j
            logger.info("Step 2: Connecting to Neo4j database")
            if not self.neo4j_agent.connect():
                return ChatResponse(
                    success=False,
                    question=request.question,
                    answer="Cannot connect to the knowledge graph database. Please ensure the database is running and accessible.",
                    error="Neo4j connection failed"
                )
            
            # Step 3: Search vector database for context (if requested)
            vector_context = []
            if request.include_context:
                logger.info("Step 3: Searching vector database for relevant context")
                try:
                    vector_context = self.vector_service.similarity_search(
                        request.question, 
                        top_k=min(request.max_results, 5)  # Limit context for prompt efficiency
                    )
                    logger.info(f"Found {len(vector_context)} relevant context chunks")
                except Exception as e:
                    logger.warning(f"Vector search failed: {str(e)} - continuing without context")
                    vector_context = []
            else:
                logger.info("Step 3: Skipping vector search as context not requested")
            
            # Step 4: Get current database schema
            logger.info("Step 4: Retrieving current database schema")
            schema_info = self.neo4j_agent.fetch_schema_1()
            
            if not schema_info:
                return ChatResponse(
                    success=False,
                    question=request.question,
                    answer="The knowledge graph appears to be empty. Please upload some data first.",
                    error="Empty database schema"
                )
            
            logger.info(f"Retrieved schema with {schema_info}")
            
            # Step 5: Generate Cypher query using LLM
            logger.info("Step 5: Generating Cypher query with LLM")
            cypher_queries = llm_agent.generate_chat_query(
                request.question,
                vector_context,
                schema_info
            )
            
            if not cypher_queries:
                return ChatResponse(
                    success=False,
                    question=request.question,
                    answer="I couldn't generate a proper query for your question. Please try rephrasing it or being more specific.",
                    error="Cypher query generation failed"
                )
            
            logger.info(f"Generated Cypher query: {cypher_queries[0]}...")
            
            # Step 6: Execute Cypher query
            logger.info("Step 6: Executing Cypher query in Neo4j")
            query_results = []
            for query in cypher_queries:
                results = self.neo4j_agent.run_query(query)
                query_results.append(results)
            
            logger.info(f"Query execution completed - {len(query_results)} results returned")
            
            # Step 7: Summarize results using LLM
            logger.info("Step 7: Summarizing results with LLM")
            answer, publications_links, project_links = llm_agent.summarize_chat_response(
                request.question,
                query_results,
                cypher_queries,
                vector_context,
                schema_info
            )

            # Step 8: Check answer accuracy
            logger.info("Step 8: Checking answer accuracy")
            accuracy = llm_agent.check_answer_accuracy(
                request.question,
                answer,
                query_results,
                schema_info)
            logger.info(f"Answer accuracy: {accuracy}")
            # Calculate processing time
            processing_time = time.time() - start_time
  

            # --- Metrics update ---
            # If your LLM agent returns token usage, use those values. Otherwise, use 0 as placeholder.
            token_input = getattr(llm_agent, 'last_token_input', 0)
            token_output = getattr(llm_agent, 'last_token_output', 0)
            MetricsService.update_metrics(accuracy, processing_time, token_input, token_output)
            # --- End metrics update ---
            # --- API response time update ---
            MetricsService.update_api_response_time(processing_time)
            # --- End API response time update ---
            
            # Create successful response
            response = ChatResponse(
                success=True,
                question=request.question,
                answer=answer,
                publications_links=publications_links,
                project_links=project_links,
                sources=None,
                cypher_query=cypher_queries,
                result_count=len(query_results),
                processing_time=processing_time,
                accuracy=accuracy,
                from_cache=False
            )
            
            # Cache the successful response
            self.cache_service.cache_response(request, response)
            
            # Log agent output/response
            logger.info("=" * 80)
            logger.info("CHAT AGENT - OUTPUT")
            logger.info(f"Question: {request.question}")
            logger.info(f"Answer: {answer}")
            logger.info(f"Cypher Query: {cypher_queries}")
            logger.info(f"Results Found: {len(query_results)}")
            logger.info(f"Processing Time: {processing_time:.2f}s")
            logger.info("=" * 80)
            
        except Exception as e:
            error_msg = f"Chat processing failed: {str(e)}"
            logger.error(error_msg)
            response = ChatResponse(
                success=False,
                question=request.question,
                answer="I encountered an error while processing your question. Please try again or rephrase your question.",
                error=error_msg
            )
        
        finally:
            # Always disconnect from Neo4j
            self.neo4j_agent.disconnect()
        
        return response
    
