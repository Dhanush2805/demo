import time
from typing import Dict, Any, Optional
from app.core.logger import get_logger
from app.core.models import TextInsightsRequest, TextInsightsResponse
from app.services.config_service import config
from app.agents.llm_agent import LLMAgent

logger = get_logger('text_insights_agent')

class TextInsightsAgent:
    """
    Text Insights Agent for analyzing text content and extracting meaningful insights
    Uses LLM to perform various types of text analysis including entity extraction,
    sentiment analysis, topic identification, and more.
    """
    
    def __init__(self):
        """Initialize text insights agent"""
        logger.info("Initializing Text Insights Agent")
        logger.info("Text Insights Agent initialized successfully")
    
    def _initialize_llm_agent(self, aws_credentials: Optional[Dict[str, str]] = None) -> LLMAgent:
        """
        Initialize LLM agent based on configured provider
        
        Args:
            aws_credentials: AWS credentials for Bedrock (if needed)
            
        Returns:
            Initialized LLM agent
        """
        if config.llm.provider.lower() == "azure_openai":
            # Azure OpenAI doesn't need AWS credentials
            logger.info("Initializing LLM Agent with Azure OpenAI provider")
            return LLMAgent()
        elif config.llm.provider.lower() == "bedrock":
            # Bedrock requires AWS credentials
            logger.info("Initializing LLM Agent with AWS Bedrock provider")
            
            if not aws_credentials:
                raise ValueError("AWS credentials required for Bedrock provider but none provided")
            return LLMAgent(aws_credentials)
        else:
            raise ValueError(f"Unsupported LLM provider: {config.llm.provider}")
    
    def analyze_text(self, request: TextInsightsRequest) -> TextInsightsResponse:
        """
        Main text analysis workflow
        
        Args:
            request: Text insights request with text and analysis parameters
            
        Returns:
            TextInsightsResponse with comprehensive analysis results
        """
        start_time = time.time()
        logger.info(f"Starting text analysis for {len(request.text)} characters")
        
        try:
            # Step 1: Initialize LLM Agent
            logger.info("Step 1: Initializing LLM agent")
            
            try:
                if config.llm.provider.lower() == "bedrock":
                    if not request.aws_access_key_id or not request.aws_secret_access_key:
                        return TextInsightsResponse(
                            success=False,
                            message="AWS credentials are required for Bedrock provider. Please provide aws_access_key_id and aws_secret_access_key.",
                            error="Missing AWS credentials"
                        )
                    
                    # Create credentials for LLM
                    llm_credentials = {
                        'aws_access_key_id': request.aws_access_key_id,
                        'aws_secret_access_key': request.aws_secret_access_key,
                        'region_name': request.region_name
                    }
                    if request.aws_session_token:
                        llm_credentials['aws_session_token'] = request.aws_session_token
                    
                    llm_agent = self._initialize_llm_agent(aws_credentials=llm_credentials)
                else:
                    # Azure OpenAI doesn't need AWS credentials
                    llm_agent = self._initialize_llm_agent()
                    
            except ValueError as e:
                return TextInsightsResponse(
                    success=False,
                    message=str(e),
                    error=str(e)
                )
            
            # Step 2: Generate insights using LLM
            logger.info("Step 2: Generating meaningful points with LLM")
            insights = llm_agent.generate_text_insights(request.text)
            
            if not insights:
                return TextInsightsResponse(
                    success=False,
                    message="Failed to generate meaningful points from text",
                    error="LLM failed to generate insights"
                )
            
            # Step 3: Create response with enhanced structure
            logger.info("Step 3: Creating enhanced response with graph data")
            
            # Extract graph data if available
            html_code = None
            is_graph = False
            
            if insights.get('graph') and insights['graph'].get('html_code'):
                html_code = insights['graph']['html_code']
                is_graph = bool(html_code and html_code.strip())
                if is_graph:
                    logger.info("Graph HTML code extracted successfully")
            response = TextInsightsResponse(
                success=True,
                message="Text insights generated successfully with graph analysis",
                consolidated_insights=insights.get('consolidated_insights', ''),
                publications_links=insights.get('publications_links', []),
                is_graph=is_graph,
                html_code=html_code
            )
            
            logger.info("Enhanced text insights extraction completed successfully")
            return response
            
        except Exception as e:
            error_msg = f"Text analysis failed: {str(e)}"
            logger.error(error_msg)
            
            return TextInsightsResponse(
                success=False,
                message=error_msg,
                error=str(e)
            )
    

    
    def validate_request(self, request: TextInsightsRequest) -> Dict[str, Any]:
        """
        Validate text insights request
        
        Args:
            request: Text insights request to validate
            
        Returns:
            Dictionary with validation results
        """
        results = {
            'valid': True,
            'errors': [],
            'warnings': []
        }
        
        # Validate text content
        if not request.text or not request.text.strip():
            results['errors'].append("Text content cannot be empty")
        elif len(request.text) < 10:
            results['errors'].append("Text content must be at least 10 characters")
        elif len(request.text) > 50000:
            results['errors'].append("Text content cannot exceed 50000 characters")
        
        # Validate LLM provider requirements
        if config.llm.provider.lower() == "bedrock":
            if not request.aws_access_key_id:
                results['errors'].append("aws_access_key_id is required for Bedrock LLM provider")
            if not request.aws_secret_access_key:
                results['errors'].append("aws_secret_access_key is required for Bedrock LLM provider")
        
        if results['errors']:
            results['valid'] = False
        
        return results 