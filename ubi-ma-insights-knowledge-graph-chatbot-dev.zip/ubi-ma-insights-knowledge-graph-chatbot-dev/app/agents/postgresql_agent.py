import time
import psycopg2
import psycopg2.pool
from typing import List, Dict, Any, Optional, Union
from contextlib import contextmanager
from app.core.logger import get_logger
from app.core.models import PostgreSQLExecutionResult
from app.services.config_service import config
import uuid

logger = get_logger('postgresql_agent')

class PostgreSQLAgent:
    """
    PostgreSQL Agent for handling all database operations
    Provides connection pooling, query execution, and comprehensive error handling
    """
    
    def __init__(self):
        """Initialize PostgreSQL agent with configuration"""
        logger.info("Initializing PostgreSQL Agent")
        
        self.host = config.postgresql.host
        self.port = config.postgresql.port
        self.database = config.postgresql.database
        self.user = config.postgresql.user
        self.password = config.postgresql.password
        self.connection_timeout = config.postgresql.connection_timeout
        self.max_connections = config.postgresql.max_connections
        self.schema = config.postgresql.schema
        self.data_ingestion_schema = config.postgresql.data_ingestion_schema
        
        self.connection_pool = None
        
        logger.info(f"PostgreSQL Agent configured for: {self.host}:{self.port}/{self.database}")
    
    def connect(self) -> bool:
        """
        Create connection pool to PostgreSQL database with error handling
        Returns True if connection successful, False otherwise
        """
        try:
            logger.info(f"Creating PostgreSQL connection pool to {self.host}:{self.port}/{self.database}")
            
            self.connection_pool = psycopg2.pool.ThreadedConnectionPool(
                1,  # minimum connections
                self.max_connections,  # maximum connections
                host=self.host,
                port=self.port,
                database=self.database,
                user=self.user,
                password=self.password,
                connect_timeout=self.connection_timeout
            )
            
            # Test connection
            with self.get_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("SELECT 1 as test")
                    test_value = cursor.fetchone()[0]
                    
            if test_value == 1:
                logger.info("PostgreSQL connection pool established successfully")
                return True
            else:
                logger.error("PostgreSQL connection test failed")
                return False
                
        except Exception as e:
            logger.error(f"PostgreSQL connection failed: {str(e)}")
            return False
    
    def disconnect(self):
        """Close all connections in the pool"""
        if self.connection_pool:
            self.connection_pool.closeall()
            logger.info("PostgreSQL connection pool closed")
    
    @contextmanager
    def get_connection(self):
        """Context manager for getting connections from the pool"""
        connection = None
        try:
            connection = self.connection_pool.getconn()
            yield connection
        finally:
            if connection:
                self.connection_pool.putconn(connection)
    
    def execute_query(self, query: str, parameters: Optional[Dict] = None) -> PostgreSQLExecutionResult:
        """
        Execute a single SQL query with comprehensive error handling
        Returns detailed execution results
        """
        logger.info(f"Executing PostgreSQL query: {query[:100]}...")
        
        start_time = time.time()
        try:
            with self.get_connection() as conn:
                with conn.cursor() as cursor:
                    # Execute query with parameters
                    cursor.execute(query, parameters)
                    
                    execution_time = time.time() - start_time
                    
                    # Handle different query types
                    if cursor.description:
                        # SELECT query - fetch results
                        column_names = [desc[0] for desc in cursor.description]
                        rows = cursor.fetchall()
                        data = [dict(zip(column_names, row)) for row in rows]
                        
                        logger.info(f"Query executed successfully: {len(rows)} rows returned "
                                   f"in {execution_time:.3f}s")
                        
                        if query.strip().upper().startswith(("INSERT", "UPDATE", "DELETE")):
                            conn.commit()
                        
                        return PostgreSQLExecutionResult(
                            query=query,
                            success=True,
                            rows_returned=len(rows),
                            execution_time=execution_time,
                            column_names=column_names,
                            data=data
                        )
                    else:
                        # INSERT/UPDATE/DELETE query
                        rows_affected = cursor.rowcount
                        conn.commit()
                        
                        logger.info(f"Query executed successfully: {rows_affected} rows affected "
                                   f"in {execution_time:.3f}s")
                        
                        return PostgreSQLExecutionResult(
                            query=query,
                            success=True,
                            rows_affected=rows_affected,
                            execution_time=execution_time
                        )
                        
        except Exception as e:
            execution_time = time.time() - start_time
            logger.error(f"Query execution failed: {str(e)}")
            
            return PostgreSQLExecutionResult(
                query=query,
                success=False,
                execution_time=execution_time,
                error=str(e)
            )
    
    def execute_multiple_queries(self, queries: List[str], use_transaction: bool = True) -> Dict[str, Any]:
        """
        Execute multiple SQL queries with optional transaction support
        Returns comprehensive execution results
        """
        logger.info(f"Executing {len(queries)} PostgreSQL queries (transaction: {use_transaction})")
        
        results = {
            'successful': 0,
            'failed': 0,
            'total_rows_affected': 0,
            'total_rows_returned': 0,
            'query_results': [],
            'errors': []
        }
        
        try:
            with self.get_connection() as conn:
                with conn.cursor() as cursor:
                    if use_transaction:
                        cursor.execute("BEGIN")
                    
                    for i, query in enumerate(queries, 1):
                        if not query.strip():
                            logger.warning(f"Skipping empty query {i}")
                            continue
                        
                        execution_result = self._execute_single_query_with_cursor(cursor, query, i)
                        
                        if execution_result.success:
                            results['successful'] += 1
                            results['total_rows_affected'] += execution_result.rows_affected
                            results['total_rows_returned'] += execution_result.rows_returned
                        else:
                            results['failed'] += 1
                            results['errors'].append(f"Query {i}: {execution_result.error}")
                            
                            if use_transaction:
                                cursor.execute("ROLLBACK")
                                logger.error(f"Transaction rolled back due to query {i} failure")
                                break
                        
                        results['query_results'].append(execution_result)
                    
                    if use_transaction and results['failed'] == 0:
                        cursor.execute("COMMIT")
                        logger.info("Transaction committed successfully")
                        
        except Exception as e:
            logger.error(f"Multiple query execution failed: {str(e)}")
            results['errors'].append(f"Transaction error: {str(e)}")
        
        logger.info(f"Multiple query execution completed: {results['successful']} successful, "
                   f"{results['failed']} failed")
        return results
    
    def get_all_tables(self, schema: str = None):
        """
        Return all tables in schema with exact row and column counts.
        Also returns total table count.
        Optimized: gets column counts in one query, then exact row counts per table.
        """
        if schema is None:
            schema = self.schema

        try:
            # Step 1: Get all tables with column counts in a single query
            col_query = """
                SELECT table_name, COUNT(column_name) AS col_count
                FROM information_schema.columns
                WHERE table_schema = %s
                GROUP BY table_name
                ORDER BY table_name;
            """
            col_result = self.execute_query(col_query, (schema,))
            if not col_result.success:
                logger.error("Failed to fetch table and column info.")
                return {"tables": [], "table_count": 0}

            table_cols = {row["table_name"]: row["col_count"] for row in col_result.data}
            table_details = []

            # Step 2: Loop tables for exact row counts
            for table, col_count in table_cols.items():
                try:
                    row_query = f'SELECT COUNT(*) AS row_count FROM "{schema}"."{table}"'
                    row_result = self.execute_query(row_query)
                    row_count = row_result.data[0]["row_count"] if row_result.success else 0

                    table_details.append({
                         "id": str(uuid.uuid4()),
                        "name": table,
                        "rows": row_count,
                        "cols": col_count
                    })

                except Exception as inner_e:
                    logger.warning(f"Failed to fetch row count for table {table}: {inner_e}")
                    table_details.append({
                         "id": str(uuid.uuid4()),
                        "name": table,
                        "rows": 0,
                        "cols": col_count
                    })
            return table_details

        except Exception as e:
            logger.error(f"Failed to fetch table details: {e}")
            raise e
        
    def get_table_data(self, table_name: str, schema: str = None):
        """
        Return column metadata (name, isNull, dataType) for a given table
        """
        if schema is None:
            schema = self.schema

        try:
            query = """
                SELECT 
                    c.column_name AS name,
                    c.column_default AS "default",
                    CASE
                        WHEN c.data_type = 'character varying' THEN 
                            'varchar' || COALESCE('(' || c.character_maximum_length || ')', '')
                        WHEN c.data_type = 'character' THEN 
                            'char' || COALESCE('(' || c.character_maximum_length || ')', '')
                        WHEN c.data_type = 'timestamp without time zone' THEN 
                            'timestamp'
                        WHEN c.data_type = 'timestamp with time zone' THEN 
                            'timestamptz'
                        WHEN c.data_type = 'time without time zone' THEN 
                            'time'
                        WHEN c.data_type = 'time with time zone' THEN 
                            'timetz'
                        WHEN c.data_type = 'numeric' THEN 
                            'numeric' || COALESCE('(' || c.numeric_precision || 
                                    COALESCE(',' || c.numeric_scale, '') || ')', '')
                        ELSE c.data_type
                    END AS "dataType",
                    (c.is_nullable = 'YES') AS "isNullable",
                    COALESCE(pgd.description, '') AS comment
                FROM information_schema.columns c
                LEFT JOIN pg_catalog.pg_statio_all_tables st ON (
                    c.table_schema = st.schemaname AND 
                    c.table_name = st.relname
                )
                LEFT JOIN pg_catalog.pg_description pgd ON (
                    pgd.objoid = st.relid AND 
                    pgd.objsubid = c.ordinal_position
                )
                WHERE c.table_schema = %s AND c.table_name = %s
                ORDER BY c.ordinal_position;
            """
            result = self.execute_query(query, (schema, table_name))

            if not result.success:
                logger.error(f"Failed to fetch column metadata for table {table_name}")
                return []

            columns = [
                {
                    "name": row["name"],
                    "isNull": bool(row["isNullable"]),
                    "dataType": row["dataType"],
                    "default": row["default"],
                    "comment": row["comment"] or ""
                }
                for row in result.data
            ]

            return columns

        except Exception as e:
            logger.error(f"Error fetching column metadata for table {table_name}: {str(e)}")
            raise e
    
    def get_table_comment(self, table_name: str, schema: str = None) -> str:
        """
        Get table comment/description
        """
        if schema is None:
            schema = self.schema

        try:
            query = """
                SELECT COALESCE(obj_description(c.oid), '') AS table_comment
                FROM pg_catalog.pg_class c
                JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
                WHERE n.nspname = %s AND c.relname = %s AND c.relkind = 'r';
            """
            result = self.execute_query(query, (schema, table_name))

            if not result.success or not result.data:
                return ""

            return result.data[0]["table_comment"] or ""
            
        except Exception as e:
            logger.error(f"Failed to fetch table comment for {table_name}: {e}")
            return ""


postgresql_agent = PostgreSQLAgent() 

def init_db_connection():
    """Initialize database connection"""
    success = postgresql_agent.connect()
    if not success:
        logger.error("Failed to connect to PostgreSQL database")
        raise Exception("Database connection failed")