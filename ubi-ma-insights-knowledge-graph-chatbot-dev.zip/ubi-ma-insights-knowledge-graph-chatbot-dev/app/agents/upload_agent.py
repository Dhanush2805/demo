import time
import os
from typing import Dict, Any, Optional
from app.core.logger import get_logger
from app.core.models import S3UploadRequest, LocalUploadRequest, UploadResponse, FileInfo
from app.services.config_service import config
from app.agents.s3_agent import S3Agent
from app.agents.local_file_agent import LocalFileAgent
from app.agents.processing_agent import ProcessingAgent
from app.agents.llm_agent import LLMAgent
from app.agents.neo4j_agent import Neo4jAgent
from app.services.vector_service import VectorService

logger = get_logger('upload_agent')

class UploadAgent:
    """
    Upload Agent - Main orchestrator for the upload workflow
    Coordinates S3Agent, ProcessingAgent, LLMAgent, and Neo4jAgent
    Implements the agentic workflow from the text diagram
    """
    
    def __init__(self):
        """Initialize upload agent"""
        logger.info("Initializing Upload Agent")
        self.neo4j_agent = Neo4jAgent()
        logger.info("Upload Agent initialized successfully")
    
    def _initialize_llm_agent(self, aws_credentials: Optional[Dict[str, str]] = None, 
                            request_aws_credentials: Optional[Dict[str, str]] = None) -> LLMAgent:
        """
        Initialize LLM agent based on configured provider
        
        Args:
            aws_credentials: AWS credentials from config/environment
            request_aws_credentials: AWS credentials from request (for S3 access)
            
        Returns:
            Initialized LLM agent
        """
        if config.llm.provider.lower() == "azure_openai":
            # Azure OpenAI doesn't need AWS credentials
            logger.info("Initializing LLM Agent with Azure OpenAI provider")
            return LLMAgent()
        elif config.llm.provider.lower() == "bedrock":
            # Bedrock requires AWS credentials
            logger.info("Initializing LLM Agent with AWS Bedrock provider")
            
            # Try to use available credentials
            credentials = aws_credentials or request_aws_credentials
            if not credentials:
                raise ValueError("AWS credentials required for Bedrock provider but none available")
            return LLMAgent(credentials)
        else:
            raise ValueError(f"Unsupported LLM provider: {config.llm.provider}")
    
    def process_s3_upload(self, request: S3UploadRequest) -> UploadResponse:
        """
        Main orchestration method for S3 upload workflow
        Follows the exact workflow from the text diagram
        """
        start_time = time.time()
        logger.info(f"Starting upload workflow for S3 URL: {request.s3_url}")
        
        # Initialize response
        response = UploadResponse(
            success=False,
            message="Upload workflow started"
        )
        
        try:
            # Get AWS credentials (may be None for public access)
            aws_credentials = config.get_aws_credentials(
                request.aws_access_key_id,
                request.aws_secret_access_key,
                request.aws_session_token,
                request.region_name
            )
            
            # Step 1: Initialize all agents
            logger.info("Step 1: Initializing agents")
            
            # S3 Agent can work with or without credentials (public vs authenticated)
            s3_agent = S3Agent(aws_credentials)
            
            # Initialize LLM Agent based on provider
            try:
  
                # For Bedrock without pre-configured credentials, use request credentials
                if config.llm.provider.lower() == "bedrock":
                    if not request.aws_access_key_id or not request.aws_secret_access_key:
                        return UploadResponse(
                            success=False,
                            message="AWS credentials are required for Bedrock provider. Please provide aws_access_key_id and aws_secret_access_key."
                        )
                    # Create credentials specifically for LLM
                    llm_credentials = {
                        'aws_access_key_id': request.aws_access_key_id,
                        'aws_secret_access_key': request.aws_secret_access_key,
                        'region_name': request.region_name
                    }
                    if request.aws_session_token:
                        llm_credentials['aws_session_token'] = request.aws_session_token
                    llm_agent = self._initialize_llm_agent(request_aws_credentials=llm_credentials)
                else:
                    # Azure OpenAI doesn't need AWS credentials
                    llm_agent = self._initialize_llm_agent()
                    
            except ValueError as e:
                return UploadResponse(
                    success=False,
                    message=str(e)
                )
            
            # Step 2: Connect to Neo4j
            logger.info("Step 2: Connecting to Neo4j database")
            if not self.neo4j_agent.connect():
                return UploadResponse(
                    success=False,
                    message="Failed to connect to Neo4j database"
                )
            
            # Step 3: Validate S3 access
            logger.info("Step 3: Validating S3 access")
            if not s3_agent.validate_s3_access(str(request.s3_url)):
                return UploadResponse(
                    success=False,
                    message="Cannot access the provided S3 URL"
                )
            
            # Step 4: Optimized S3 processing (CSV direct, Excel download)
            logger.info("Step 4: Optimized S3 file processing")
            s3_processing_results = s3_agent.process_s3_files_optimized(str(request.s3_url))
            
            if not s3_processing_results['files_info']:
                return UploadResponse(
                    success=False,
                    message="No supported files found or processed from S3",
                    errors=s3_processing_results.get('errors', [])
                )
            
            logger.info(f"✅ S3 Processing: {s3_processing_results['total_csv_direct']} CSVs direct, "
                       f"{s3_processing_results['total_excel_converted']} Excel converted")
            
            # Step 5: Create vectors
            if request.create_vectors:
                logger.info("Step 8: Creating vector embeddings")
                vector_stats = VectorService().create_csv_vectors(s3_processing_results["csv_files_direct"])
                vector_chunks_created = vector_stats.get('total_chunks', 0)
            else:
                logger.info("Step 7: Skipping vector creation as requested")
            
            # Prepare processing results in expected format
            processing_results = {
                'files_processed': len(s3_processing_results['files_info']),
                'total_rows': sum(f.row_count for f in s3_processing_results['files_info']),
                'files_info': s3_processing_results['files_info'],
                'vector_stats': vector_stats,
                'errors': s3_processing_results.get('errors', [])
            }
            
            # if not processing_results['files_info']:
            #     return UploadResponse(
            #         success=False,
            #         message="No files could be processed successfully",
            #         errors=processing_results.get('errors', [])
            #     )
            
            # logger.info(f"Processed {processing_results['files_processed']} files, "
                    #    f"created {processing_results.get('vector_stats', {}).get('total_chunks', 0)} vector chunks")
                    
            # Get current schema before processing this file
            logger.info("Step 5.1: Getting current database schema")
            current_schema = self.neo4j_agent.fetch_schema()
                
            # Step 6: Generate Cypher queries using LLM
            logger.info("Step 6: Generating Cypher queries with LLM")
            cypher_queries = llm_agent.generate_cypher_queries_with_schema(processing_results['files_info'], current_schema=current_schema)
            if not cypher_queries:
                return UploadResponse(
                    success=False,
                    message="Failed to generate valid Cypher queries"
                )
            
            logger.info(f"Generated {len(cypher_queries)} Cypher queries")
            
            # # Step 7: Clear existing database (optional - can be configured)
            # logger.info("Step 7: Clearing existing Neo4j data")
            # clear_results = self.neo4j_agent.clear_database()
            # logger.info(f"Cleared {clear_results.get('nodes_deleted', 0)} nodes, "
            #            f"{clear_results.get('relationships_deleted', 0)} relationships")
            

            # Step 8: Execute Cypher queries
            logger.info("Step 8: Executing Cypher queries in Neo4j")
            execution_results = self.neo4j_agent.execute_cypher_queries(cypher_queries)
            
            # Step 9: Get final schema information
            logger.info("Step 9: Retrieving final database schema")
            schema_info = self.neo4j_agent.fetch_schema()
            
            # Step 10: Cleanup temporary files (only Excel converted files)
            # logger.info("Step 10: Cleaning up temporary files")
            # if s3_processing_results['excel_files_downloaded']:
            #     s3_agent.cleanup_temp_files(s3_processing_results['excel_files_downloaded'])
            # logger.info("✅ CSV files loaded directly from S3 (no cleanup needed)")
            
            # Calculate processing time
            processing_time = time.time() - start_time
            
            # Prepare final response
            response = UploadResponse(
                success=True,
                message=f"Knowledge graph created successfully in {processing_time:.2f} seconds",
                files_processed=processing_results['files_processed'],
                total_rows=processing_results['total_rows'],
                nodes_created=execution_results['total_nodes'],
                relationships_created=execution_results['total_relationships'],
                vector_chunks_created=processing_results.get('vector_stats', {}).get('total_chunks', 0),
                schema_info=schema_info,
                errors=execution_results.get('errors', [])
            )
            
            logger.info(f"Upload workflow completed successfully: "
                       f"{response.files_processed} files, "
                       f"{response.nodes_created} nodes, "
                       f"{response.relationships_created} relationships")
            
        except Exception as e:
            error_msg = f"Upload workflow failed: {str(e)}"
            logger.error(error_msg)
            response = UploadResponse(
                success=False,
                message=error_msg
            )
        
        finally:
            # Always disconnect from Neo4j
            self.neo4j_agent.disconnect()
        
        return response

    def process_s3_upload_iterative(self, request: S3UploadRequest) -> UploadResponse:
        """
        NEW: Iterative S3 file processing method - processes files one by one
        sharing schema information between iterations to create relations to existing data
        """
        start_time = time.time()
        logger.info(f"Starting ITERATIVE S3 upload workflow for URL: {request.s3_url}")
        
        # Initialize response
        response = UploadResponse(
            success=False,
            message="Iterative S3 upload workflow started"
        )
        
        # Tracking variables for all iterations
        total_files_processed = 0
        total_rows_processed = 0
        total_nodes_created = 0
        total_relationships_created = 0
        total_vector_chunks = 0
        all_errors = []
        
        try:
            # Prepare AWS credentials dictionary
            aws_credentials = {
                'aws_access_key_id': request.aws_access_key_id,
                'aws_secret_access_key': request.aws_secret_access_key,
                'aws_session_token': request.aws_session_token,
                'region_name': request.region_name
            }
            
            # Remove None values to avoid issues with boto3
            aws_credentials = {k: v for k, v in aws_credentials.items() if v is not None}
            
            # Step 1: Initialize all agents
            logger.info("Step 1: Initializing agents")
            s3_agent = S3Agent(aws_credentials)
            processing_agent = ProcessingAgent()
            
            try:
                llm_agent = self._initialize_llm_agent(aws_credentials=aws_credentials)
            except ValueError as e:
                return UploadResponse(
                    success=False,
                    message=str(e)
                )
            
            # Step 2: Connect to Neo4j
            logger.info("Step 2: Connecting to Neo4j database")
            if not self.neo4j_agent.connect():
                return UploadResponse(
                    success=False,
                    message="Failed to connect to Neo4j database"
                )
            
            # Step 3: Parse S3 URL and bucket info
            logger.info("Step 3: Parsing S3 URL and discovering files")
            bucket_info = s3_agent.parse_s3_url(str(request.s3_url))
            if not bucket_info:
                return UploadResponse(
                    success=False,
                    message="Invalid S3 URL provided"
                )
            
            # Step 4: Download files from S3
            logger.info("Step 4: Downloading files from S3")
            downloaded_files = s3_agent.download_files(
                bucket_info['bucket'], 
                bucket_info['prefix']
            )
            
            if not downloaded_files:
                return UploadResponse(
                    success=False,
                    message="No supported files found or downloaded from S3"
                )
            
            logger.info(f"Downloaded {len(downloaded_files)} files from S3")
            
            # Step 5: Process files one by one iteratively
            for file_index, downloaded_file in enumerate(downloaded_files, 1):
                logger.info(f"========= PROCESSING FILE {file_index}/{len(downloaded_files)}: {downloaded_file} =========")
                
                # Get current schema before processing this file
                logger.info(f"Step 5.{file_index}.1: Getting current database schema")
                current_schema = self.neo4j_agent.fetch_schema()
                
                # Process single file
                logger.info(f"Step 5.{file_index}.2: Processing file {file_index}")
                processing_results = processing_agent.process_files([downloaded_file])
                
                if not processing_results['files_info']:
                    error_msg = f"File {file_index} could not be processed"
                    logger.error(error_msg)
                    all_errors.append(error_msg)
                    continue
                
                # Generate Cypher queries with current schema context
                logger.info(f"Step 5.{file_index}.3: Generating Cypher queries with schema context")
                cypher_queries = llm_agent.generate_cypher_queries_with_schema(
                    processing_results['files_info'], 
                    current_schema
                )
                
                if not cypher_queries:
                    error_msg = f"Failed to generate valid Cypher queries for file {file_index}"
                    logger.error(error_msg)
                    all_errors.append(error_msg)
                    continue
                
                logger.info(f"Generated {len(cypher_queries)} Cypher queries for file {file_index}")
                
                # Execute queries for this file
                logger.info(f"Step 5.{file_index}.4: Executing Cypher queries")
                execution_results = self.neo4j_agent.execute_cypher_queries(cypher_queries)
                
                # Update totals
                total_files_processed += processing_results['files_processed']
                total_rows_processed += processing_results['total_rows']
                total_nodes_created += execution_results['total_nodes']
                total_relationships_created += execution_results['total_relationships']
                total_vector_chunks += processing_results.get('vector_stats', {}).get('total_chunks', 0)
                
                if execution_results.get('errors'):
                    all_errors.extend(execution_results['errors'])
                
                logger.info(f"File {file_index} completed: "
                           f"{execution_results['total_nodes']} nodes, "
                           f"{execution_results['total_relationships']} relationships created")
                
                # Get updated schema after processing this file
                logger.info(f"Step 5.{file_index}.5: Schema after processing file {file_index}")
                updated_schema = self.neo4j_agent.fetch_schema()
                logger.info(f"Current database now has {len(updated_schema.get('nodes', {}))} node types, "
                           f"{len(updated_schema.get('relationships', []))} relationship types")

            # Step 6: Get final schema information
            logger.info("Step 6: Retrieving final database schema")
            final_schema_info = self.neo4j_agent.fetch_schema()

            # Step 7: Cleanup temporary files
            logger.info("Step 7: Cleaning up temporary files")
            s3_agent.cleanup_temp_files(downloaded_files)
            
            # Calculate processing time
            processing_time = time.time() - start_time
            
            # Prepare final response
            response = UploadResponse(
                success=True,
                message=f"Iterative knowledge graph created successfully from {total_files_processed} files in {processing_time:.2f} seconds",
                files_processed=total_files_processed,
                total_rows=total_rows_processed,
                nodes_created=total_nodes_created,
                relationships_created=total_relationships_created,
                vector_chunks_created=total_vector_chunks,
                schema_info=final_schema_info,
                errors=all_errors if all_errors else None
            )
            
            logger.info(f"Iterative S3 upload workflow completed successfully: "
                       f"{response.files_processed} files, "
                       f"{response.nodes_created} nodes, "
                       f"{response.relationships_created} relationships")
            
        except Exception as e:
            error_msg = f"Iterative S3 upload workflow failed: {str(e)}"
            logger.error(error_msg)
            response = UploadResponse(
                success=False,
                message=error_msg
            )
        
        finally:
            # Always disconnect from Neo4j
            self.neo4j_agent.disconnect()
        
        return response
    
    def validate_s3_upload_request(self, request: S3UploadRequest) -> Dict[str, Any]:
        """
        Validate S3 upload request before processing
        Returns validation results with file discovery
        """
        logger.info(f"Validating S3 upload request for URL: {request.s3_url}")
        
        validation_results = {
            'valid': False,
            'errors': [],
            'warnings': [],
            'file_info': None
        }
        
        try:
            # Prepare AWS credentials dictionary
            aws_credentials = {
                'aws_access_key_id': request.aws_access_key_id,
                'aws_secret_access_key': request.aws_secret_access_key,
                'aws_session_token': request.aws_session_token,
                'region_name': request.region_name
            }
            
            # Remove None values
            aws_credentials = {k: v for k, v in aws_credentials.items() if v is not None}
            
            # Initialize S3 agent
            s3_agent = S3Agent(aws_credentials)
            
            # Parse S3 URL
            bucket_info = s3_agent.parse_s3_url(str(request.s3_url))
            if not bucket_info:
                validation_results['errors'].append("Invalid S3 URL format")
                return validation_results
            
            # Test S3 connection and file discovery
            file_list = s3_agent.discover_files(bucket_info['bucket'], bucket_info['prefix'])
            
            if not file_list:
                validation_results['errors'].append("No supported files found in S3 location")
                return validation_results
            
            validation_results['file_info'] = {
                'bucket': bucket_info['bucket'],
                'prefix': bucket_info['prefix'],
                'files_found': file_list,
                'total_files': len(file_list),
                'total_size_mb': sum(f.get('size_mb', 0) for f in file_list)
            }
            
            # Size warnings
            total_size_mb = validation_results['file_info']['total_size_mb']
            if total_size_mb > 1000:  # 1GB warning threshold for S3
                validation_results['warnings'].append(
                    f"Large total file size: {total_size_mb:.1f}MB"
                )
            
            # Validate Neo4j connection
            if not self.neo4j_agent.connect():
                validation_results['errors'].append("Cannot connect to Neo4j database")
                return validation_results
            
            self.neo4j_agent.disconnect()
            
            # If we get here, validation passed
            validation_results['valid'] = True
            logger.info(f"S3 upload request validation passed - {len(file_list)} files available")
            
        except Exception as e:
            validation_results['errors'].append(f"S3 validation error: {str(e)}")
            logger.error(f"S3 validation failed: {str(e)}")
        
        return validation_results
     
    def process_local_upload(self, request: LocalUploadRequest) -> UploadResponse:
        """
        Main orchestration method for local file upload workflow
        Similar to S3 workflow but for local files
        """
        start_time = time.time()
        logger.info(f"Starting local upload workflow for {len(request.file_paths)} files")
        
        # Initialize response
        response = UploadResponse(
            success=False,
            message="Local upload workflow started"
        )
        
        try:
            # Get AWS credentials from environment/configuration
            aws_credentials = config.get_aws_credentials_from_env()
            
            # Check if we have the required credentials for the configured LLM provider
            if config.llm.provider.lower() == "bedrock" and not aws_credentials:
                return UploadResponse(
                    success=False,
                    message="AWS credentials not configured for Bedrock provider. Please set AWS credentials in environment variables."
                )
            
            # Step 1: Initialize all agents
            logger.info("Step 1: Initializing agents")
            local_file_agent = LocalFileAgent()
            processing_agent = ProcessingAgent()
            
            try:
                llm_agent = self._initialize_llm_agent(aws_credentials=aws_credentials)
            except ValueError as e:
                return UploadResponse(
                    success=False,
                    message=str(e)
                )
            
            # Step 2: Connect to Neo4j
            logger.info("Step 2: Connecting to Neo4j database")
            if not self.neo4j_agent.connect():
                return UploadResponse(
                    success=False,
                    message="Failed to connect to Neo4j database"
                )
            
            # Step 3: Validate local file paths
            logger.info("Step 3: Validating local file paths")
            validation_results = local_file_agent.validate_file_paths(request.file_paths)
            if not validation_results['valid']:
                return UploadResponse(
                    success=False,
                    message="File validation failed",
                    errors=validation_results['errors']
                )
            
            # Step 4: Copy files to temp directory
            logger.info("Step 4: Copying files to temp directory")
            temp_files = local_file_agent.copy_files_to_temp(request.file_paths)
            if not temp_files:
                return UploadResponse(
                    success=False,
                    message="No files could be copied for processing"
                )
            
            logger.info(f"Copied {len(temp_files)} files to temp directory")
            
            # Step 5: Process files (convert, analyze, optionally create vectors)
            if request.create_vectors:
                logger.info("Step 5: Processing files and creating vectors")
                processing_results = processing_agent.process_files(temp_files)
            else:
                logger.info("Step 5: Processing files (skipping vector creation)")
                processing_results = processing_agent.process_files_without_vectors(temp_files)
            
            if not processing_results['files_info']:
                return UploadResponse(
                    success=False,
                    message="No files could be processed successfully",
                    errors=processing_results.get('errors', [])
                )
            
            if request.create_vectors:
                logger.info(f"Processed {processing_results['files_processed']} files, "
                           f"created {processing_results.get('vector_stats', {}).get('total_chunks', 0)} vector chunks")
            else:
                logger.info(f"Processed {processing_results['files_processed']} files (vectors skipped)")
            
            # Step 6: Generate Cypher queries using LLM
            logger.info("Step 6: Generating Cypher queries with LLM")
            cypher_queries = llm_agent.generate_cypher_queries(processing_results['files_info'])

            if not cypher_queries:
                return UploadResponse(
                    success=False,
                    message="Failed to generate valid Cypher queries"
                )
            # Step 7: Execute Cypher queries
            logger.info("Step 7: Executing Cypher queries in Neo4j")
            execution_results = self.neo4j_agent.execute_cypher_queries(cypher_queries)

            # Step 8: Get final schema information
            logger.info("Step 8: Retrieving final database schema")
            schema_info = self.neo4j_agent.fetch_schema()

            # Step 9: Cleanup temporary files
            logger.info("Step 9: Cleaning up temporary files")
            local_file_agent.cleanup_temp_files(temp_files)
            
            # Calculate processing time
            processing_time = time.time() - start_time
            
            # Prepare final response
            response = UploadResponse(
                success=True,
                message=f"Knowledge graph created successfully from local files in {processing_time:.2f} seconds",
                files_processed=processing_results['files_processed'],
                total_rows=processing_results['total_rows'],
                nodes_created=execution_results['total_nodes'],
                relationships_created=execution_results['total_relationships'],
                vector_chunks_created=processing_results.get('vector_stats', {}).get('total_chunks', 0),
                schema_info=schema_info,
                errors=execution_results.get('errors', [])
            )
            
            logger.info(f"Local upload workflow completed successfully: "
                       f"{response.files_processed} files, "
                       f"{response.nodes_created} nodes, "
                       f"{response.relationships_created} relationships")
            
        except Exception as e:
            error_msg = f"Local upload workflow failed: {str(e)}"
            logger.error(error_msg)
            response = UploadResponse(
                success=False,
                message=error_msg
            )
        
        finally:
            # Always disconnect from Neo4j
            self.neo4j_agent.disconnect()
        
        return response
    
    def validate_local_upload_request(self, request: LocalUploadRequest) -> Dict[str, Any]:
        """
        Validate local upload request before processing
        Returns validation results
        """
        logger.info(f"Validating local upload request for {len(request.file_paths)} files")
        
        validation_results = {
            'valid': False,
            'errors': [],
            'warnings': [],
            'file_info': None
        }
        
        try:
            # Validate local file paths
            local_file_agent = LocalFileAgent()
            file_validation = local_file_agent.validate_file_paths(request.file_paths)
            
            if not file_validation['valid']:
                validation_results['errors'].extend(file_validation['errors'])
                return validation_results
            
            validation_results['file_info'] = file_validation
            
            # Check file size warnings
            total_size = sum(file['size'] for file in file_validation['files_found'])
            total_size_mb = total_size / (1024 * 1024)
            
            if total_size_mb > 500:  # 500MB warning threshold
                validation_results['warnings'].append(
                    f"Large total file size: {total_size_mb:.1f}MB"
                )
            
            # Validate Neo4j connection
            if not self.neo4j_agent.connect():
                validation_results['errors'].append("Cannot connect to Neo4j database")
                return validation_results
            
            self.neo4j_agent.disconnect()
            
            # If we get here, validation passed
            validation_results['valid'] = True
            logger.info(f"Local upload request validation passed - {len(file_validation['files_found'])} files available")
            
        except Exception as e:
            error_msg = f"Validation error: {str(e)}"
            logger.error(error_msg)
            validation_results['errors'].append(error_msg)
        
        return validation_results
    
    def get_upload_status(self) -> Dict[str, Any]:
        """
        Get current status of upload system
        Returns information about database, vector store, etc.
        """
        logger.info("Getting upload system status")
        
        try:
            # Check Neo4j connection
            neo4j_connected = self.neo4j_agent.connect()
            if neo4j_connected:
                db_stats = self.neo4j_agent.get_database_stats()
                schema_info = self.neo4j_agent.fetch_schema()
                self.neo4j_agent.disconnect()
            else:
                db_stats = {'error': 'Cannot connect to Neo4j'}
                schema_info = {}
            
            # Check processing agent status
            processing_agent = ProcessingAgent()
            processing_stats = processing_agent.get_processing_stats()
            
            status = {
                'neo4j_connected': neo4j_connected,
                'database_stats': db_stats,
                'schema_info': schema_info,
                'processing_stats': processing_stats,
                'timestamp': time.time()
            }
            
            logger.info(f"Upload system status retrieved - Neo4j connected: {neo4j_connected}")
            return status
            
        except Exception as e:
            logger.error(f"Error getting upload status: {str(e)}")
            return {
                'error': str(e),
                'timestamp': time.time()
            }
    
    def validate_upload_request(self, request: S3UploadRequest) -> Dict[str, Any]:
        """
        Validate upload request before processing
        Returns validation results
        """
        logger.info(f"Validating upload request for S3 URL: {request.s3_url}")
        
        validation_results = {
            'valid': False,
            'errors': [],
            'warnings': [],
            's3_info': None
        }
        
        try:
            # Get AWS credentials (may be None for public access)
            aws_credentials = config.get_aws_credentials(
                request.aws_access_key_id,
                request.aws_secret_access_key,
                request.aws_session_token,
                request.region_name
            )
            
            # Validate S3 access (works with or without credentials)
            s3_agent = S3Agent(aws_credentials)
            if not s3_agent.validate_s3_access(str(request.s3_url)):
                validation_results['errors'].append("Cannot access the provided S3 URL")
                return validation_results
            
            # Get S3 information
            s3_info = s3_agent.get_s3_info(str(request.s3_url))
            if 'error' in s3_info:
                validation_results['errors'].append(f"S3 error: {s3_info['error']}")
                return validation_results
            
            validation_results['s3_info'] = s3_info
            
            # Validate file availability
            if s3_info['total_files'] == 0:
                validation_results['errors'].append("No supported files found in S3 location")
                return validation_results
            
            # Check file size warnings
            if s3_info['total_size_mb'] > 500:  # 500MB warning threshold
                validation_results['warnings'].append(
                    f"Large total file size: {s3_info['total_size_mb']:.1f}MB"
                )
            
            # Validate Neo4j connection
            if not self.neo4j_agent.connect():
                validation_results['errors'].append("Cannot connect to Neo4j database")
                return validation_results
            
            self.neo4j_agent.disconnect()
            
            # If we get here, validation passed
            validation_results['valid'] = True
            logger.info(f"Upload request validation passed - {s3_info['total_files']} files available")
            
        except Exception as e:
            error_msg = f"Validation error: {str(e)}"
            logger.error(error_msg)
            validation_results['errors'].append(error_msg)
        
        return validation_results
    
    def cleanup_upload_data(self) -> Dict[str, Any]:
        """
        Clean up all upload-related data (database, vectors, files)
        Use with caution - this deletes all data
        """
        logger.info("Starting cleanup of all upload data")
        
        cleanup_results = {
            'database_cleared': False,
            'vectors_cleared': False,
            'files_cleared': False,
            'errors': []
        }
        
        try:
            # Clear Neo4j database
            if self.neo4j_agent.connect():
                clear_results = self.neo4j_agent.clear_database()
                cleanup_results['database_cleared'] = True
                logger.info(f"Database cleared: {clear_results}")
                self.neo4j_agent.disconnect()
            
            # Clear processing files and vectors
            processing_agent = ProcessingAgent()
            processing_agent.cleanup_processed_files()
            cleanup_results['vectors_cleared'] = True
            cleanup_results['files_cleared'] = True
            
            logger.info("Cleanup completed successfully")
            
        except Exception as e:
            error_msg = f"Cleanup error: {str(e)}"
            logger.error(error_msg)
            cleanup_results['errors'].append(error_msg)
        
        return cleanup_results

    def process_local_upload_iterative(self, request: LocalUploadRequest) -> UploadResponse:
        """
        NEW: Iterative file processing method - processes files one by one
        sharing schema information between iterations to create relations to existing data
        """
        start_time = time.time()
        logger.info(f"Starting ITERATIVE local upload workflow for {len(request.file_paths)} files")
        
        # Initialize response
        response = UploadResponse(
            success=False,
            message="Iterative local upload workflow started"
        )
        
        # Tracking variables for all iterations
        total_files_processed = 0
        total_rows_processed = 0
        total_nodes_created = 0
        total_relationships_created = 0
        total_vector_chunks = 0
        all_errors = []
        
        try:
            # Get AWS credentials from environment/configuration
            aws_credentials = config.get_aws_credentials_from_env()
            
            # Check credentials based on LLM provider
            if config.llm.provider.lower() == "bedrock" and not aws_credentials:
                return UploadResponse(
                    success=False,
                    message="AWS credentials required for Bedrock provider. Please set AWS credentials in environment variables."
                )
            
            # Step 1: Initialize all agents
            logger.info("Step 1: Initializing agents")
            local_file_agent = LocalFileAgent()
            processing_agent = ProcessingAgent()
            
            try:
                llm_agent = self._initialize_llm_agent(aws_credentials=aws_credentials)
            except ValueError as e:
                return UploadResponse(
                    success=False,
                    message=str(e)
                )
            
            # Step 2: Connect to Neo4j
            logger.info("Step 2: Connecting to Neo4j database")
            if not self.neo4j_agent.connect():
                return UploadResponse(
                    success=False,
                    message="Failed to connect to Neo4j database"
                )
            
            # Step 3: Validate local file paths
            logger.info("Step 3: Validating local file paths")
            validation_results = local_file_agent.validate_file_paths(request.file_paths)
            if not validation_results['valid']:
                return UploadResponse(
                    success=False,
                    message="File validation failed",
                    errors=validation_results['errors']
                )
            
            # Step 4: Copy files to temp directory
            logger.info("Step 4: Copying files to temp directory")
            temp_files = local_file_agent.copy_files_to_temp(request.file_paths)
            if not temp_files:
                return UploadResponse(
                    success=False,
                    message="No files could be copied for processing"
                )
            
            logger.info(f"Copied {len(temp_files)} files to temp directory")
            
            # Step 5: Process files one by one iteratively
            for file_index, temp_file in enumerate(temp_files, 1):
                logger.info(f"========= PROCESSING FILE {file_index}/{len(temp_files)}: {temp_file} =========")
                
                # Get current schema before processing this file
                logger.info(f"Step 5.{file_index}.1: Getting current database schema")
                current_schema = self.neo4j_agent.fetch_schema()
                
                # Process single file
                logger.info(f"Step 5.{file_index}.2: Processing file {file_index}")
                if request.create_vectors:
                    processing_results = processing_agent.process_files([temp_file])
                else:
                    processing_results = processing_agent.process_files_without_vectors([temp_file])
                
                if not processing_results['files_info']:
                    error_msg = f"File {file_index} could not be processed"
                    logger.error(error_msg)
                    all_errors.append(error_msg)
                    continue
                
                # Generate Cypher queries with current schema context
                logger.info(f"Step 5.{file_index}.3: Generating Cypher queries with schema context")
                cypher_queries = llm_agent.generate_cypher_queries_with_schema(
                    processing_results['files_info'], 
                    current_schema
                )
                
                if not cypher_queries:
                    error_msg = f"Failed to generate valid Cypher queries for file {file_index}"
                    logger.error(error_msg)
                    all_errors.append(error_msg)
                    continue
                logger.info(f"cypher_queries: {cypher_queries}")
                logger.info(f"Generated {len(cypher_queries)} Cypher queries for file {file_index}")
                
                # Execute queries for this file
                logger.info(f"Step 5.{file_index}.4: Executing Cypher queries")
                # execution_results = self.neo4j_agent.execute_cypher_queries(cypher_queries)
                execution_results = self.neo4j_agent.execute_cypher_queries(cypher_queries)
                # Update totals
                total_files_processed += processing_results['files_processed']
                total_rows_processed += processing_results['total_rows']
                total_nodes_created += execution_results['total_nodes']
                total_relationships_created += execution_results['total_relationships']
                total_vector_chunks += processing_results.get('vector_stats', {}).get('total_chunks', 0)
                
                if execution_results.get('errors'):
                    all_errors.extend(execution_results['errors'])
                
                logger.info(f"File {file_index} completed: "
                           f"{execution_results['total_nodes']} nodes, "
                           f"{execution_results['total_relationships']} relationships created")
                
                # Get updated schema after processing this file
                logger.info(f"Step 5.{file_index}.5: Schema after processing file {file_index}")
                updated_schema = self.neo4j_agent.fetch_schema()
                logger.info(f"Current database now has {len(updated_schema.get('nodes', {}))} node types, "
                           f"{len(updated_schema.get('relationships', []))} relationship types")

            # Step 6: Get final schema information
            logger.info("Step 6: Retrieving final database schema")
            final_schema_info = self.neo4j_agent.fetch_schema()

            # Step 7: Cleanup temporary files
            logger.info("Step 7: Cleaning up temporary files")
            local_file_agent.cleanup_temp_files(temp_files)
            
            # Calculate processing time
            processing_time = time.time() - start_time
            
            # Prepare final response
            response = UploadResponse(
                success=True,
                message=f"Iterative knowledge graph created successfully from {total_files_processed} files in {processing_time:.2f} seconds",
                files_processed=total_files_processed,
                total_rows=total_rows_processed,
                nodes_created=total_nodes_created,
                relationships_created=total_relationships_created,
                vector_chunks_created=total_vector_chunks,
                schema_info=final_schema_info,
                errors=all_errors if all_errors else None
            )
            
            logger.info(f"Iterative upload workflow completed successfully: "
                       f"{response.files_processed} files, "
                       f"{response.nodes_created} nodes, "
                       f"{response.relationships_created} relationships")
            
        except Exception as e:
            error_msg = f"Iterative upload workflow failed: {str(e)}"
            logger.error(error_msg)
            response = UploadResponse(
                success=False,
                message=error_msg
            )
        
        finally:
            # Always disconnect from Neo4j
            self.neo4j_agent.disconnect()
        
        return response


    def process_local_upload_chunked(self, request: LocalUploadRequest) -> UploadResponse:
        """
        NEW: Process local files using chunk-wise Cypher query generation and execution
        Processes CSV files in configurable chunks for incremental knowledge graph building
        
        This method:
        1. Converts files to CSV format
        2. Processes each CSV file in chunks of specified size
        3. Generates Cypher queries for each chunk using MERGE statements
        4. Executes queries incrementally to build knowledge graph
        
        Args:
            request: LocalUploadRequest with file paths and chunk_size
            
        Returns:
            UploadResponse with detailed processing results
        """
        start_time = time.time()
        chunk_size = request.chunk_size
        logger.info(f"Starting chunked local upload workflow for {len(request.file_paths)} files "
                   f"(chunk size: {chunk_size})")
        
        # Initialize response
        response = UploadResponse(
            success=False,
            message="Chunked upload workflow started"
        )
        
        try:
            # Get AWS credentials (only needed for Bedrock provider)
            aws_credentials = config.get_aws_credentials_from_env()
            
            # Check credentials based on LLM provider
            if config.llm.provider.lower() == "bedrock" and not aws_credentials:
                return UploadResponse(
                    success=False,
                    message="AWS credentials required for Bedrock provider. Please set AWS credentials in environment variables."
                )
            
            # Step 1: Initialize agents
            logger.info("Step 1: Initializing agents for chunked processing")
            local_file_agent = LocalFileAgent()
            processing_agent = ProcessingAgent()
            
            try:
                llm_agent = self._initialize_llm_agent(aws_credentials=aws_credentials)
            except ValueError as e:
                return UploadResponse(
                    success=False,
                    message=str(e)
                )
            
            # Step 2: Connect to Neo4j
            logger.info("Step 2: Connecting to Neo4j database")
            if not self.neo4j_agent.connect():
                return UploadResponse(
                    success=False,
                    message="Failed to connect to Neo4j database"
                )
            

            
            # Step 4: Convert files to CSV
            logger.info("Step 4: Converting files to CSV format")
            csv_files = processing_agent._convert_excel_to_csv(request.file_paths)
            if not csv_files:
                return UploadResponse(
                    success=False,
                    message="No CSV files could be created from provided files"
                )
            
            logger.info(f"Converted to {len(csv_files)} CSV files")
            
            # Step 5: Get initial schema for context
            logger.info("Step 5: Fetching current database schema")
            current_schema = self.neo4j_agent.fetch_schema()
            
            # Step 6: Process each CSV file in chunks
            logger.info(f"Step 6: Processing {len(csv_files)} CSV files in chunks of {chunk_size}")
            total_chunks_processed = 0
            total_queries_executed = 0
            total_nodes_created = 0
            total_relationships_created = 0
            total_rows_processed = 0
            all_errors = []
            
            for csv_file in csv_files:
                logger.info(f"Processing file: {os.path.basename(csv_file)}")
                
                # Process CSV in chunks
                chunk_result = processing_agent.process_csv_in_chunks(csv_file, chunk_size)
                
                if not chunk_result.get('file_info') or not chunk_result.get('chunks'):
                    error_msg = f"Failed to process {csv_file} in chunks"
                    logger.error(error_msg)
                    all_errors.append(error_msg)
                    continue
                
                file_info = chunk_result['file_info']
                chunks = chunk_result['chunks']
                
                logger.info(f"File {file_info.filename} split into {len(chunks)} chunks")
                
                # Process each chunk
                for chunk in chunks:
                    chunk_number = chunk['chunk_number']
                    total_chunks = chunk['total_chunks']
                    chunk_data = chunk['data']
                    
                    logger.info(f"Processing chunk {chunk_number}/{total_chunks} "
                               f"of {file_info.filename} ({len(chunk_data)} rows)")
                    
                    # Generate Cypher queries for this chunk
                    chunk_queries = llm_agent.generate_chunked_cypher_queries(
                        file_info, chunk_data, chunk_number, total_chunks, current_schema
                    )
        
                    
                    if not chunk_queries:
                        error_msg = f"Failed to generate queries for chunk {chunk_number} of {file_info.filename}"
                        logger.error(error_msg)
                        all_errors.append(error_msg)
                        continue
                    
                    # Safety check: ensure chunk_queries is a list of strings
                    if not isinstance(chunk_queries, list):
                        logger.error(f"chunk_queries is not a list: {type(chunk_queries)} - {chunk_queries}")
                        all_errors.append(f"Invalid query format for chunk {chunk_number}: expected list, got {type(chunk_queries)}")
                        continue
                    
                    # Convert any non-string items to strings
                    safe_queries = []
                    for i, query in enumerate(chunk_queries):
                        if isinstance(query, str):
                            safe_queries.append(query)
                        else:
                            logger.warning(f"Query {i} in chunk {chunk_number} is not a string: {type(query)} - {query}")
                            safe_queries.append(str(query))
                    
                    if not safe_queries:
                        error_msg = f"No valid queries generated for chunk {chunk_number} of {file_info.filename}"
                        logger.error(error_msg)
                        all_errors.append(error_msg)
                        continue
                    
                    # Execute chunk queries
                    try:
                        execution_result = self.neo4j_agent.execute_cypher_queries(safe_queries)
                        
                        total_chunks_processed += 1
                        total_queries_executed += len(chunk_queries)
                        total_rows_processed += len(chunk_data)
                        total_nodes_created += execution_result.get('total_nodes', 0)
                        total_relationships_created += execution_result.get('total_relationships', 0)
                        
                        if execution_result.get('errors'):
                            all_errors.extend(execution_result['errors'])
                        
                        logger.info(f"Chunk {chunk_number}/{total_chunks} of {file_info.filename} completed: "
                                   f"{execution_result.get('successful', 0)}/{len(safe_queries)} successful queries, "
                                   f"{execution_result.get('total_nodes', 0)} nodes, "
                                   f"{execution_result.get('total_relationships', 0)} relationships")
                        
                        if execution_result.get('failed', 0) > 0:
                            logger.warning(f"Chunk {chunk_number}/{total_chunks} of {file_info.filename}: "
                                         f"{execution_result.get('failed', 0)} queries failed")
                            
                    except Exception as chunk_error:
                        error_msg = f"Failed to execute queries for chunk {chunk_number}/{total_chunks} of {file_info.filename}: {str(chunk_error)}"
                        logger.error(error_msg)
                        all_errors.append(error_msg)
                        total_chunks_processed += 1  # Still count as processed even if failed
                        total_rows_processed += len(chunk_data)  # Count rows even if failed
                        continue
                    
                    # Update schema context for next chunks
                    current_schema = self.neo4j_agent.fetch_schema()
            
            # Step 7: Create vector embeddings if requested
            vector_chunks_created = 0
            if request.create_vectors:
                logger.info("Step 7: Creating vector embeddings")
                vector_stats = VectorService().create_csv_vectors(csv_files)
                vector_chunks_created = vector_stats.get('total_chunks', 0)
            else:
                logger.info("Step 7: Skipping vector creation as requested")
            
            # Step 8: Get final schema
            logger.info("Step 8: Retrieving final database schema")
            final_schema = self.neo4j_agent.fetch_schema()
            
            # Calculate processing time
            processing_time = time.time() - start_time
            
            # Prepare response
            response = UploadResponse(
                success=True,
                message=f"Chunked knowledge graph creation completed in {processing_time:.2f}s. "
                       f"Processed {total_chunks_processed} chunks, "
                       f"executed {total_queries_executed} queries.",
                files_processed=len(csv_files),
                total_rows=total_rows_processed,
                nodes_created=total_nodes_created,
                relationships_created=total_relationships_created,
                vector_chunks_created=vector_chunks_created,
                schema_info=final_schema,
                errors=all_errors
            )
            
            logger.info(f"Chunked upload workflow completed successfully: "
                       f"{response.files_processed} files, "
                       f"{total_chunks_processed} chunks processed, "
                       f"{response.nodes_created} nodes, "
                       f"{response.relationships_created} relationships")
            
        except Exception as e:
            error_msg = f"Chunked upload workflow failed: {str(e)}"
            logger.error(error_msg)
            response = UploadResponse(
                success=False,
                message=error_msg
            )
        
        finally:
            # Always disconnect from Neo4j
            self.neo4j_agent.disconnect()
        
        return response

    def process_s3_upload_chunked(self, request: S3UploadRequest) -> UploadResponse:
        """
        NEW: Process S3 files using chunk-wise Cypher query generation and execution
        Similar to local chunked processing but for S3 files
        
        Args:
            request: S3UploadRequest with S3 URL, credentials, and chunk_size
            
        Returns:
            UploadResponse with detailed processing results
        """
        start_time = time.time()
        chunk_size = request.chunk_size
        logger.info(f"Starting chunked S3 upload workflow for URL: {request.s3_url} "
                   f"(chunk size: {chunk_size})")
        
        # Initialize response
        response = UploadResponse(
            success=False,
            message="Chunked S3 upload workflow started"
        )
        
        try:
            # Get AWS credentials
            aws_credentials = config.get_aws_credentials(
                request.aws_access_key_id,
                request.aws_secret_access_key,
                request.aws_session_token,
                request.region_name
            )
            
            # Step 1: Initialize agents
            logger.info("Step 1: Initializing agents for chunked S3 processing")
            s3_agent = S3Agent(aws_credentials)
            processing_agent = ProcessingAgent()
            
            # Initialize LLM Agent based on provider
            try:
                if aws_credentials:
                    llm_agent = self._initialize_llm_agent(aws_credentials=aws_credentials)
                else:
                    # For Bedrock without pre-configured credentials, use request credentials
                    if config.llm.provider.lower() == "bedrock":
                        if not request.aws_access_key_id or not request.aws_secret_access_key:
                            return UploadResponse(
                                success=False,
                                message="AWS credentials are required for Bedrock provider. Please provide aws_access_key_id and aws_secret_access_key."
                            )
                        # Create credentials specifically for LLM
                        llm_credentials = {
                            'aws_access_key_id': request.aws_access_key_id,
                            'aws_secret_access_key': request.aws_secret_access_key,
                            'region_name': request.region_name
                        }
                        if request.aws_session_token:
                            llm_credentials['aws_session_token'] = request.aws_session_token
                        llm_agent = self._initialize_llm_agent(request_aws_credentials=llm_credentials)
                    else:
                        # Azure OpenAI doesn't need AWS credentials
                        llm_agent = self._initialize_llm_agent()
            except ValueError as e:
                return UploadResponse(
                    success=False,
                    message=str(e)
                )
            
            # Step 2: Connect to Neo4j
            logger.info("Step 2: Connecting to Neo4j database")
            if not self.neo4j_agent.connect():
                return UploadResponse(
                    success=False,
                    message="Failed to connect to Neo4j database"
                )
            
            # Step 3: Validate S3 access
            logger.info("Step 3: Validating S3 access")
            if not s3_agent.validate_s3_access(str(request.s3_url)):
                return UploadResponse(
                    success=False,
                    message="Cannot access the provided S3 URL"
                )
            
            # Step 4: Download files from S3
            logger.info("Step 4: Downloading files from S3")
            downloaded_files = s3_agent.download_files_from_s3(str(request.s3_url))
            if not downloaded_files:
                return UploadResponse(
                    success=False,
                    message="No supported files found or downloaded from S3"
                )
            
            logger.info(f"Downloaded {len(downloaded_files)} files from S3")
            
            # Step 5: Convert files to CSV
            logger.info("Step 5: Converting files to CSV format")
            csv_files = processing_agent._convert_excel_to_csv(downloaded_files)
            if not csv_files:
                return UploadResponse(
                    success=False,
                    message="No CSV files could be created from downloaded files"
                )
            
            logger.info(f"Converted to {len(csv_files)} CSV files")
            
            # Step 6: Get initial schema for context
            logger.info("Step 6: Fetching current database schema")
            current_schema = self.neo4j_agent.fetch_schema()
            
            # Step 7: Process each CSV file in chunks
            logger.info(f"Step 7: Processing {len(csv_files)} CSV files in chunks of {chunk_size}")
            total_chunks_processed = 0
            total_queries_executed = 0
            total_rows_processed = 0
            total_nodes_created = 0
            total_relationships_created = 0
            all_errors = []
            
            for csv_file in csv_files:
                logger.info(f"Processing file: {os.path.basename(csv_file)}")
                
                # Process CSV in chunks
                chunk_result = processing_agent.process_csv_in_chunks(csv_file, chunk_size)
                
                if not chunk_result.get('file_info') or not chunk_result.get('chunks'):
                    error_msg = f"Failed to process {csv_file} in chunks"
                    logger.error(error_msg)
                    all_errors.append(error_msg)
                    continue
                
                file_info = chunk_result['file_info']
                chunks = chunk_result['chunks']
                
                logger.info(f"File {file_info.filename} split into {len(chunks)} chunks")
                
                # Process each chunk
                for chunk in chunks:
                    chunk_number = chunk['chunk_number']
                    total_chunks = chunk['total_chunks']
                    chunk_data = chunk['data']
                    
                    logger.info(f"Processing chunk {chunk_number}/{total_chunks} "
                               f"of {file_info.filename} ({len(chunk_data)} rows)")
                    
                    # Generate Cypher queries for this chunk
                    chunk_queries = llm_agent.generate_chunked_cypher_queries(
                        file_info, chunk_data, chunk_number, total_chunks, current_schema
                    )
                    
                    if not chunk_queries:
                        error_msg = f"Failed to generate queries for chunk {chunk_number} of {file_info.filename}"
                        logger.error(error_msg)
                        all_errors.append(error_msg)
                        continue
                    
                    # Execute chunk queries
                    try:
                        execution_result = self.neo4j_agent.execute_cypher_queries(chunk_queries)
                        
                        total_chunks_processed += 1
                        total_queries_executed += len(chunk_queries)
                        total_rows_processed += len(chunk_data)
                        total_nodes_created += execution_result.get('total_nodes', 0)
                        total_relationships_created += execution_result.get('total_relationships', 0)
                        
                        if execution_result.get('errors'):
                            all_errors.extend(execution_result['errors'])
                        
                        logger.info(f"Chunk {chunk_number}/{total_chunks} of {file_info.filename} completed: "
                                   f"{execution_result.get('successful', 0)}/{len(chunk_queries)} successful queries, "
                                   f"{execution_result.get('total_nodes', 0)} nodes, "
                                   f"{execution_result.get('total_relationships', 0)} relationships")
                        
                        if execution_result.get('failed', 0) > 0:
                            logger.warning(f"Chunk {chunk_number}/{total_chunks} of {file_info.filename}: "
                                         f"{execution_result.get('failed', 0)} queries failed")
                            
                    except Exception as chunk_error:
                        error_msg = f"Failed to execute queries for chunk {chunk_number}/{total_chunks} of {file_info.filename}: {str(chunk_error)}"
                        logger.error(error_msg)
                        all_errors.append(error_msg)
                        total_chunks_processed += 1  # Still count as processed even if failed
                        total_rows_processed += len(chunk_data)  # Count rows even if failed
                        continue
                    
                    # Update schema context for next chunks
                    current_schema = self.neo4j_agent.fetch_schema()
            
            # # Step 8: Create vector embeddings
            # logger.info("Step 8: Creating vector embeddings")
            # vector_stats = VectorService().create_csv_vectors(csv_files)
            # vector_chunks_created = vector_stats.get('total_chunks', 0)
            
            # Step 9: Cleanup temporary files
            logger.info("Step 9: Cleaning up temporary files")
            s3_agent.cleanup_temp_files(downloaded_files)
            
            # Step 10: Get final schema
            logger.info("Step 10: Retrieving final database schema")
            final_schema = self.neo4j_agent.fetch_schema()
            
            # Calculate processing time
            processing_time = time.time() - start_time
            
            # Prepare response
            response = UploadResponse(
                success=True,
                message=f"Chunked S3 knowledge graph creation completed in {processing_time:.2f}s. "
                       f"Processed {total_chunks_processed} chunks, "
                       f"executed {total_queries_executed} queries.",
                files_processed=len(csv_files),
                total_rows=total_rows_processed,
                nodes_created=total_nodes_created,
                relationships_created=total_relationships_created,
                # vector_chunks_created=vector_chunks_created,
                schema_info=final_schema,
                errors=all_errors
            )
            
            logger.info(f"Chunked S3 upload workflow completed successfully: "
                       f"{response.files_processed} files, "
                       f"{total_chunks_processed} chunks processed, "
                       f"{response.nodes_created} nodes, "
                       f"{response.relationships_created} relationships")
            
        except Exception as e:
            error_msg = f"Chunked S3 upload workflow failed: {str(e)}"
            logger.error(error_msg)
            response = UploadResponse(
                success=False,
                message=error_msg
            )
        
        finally:
            # Always disconnect from Neo4j
            self.neo4j_agent.disconnect()
        
        return response 