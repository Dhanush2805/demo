import logging
import os
from datetime import datetime
from pathlib import Path

def setup_logger():
    """
    Set up logging configuration for the knowledge graph chatbot
    Creates daily log files in /logs folder with format: YYYY-MM-DD.log
    Configures agent-specific logging while suppressing system noise
    """
    # Create logs directory if it doesn't exist
    logs_dir = Path("logs")
    logs_dir.mkdir(exist_ok=True)
    
    # Create log filename with current date
    current_date = datetime.now().strftime("%Y-%m-%d")
    log_filename = logs_dir / f"{current_date}.log"
    
    # Configure logging format
    log_format = "[%(asctime)s] [%(levelname)s] [%(name)s] - %(message)s"
    date_format = "%Y-%m-%d %H:%M:%S"
    
    # Configure root logger with WARNING level to suppress system logs
    logging.basicConfig(
        level=logging.WARNING,
        format=log_format,
        datefmt=date_format,
        handlers=[
            logging.FileHandler(log_filename, encoding='utf-8'),
            logging.StreamHandler()  # Also log to console
        ]
    )
    
    # Suppress noisy system loggers
    logging.getLogger("uvicorn").setLevel(logging.WARNING)
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)
    logging.getLogger("uvicorn.error").setLevel(logging.WARNING)
    logging.getLogger("watchfiles").setLevel(logging.WARNING)
    logging.getLogger("fastapi").setLevel(logging.WARNING)
    logging.getLogger("multipart").setLevel(logging.WARNING)
    
    # Create specific loggers for different components with INFO level
    loggers = {
        'upload_agent': logging.getLogger('UploadAgent'),
        'chat_agent': logging.getLogger('ChatAgent'),
        's3_agent': logging.getLogger('S3Agent'),
        'processing_agent': logging.getLogger('ProcessingAgent'),
        'llm_agent': logging.getLogger('LLMAgent'),
        'neo4j_agent': logging.getLogger('Neo4jAgent'),
        'vector_service': logging.getLogger('VectorService'),
        'api': logging.getLogger('API')
    }
    
    # Set agent loggers to INFO level to see their messages
    for logger_name, logger_obj in loggers.items():
        logger_obj.setLevel(logging.INFO)
    
    return loggers

# Initialize loggers
LOGGERS = setup_logger()

def get_logger(name: str) -> logging.Logger:
    """Get a specific logger by name"""
    return LOGGERS.get(name, logging.getLogger(name)) 