from typing import List, Dict, Any, Optional
from pydantic import BaseModel, HttpUrl, Field
from fastapi import UploadFile


class SafeDataConverter:
    """Utility class for safe data type conversions from database rows"""

    @staticmethod
    def safe_date_string(value) -> Optional[str]:
        """Safely convert date/datetime to string, returning None for empty/invalid values"""
        if value is None or value == '' or value == 'NULL':
            return None
        if hasattr(value, 'strftime'):  # Check if it's a date/datetime object
            return value.strftime('%Y-%m-%d')
        if isinstance(value, str):
            return value
        try:
            # Try to convert to string as fallback
            return str(value)
        except (ValueError, TypeError):
            return None

    @staticmethod
    def safe_int(value) -> Optional[int]:
        """Safely convert value to int, returning None for empty/invalid values"""
        if value is None or value == '' or value == 'NULL':
            return None
        try:
            return int(float(value))  # Handle cases where int comes as float
        except (ValueError, TypeError):
            return None

    @staticmethod
    def safe_float(value) -> Optional[float]:
        """Safely convert value to float, returning None for empty/invalid values"""
        if value is None or value == '' or value == 'NULL':
            return None
        try:
            return float(value)
        except (ValueError, TypeError):
            return None

    @staticmethod
    def safe_bool(value) -> Optional[bool]:
        """Safely convert value to bool, returning None for empty/invalid values"""
        if value is None or value == '' or value == 'NULL':
            return None
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.lower() in ('true', '1', 'yes', 'on')
        try:
            return bool(int(value))
        except (ValueError, TypeError):
            return None

class FileInfo(BaseModel):
    """Model for CSV file information - extracted from notebook"""
    filename: str
    file_path: str  # Can be local file path or HTTPS URL for S3
    file_size: int = 0  # File size in bytes (0 for URL-based files)
    columns: List[str]
    row_count: int
    sample_data: List[Dict[str, Any]]

class S3UploadRequest(BaseModel):
    """Request model for S3 upload endpoint"""
    s3_url: HttpUrl = Field(..., description="S3 URL to download files from")
    aws_access_key_id: Optional[str] = Field(None, description="AWS Access Key ID (optional for public URLs)")
    aws_secret_access_key: Optional[str] = Field(None, description="AWS Secret Access Key (optional for public URLs)")
    aws_session_token: Optional[str] = Field(None, description="AWS Session Token (optional)")
    region_name: str = Field(default="us-west-2", description="AWS Region")
    chunk_size: int = Field(default=10, ge=1, le=1000, description="Number of rows to process per chunk (1-1000)")
    create_vectors: bool = Field(default=False, description="Whether to create vector embeddings for semantic search")


class LocalUploadRequest(BaseModel):
    """Request model for local file upload endpoint"""
    file_paths: List[str] = Field(..., description="List of local file paths to process")
    create_vectors: bool = Field(default=False, description="Whether to create vector embeddings for semantic search")
    chunk_size: int = Field(default=10, ge=1, le=1000, description="Number of rows to process per chunk (1-1000)")


class FileUploadInfo(BaseModel):
    """Model for individual file upload information"""
    filename: str
    file_type: str 
    file_size: int
    s3_url: str
    processing_status: str
    error_message: Optional[str] = None


class TempUploadResponse(BaseModel):
    """Response model for temp-upload endpoint"""
    success: bool
    message: str
    files_processed: int = 0
    pdf_files_processed: int = 0
    video_files_uploaded: int = 0
    files_info: List[FileUploadInfo] = []
    errors: Optional[List[str]] = None


class TempChatRequest(BaseModel):
    """Request model for temp-chat endpoint"""
    question: str = Field(..., min_length=1, description="Question to ask about the file content")
    source_filename: str = Field(..., description="Name of the uploaded file to search in")


class TempChatResponse(BaseModel):
    """Response model for temp-chat endpoint"""
    success: bool
    question: str
    source_filename: str
    answer: str
    sources_found: int = 0
    processing_time: Optional[float] = None
    error: Optional[str] = None


class PPTAnalysisResponse(BaseModel):
    """Simplified response model for PPT analysis endpoint"""
    success: bool
    message: str
    files_processed: int = 0
    analysis_markdown: str = ""
    processing_time: Optional[float] = None
    errors: Optional[List[str]] = None


class UploadResponse(BaseModel):
    """Response model for upload endpoint"""
    success: bool
    message: str
    files_processed: Optional[int] = None
    total_rows: Optional[int] = None
    nodes_created: Optional[int] = None
    relationships_created: Optional[int] = None
    vector_chunks_created: Optional[int] = None
    schema_info: Optional[Dict[str, Any]] = None
    errors: Optional[List[str]] = None

class ChatRequest(BaseModel):
    """Request model for chat endpoint"""
    question: str = Field(..., min_length=1, description="User question about the knowledge graph")
    include_context: Optional[bool] = Field(default=True, description="Whether to include vector search context")
    max_results: Optional[int] = Field(default=10, ge=1, le=100, description="Maximum number of results to return")

class ChatResponse(BaseModel):
    """Response model for chat endpoint"""
    success: bool
    question: str
    answer: str
    publications_links: Optional[List[str]] = None
    project_links: Optional[List[str]] = None
    cypher_query: Optional[List[str]] = None
    sources: Optional[List[Dict[str, Any]]] = None
    result_count: Optional[int] = None
    processing_time: Optional[float] = None
    error: Optional[str] = None
    accuracy: Optional[float] = None
    from_cache: Optional[bool] = Field(default=False, description="Whether the response was retrieved from cache")



class VectorSearchResult(BaseModel):
    """Model for vector search results"""
    chunk_id: str
    source: str
    content: str
    similarity_score: float
    metadata: Dict[str, Any]

class Neo4jExecutionResult(BaseModel):
    """Model for Neo4j query execution results"""
    query: str
    success: bool
    nodes_created: int = 0
    relationships_created: int = 0
    records_returned: int = 0
    execution_time: float = 0.0
    error: Optional[str] = None


class TextInsightsRequest(BaseModel):
    """Request model for text insights analysis endpoint"""
    text: str = Field(..., min_length=10, max_length=50000, description="Text content, bullet points, or paragraphs to analyze")

class TextInsightsResponse(BaseModel):
    """Response model for enhanced text insights analysis with graph visualization"""
    success: bool
    message: str
    publications_links: Optional[List[str]] = Field(None, description="List of PubMed IDs")
    consolidated_insights: Optional[str] = Field(None, description="Comprehensive summary of key themes and patterns")
    is_graph: bool = Field(default=False, description="Whether a meaningful graph was generated")
    html_code: Optional[str] = Field(None, description="Complete self-contained HTML code for the graph")
    error: Optional[str] = None

class CDPNLQRequest(BaseModel):
    """Request model for CDP Natural Language Query endpoint"""
    query: str = Field(..., min_length=5, max_length=1000, description="Natural language query to analyze against CDP data")
    max_results: int = Field(default=100, ge=1, le=1000, description="Maximum number of results to return")
    include_graph: bool = Field(default=True, description="Whether to generate graph visualization")

class CDPNLQResponse(BaseModel):
    """Response model for CDP Natural Language Query with graph visualization"""
    success: bool
    message: str
    query: str = Field(..., description="Original natural language query")
    sql_query: Optional[str] = Field(None, description="Generated SQL query")
    data: Optional[List[Dict[str, Any]]] = Field(None, description="Query results")
    total_count: int = Field(default=0, description="Total number of results")
    is_graph: bool = Field(default=False, description="Whether a meaningful graph was generated")
    html_code: Optional[str] = Field(None, description="Complete self-contained HTML code for the graph")
    processing_time: float = Field(default=0.0, description="Query processing time in seconds")
    error: Optional[str] = None

class PostgreSQLExecutionResult(BaseModel):
    """Model for PostgreSQL query execution results"""
    query: str
    success: bool
    rows_affected: int = 0
    rows_returned: int = 0
    execution_time: float = 0.0
    column_names: Optional[List[str]] = None
    data: Optional[List[Dict[str, Any]]] = None
    error: Optional[str] = None


# Dashboard API Models
class InsightResponse(BaseModel):
    """Response model for insights API"""
    publication_id: str
    project_id: str
    oneliner_insight: str
    multiliner_insights: str


class PublicationResponse(BaseModel):
    """Response model for publications API"""
    publication_id: str
    pmid: str
    title: str
    journal: str
    journal_abbr: str
    year: int
    pmc_id: str
    total_authors: int
    therapeutic_area: str
    author_researcher_names: str
    oneliner_insight: str
    multiliner_insights: str
    linked_project_ids: str
    abstract: str
    pubmed_link: str
    pubmed_cited_link: str


class ProjectResponse(BaseModel):
    """Response model for projects API"""
    project_id: str
    application_ids: str
    title: str
    pi_name: str
    funding_mechanism: str
    fiscal_year: int
    organization: str
    org_city: str
    org_state: str
    start_date: str
    end_date: str
    total_cost: int
    direct_cost: int
    therapeutic_area: str
    funding_ics: str
    linked_publication_ids: str
    oneliner_insight: str
    multiliner_insights: str
    abstract: str


class KOLResponse(BaseModel):
    """Response model for KOLs API"""
    researcher_id: str
    name: str
    institution: str
    year: int
    project_ids: str
    oneliner_insight: str
    multiliner_insights: str
    therapeutic_area: str
    roles: str
    city: str


# KOL Detail Models
class KOLAdvisoryBoard(BaseModel):
    """Advisory board data for KOL"""
    advisory_id: str
    advisory_meeting_date: Optional[str] = None
    advisory_meeting_topic: Optional[str] = None
    advisory_kol_contribution: Optional[str] = None
    advisory_discussion_points: Optional[str] = None
    advisory_action_items: Optional[str] = None
    advisory_campaign_id: Optional[str] = None
    advisory_strategic_flag: Optional[bool] = None
    advisory_pipeline_impact_score: Optional[float] = None
    advisory_competitive_insight: Optional[str] = None

    @classmethod
    def from_db_row(cls, row: dict):
        """Create instance from database row, handling null/empty values"""
        return cls(
            advisory_id=row.get('advisory_id', ''),
            advisory_meeting_date=SafeDataConverter.safe_date_string(row.get('advisory_meeting_date')),
            advisory_meeting_topic=row.get('advisory_meeting_topic') or None,
            advisory_kol_contribution=row.get('advisory_kol_contribution') or None,
            advisory_discussion_points=row.get('advisory_discussion_points') or None,
            advisory_action_items=row.get('advisory_action_items') or None,
            advisory_campaign_id=row.get('advisory_campaign_id') or None,
            advisory_strategic_flag=SafeDataConverter.safe_bool(row.get('advisory_strategic_flag')),
            advisory_pipeline_impact_score=SafeDataConverter.safe_float(row.get('advisory_pipeline_impact_score')),
            advisory_competitive_insight=row.get('advisory_competitive_insight') or None
        )


class KOLSocialMedia(BaseModel):
    """Social media data for KOL"""
    social_activity_date: Optional[str] = None
    social_platform: Optional[str] = None
    social_activity_type: Optional[str] = None
    social_reach: Optional[int] = None
    social_likes: Optional[int] = None
    social_comments: Optional[int] = None
    social_shares: Optional[int] = None

    @classmethod
    def from_db_row(cls, row: dict):
        """Create instance from database row, handling null/empty values"""
        return cls(
            social_activity_date=SafeDataConverter.safe_date_string(row.get('social_activity_date')),
            social_platform=row.get('social_platform') or None,
            social_activity_type=row.get('social_activity_type') or None,
            social_reach=SafeDataConverter.safe_int(row.get('social_reach')),
            social_likes=SafeDataConverter.safe_int(row.get('social_likes')),
            social_comments=SafeDataConverter.safe_int(row.get('social_comments')),
            social_shares=SafeDataConverter.safe_int(row.get('social_shares'))
        )

class KOLPeerPortal(BaseModel):
    """Peer portal interaction data for KOL"""
    pp_transaction_id: Optional[str] = None
    pp_kol_id: Optional[str] = None
    pp_portal_name: Optional[str] = None
    pp_portal_url: Optional[str] = None
    pp_access_date: Optional[str] = None
    pp_activity_type: Optional[str] = None
    pp_content_accessed: Optional[str] = None
    pp_time_spent_minutes: Optional[int] = None
    pp_engagement_score: Optional[float] = None
    pp_created_at: Optional[str] = None

    @classmethod
    def from_db_row(cls, row: dict):
        """Create instance from database row, handling null/empty values"""
        return cls(
            pp_transaction_id=row.get('transaction_id') or None,
            pp_kol_id=row.get('kol_id') or None,
            pp_portal_name=row.get('portal_name') or None,
            pp_portal_url=row.get('portal_url') or None,
            pp_access_date=SafeDataConverter.safe_date_string(row.get('access_date')),
            pp_activity_type=row.get('activity_type') or None,
            pp_content_accessed=row.get('content_accessed') or None,
            pp_time_spent_minutes=SafeDataConverter.safe_int(row.get('time_spent_minutes')),
            pp_engagement_score=SafeDataConverter.safe_float(row.get('engagement_score')),
            pp_created_at=SafeDataConverter.safe_date_string(row.get('created_at')) or None,
        )
        
class KOLMedscape(BaseModel):
    """Medscape activity data for KOL"""
    medscape_transaction_id: Optional[str] = None
    medscape_kol_id: Optional[str] = None
    medscape_activity_date: Optional[str] = None
    medscape_activity_type: Optional[str] = None
    medscape_content_title: Optional[str] = None
    medscape_content_category: Optional[str] = None
    medscape_time_spent_minutes: Optional[int] = None
    medscape_completion_rate: Optional[int] = None
    medscape_cme_credits_earned: Optional[float] = None
    medscape_engagement_metrics: Optional[str] = None
    medscape_created_at: Optional[str] = None

    @classmethod
    def from_db_row(cls, row: dict):
        """Create instance from database row, handling null/empty values"""
        return cls(
            medscape_transaction_id=row.get('transaction_id') or None,
            medscape_kol_id=row.get('kol_id') or None,
            medscape_activity_date=SafeDataConverter.safe_date_string(row.get('activity_date')),
            medscape_activity_type=row.get('activity_type') or None,
            medscape_content_title=row.get('content_title') or None,
            medscape_content_category=row.get('content_category') or None,
            medscape_time_spent_minutes=SafeDataConverter.safe_int(row.get('time_spent_minutes')),
            medscape_completion_rate=SafeDataConverter.safe_int(row.get('completion_rate')),
            medscape_cme_credits_earned=SafeDataConverter.safe_float(row.get('cme_credits_earned')),
            medscape_engagement_metrics=row.get('engagement_metrics') or None,
            medscape_created_at=SafeDataConverter.safe_date_string(row.get('created_at')) or None
        )
        
class KOLCompProduct(BaseModel):
    """Competitive product interaction data for KOL"""
    cp_transaction_id: Optional[str] = None
    cp_kol_id: Optional[str] = None
    cp_product_name: Optional[str] = None
    cp_product_category: Optional[str] = None
    cp_interaction_date: Optional[str] = None
    cp_interaction_type: Optional[str] = None
    cp_engagement_level: Optional[str] = None
    cp_source_platform: Optional[str] = None
    cp_notes: Optional[str] = None
    cp_created_at: Optional[str] = None

    @classmethod
    def from_db_row(cls, row: dict):
        """Create instance from database row, handling null/empty values"""
        return cls(
            cp_transaction_id=row.get('cp_transaction_id') or None,
            cp_kol_id=row.get('kol_id') or None,
            cp_product_name=row.get('product_name') or None,
            cp_product_category=row.get('product_category') or None,
            cp_interaction_date=SafeDataConverter.safe_date_string(row.get('interaction_date')),
            cp_interaction_type=row.get('interaction_type') or None,
            cp_engagement_level=row.get('engagement_level') or None,
            cp_source_platform=row.get('source_platform') or None,
            cp_notes=row.get('notes') or None,
            cp_created_at=SafeDataConverter.safe_date_string(row.get('created_at')) or None
        )

            
class KOLDoximity(BaseModel):
    """Doximity activity data for KOL"""
    doximity_transaction_id: Optional[str] = None
    doximity_kol_id: Optional[str] = None
    doximity_activity_date: Optional[str] = None
    doximity_activity_type: Optional[str] = None
    doximity_content_title: Optional[str] = None
    doximity_network_connections: Optional[int] = None
    doximity_profile_views: Optional[int] = None
    doximity_engagement_level: Optional[str] = None
    doximity_specialty_focus: Optional[str] = None
    doximity_created_at: Optional[str] = None

    @classmethod
    def from_db_row(cls, row: dict):
        """Create instance from database row, handling null/empty values"""
        return cls(
            doximity_transaction_id=row.get('transaction_id') or None,
            doximity_kol_id=row.get('kol_id') or None,
            doximity_activity_date=SafeDataConverter.safe_date_string(row.get('activity_date')),
            doximity_activity_type=row.get('activity_type') or None,
            doximity_content_title=row.get('content_title') or None,
            doximity_network_connections=SafeDataConverter.safe_int(row.get('network_connections')),
            doximity_profile_views=SafeDataConverter.safe_int(row.get('profile_views')),
            doximity_engagement_level=row.get('engagement_level') or None,
            doximity_specialty_focus=row.get('specialty_focus') or None,
            doximity_created_at=SafeDataConverter.safe_date_string(row.get('created_at')) or None
        )

class SpeakerBureauEngagement(BaseModel):
    """Speaker Bureau engagement data for KOL"""
    engagement_id: Optional[str] = None
    kol_id: Optional[str] = None
    engagement_date: Optional[str] = None
    event_type: Optional[str] = None
    presentation_topic: Optional[str] = None
    audience_size: Optional[int] = None
    honorarium_paid: Optional[float] = None
    event_description: Optional[str] = None
    campaign_id: Optional[str] = None
    kol_event_performance_score: Optional[float] = None
    attendees_reached_by_kol: Optional[int] = None
    source_system: Optional[str] = None
    event_platform_id: Optional[str] = None

    @classmethod
    def from_db_row(cls, row: dict):
        """Create instance from database row, handling null/empty values"""
        return cls(
            engagement_id=row.get('engagement_id') or None,
            kol_id=row.get('kol_id') or None,
            engagement_date=SafeDataConverter.safe_date_string(row.get('engagement_date')) or None,
            event_type=row.get('event_type') or None,
            presentation_topic=row.get('presentation_topic') or None,
            audience_size=SafeDataConverter.safe_int(row.get('audience_size')),
            honorarium_paid=SafeDataConverter.safe_float(row.get('honorarium_paid')),
            event_description=row.get('event_description') or None,
            campaign_id=row.get('campaign_id') or None,
            kol_event_performance_score=SafeDataConverter.safe_float(row.get('kol_event_performance_score')),
            attendees_reached_by_kol=SafeDataConverter.safe_int(row.get('attendees_reached_by_kol')),
            source_system=row.get('source_system') or None,
            event_platform_id=row.get('event_platform_id') or None
        )
class MSLKOLInteractionSummary(BaseModel):
    """Summary of MSL and KOL interaction details"""
    msl_name: str
    interaction_type: str
    therapy_area_focus: str
    key_meeting_objectives: str

    region: Optional[str] = None
    discussion_topics: Optional[str] = None
    kol_publications_count: Optional[int] = None
    kol_citations_count: Optional[int] = None
    next_action_required: Optional[str] = None
    interaction_date: Optional[str] = None

    @classmethod
    def from_db_row(cls, row: dict):
        """Create instance from a database row dictionary"""
        return cls(
            msl_name=row.get('msl_name') or "",
            region=row.get('region') or None,
            interaction_type=row.get('interaction_type') or "",
            therapy_area_focus=row.get('therapy_area_focus') or "",
            discussion_topics=row.get('discussion_topics') or None,
            key_meeting_objectives=row.get('key_meeting_objectives') or "",
            kol_publications_count=SafeDataConverter.safe_int(row.get('kol_publications_count')),
            kol_citations_count=SafeDataConverter.safe_int(row.get('kol_citations_count')),
            next_action_required=row.get('next_action_required') or None
        )
class KOLCongress(BaseModel):
    """Congress data for KOL"""
    congress_date: Optional[str] = None
    congress_name: Optional[str] = None
    congress_role: Optional[str] = None
    congress_key_takeaways: Optional[str] = None
    congress_impact_score: Optional[float] = None
    congress_trend_keywords: Optional[str] = None
    congress_audience_reception: Optional[str] = None

    @classmethod
    def from_db_row(cls, row: dict):
        """Create instance from database row, handling null/empty values"""
        return cls(
            congress_date=SafeDataConverter.safe_date_string(row.get('congress_date')) or None,
            congress_name=row.get('congress_name') or None,
            congress_role=row.get('congress_role') or None,
            congress_key_takeaways=row.get('congress_key_takeaways') or None,
            congress_impact_score=SafeDataConverter.safe_float(row.get('congress_impact_score')),
            congress_trend_keywords=row.get('congress_trend_keywords') or None,
            congress_audience_reception=row.get('congress_audience_reception') or None
        )


class KOLMaster(BaseModel):
    """Master KOL information"""
    authorName: Optional[str] = None
    Credentials: Optional[str] = None
    Specialty_Sub_TA: Optional[str] = Field(None, alias="Specialty/Sub-TA")
    Institution: Optional[str] = None
    Primary_Therapeutic_Area: Optional[str] = None
    Tier: Optional[str] = None
    Is_Principal_Investigator: Optional[bool] = None
    Site_Affiliation: Optional[str] = None
    Avg_Enrollment_Rate_Past_Trials: Optional[float] = None
    Data_Quality_Score: Optional[float] = None
    Years_Experience: Optional[int] = None
    Research_Focus: Optional[str] = None
    Research_Focus_SNOMED_CT_Code: Optional[str] = None
    Research_Focus_ICD9_Code: Optional[str] = None
    Research_Focus_ICD10_Code: Optional[str] = None
    Research_Focus_ICD11_Code: Optional[str] = None
    Last_Contact_Date: Optional[str] = None

    @classmethod
    def from_db_row(cls, row: dict):
        """Create instance from database row, handling null/empty values"""
        return cls(
            authorName=row.get('authorname') or None,
            Credentials=row.get('credentials') or None,
            Specialty_Sub_TA=row.get('Specialty/Sub-TA') or None,
            Institution=row.get('institution') or None,
            Primary_Therapeutic_Area=row.get('primary_therapeutic_area') or None,
            Tier=row.get('tier') or None,
            Is_Principal_Investigator=SafeDataConverter.safe_bool(row.get('is_principal_investigator')),
            Site_Affiliation=row.get('site_affiliation') or None,
            Avg_Enrollment_Rate_Past_Trials=SafeDataConverter.safe_float(row.get('avg_enrollment_rate_past_trials')),
            Data_Quality_Score=SafeDataConverter.safe_float(row.get('data_quality_score')),
            Years_Experience=SafeDataConverter.safe_int(row.get('years_experience')),
            Research_Focus=row.get('research_focus') or None,
            Research_Focus_SNOMED_CT_Code=row.get('research_focus_snomed_ct_code') or None,
            Research_Focus_ICD9_Code=row.get('research_focus_icd9_code') or None,
            Research_Focus_ICD10_Code=row.get('research_focus_icd10_code') or None,
            Research_Focus_ICD11_Code=row.get('research_focus_icd11_code') or None,
            Last_Contact_Date=SafeDataConverter.safe_date_string(row.get('last_contact_date'))
        )


class KOLPreCallInsights(BaseModel):
    """Response model for KOL pre-call insights API"""
    researcher_id: str
    name: str
    pre_call_insights_pointers: List[str]


class ListResponse(BaseModel):
    """Generic list response model"""
    success: bool
    message: str
    data: Optional[List[Any]] = None
    total_count: int = 0


class GenericResponse(BaseModel):
    """Generic response model"""
    success: bool
    message: str
    data: Optional[Any] = None


class IngestionCreateRequest(BaseModel):
    """Request model for creating data ingestion pipelines"""
    source: str
    source_details: Dict[str, Any]
    target: str
    target_details: Dict[str, Any]
    mapping_data: Optional[Dict[str, Any]] = None
    status: Optional[str] = None
    last_run: Optional[str] = None
    databricks_job_id: Optional[str] = None
    last_run_id: Optional[str] = None
    last_run_status: Optional[str] = None


class JobRequest(BaseModel):
    """Request model for job operations"""
    ingestion_id: str
    last_run_id: Optional[str] = None


class RunJobRequest(BaseModel):
    """Request model for running jobs"""
    ingestion_id: str

class KOLDetailResponse(BaseModel):
    """Response model for individual KOL detail API"""
    researcher_id: str
    name: str
    roles: str
    therapeutic_areas: str
    project_ids: str
    publication_ids: str
    patent_ids: str
    clinical_study_ids: str
    sub_pi_authors: str
    sub_publication_authors: str
    total_projects: int
    total_publications: int
    total_patents: int
    total_clinical_studies: int
    total_funding: int
    top_institution: str
    org_city: str
    org_state: str
    is_pi: bool
    is_author: bool
    is_both: bool

    topics: str
    pre_call_insights_pointers: List[str] = []
    # Additional KOL data
    kol_master: Optional[KOLMaster] = None
    advisory_board: List[KOLAdvisoryBoard] = []
    congresses: List[KOLCongress] = []
    social_media: List[KOLSocialMedia] = []
    peer_portals: List[KOLPeerPortal] = []
    medscapes: List[KOLMedscape] = []
    comp_products: List[KOLCompProduct] = []
    doximity: List[KOLDoximity] = []
    speaker_bureau: List[SpeakerBureauEngagement] = []
    collaborations: List[MSLKOLInteractionSummary] = []