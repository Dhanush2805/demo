"""
CSV Cleaner Utility
Simple function to handle CSV null values and formatting errors
"""

import pandas as pd
import os
import re
import csv
import tempfile
from typing import Dict, Any, Optional
from app.core.logger import get_logger
from datetime import datetime

logger = get_logger('csv_cleaner')

def clean_csv_file(csv_file_path: str, output_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Simple single function to handle CSV null values and formatting errors
    
    Args:
        csv_file_path: Path to the CSV file to clean
        output_path: Optional output path. If None, overwrites the original file
    
    Returns:
        Dictionary with cleaning results and statistics
    """
    logger.info(f"Cleaning CSV file: {os.path.basename(csv_file_path)}")
    
    results = {
        'original_file': csv_file_path,
        'cleaned_file': output_path or csv_file_path,
        'null_values_fixed': 0,
        'quote_issues_fixed': 0,
        'string_issues_fixed': 0,
        'date_issues_fixed': 0,  # New field for date format fixes
        'rows_processed': 0,
        'success': False,
        'error_message': None
    }
    
    try:
        # Step 1: Fix content-level issues (quotes, encoding)
        fixed_content = _fix_csv_content(csv_file_path)
        results['quote_issues_fixed'] = fixed_content['quotes_fixed']
        
        # Step 2: Read and clean data
        df = _read_csv_safely(csv_file_path, fixed_content['content'])
        
        if df is None:
            raise Exception("Could not read CSV file")
        
        results['rows_processed'] = len(df)
        
        # Step 3: Handle null values
        original_nulls = df.isnull().sum().sum()
        df_cleaned = _clean_null_values(df)
        final_nulls = df_cleaned.isnull().sum().sum()
        results['null_values_fixed'] = original_nulls - final_nulls
        
        # Step 4: Sanitize strings for Cypher compatibility
        df_sanitized, string_fixes = _sanitize_strings_for_cypher(df_cleaned)
        results['string_issues_fixed'] = string_fixes
        
        # Step 5: Validate and fix date formats
        df_date_fixed, date_fixes = _validate_and_fix_dates(df_sanitized)
        results['date_issues_fixed'] = date_fixes
        
        # Step 6: Save cleaned file
        output_file = output_path or csv_file_path
        df_date_fixed.to_csv(output_file, index=False, quoting=csv.QUOTE_MINIMAL)
        
        results['success'] = True
        
        logger.info(f"CSV cleaning completed: {results['rows_processed']} rows, "
                   f"{results['null_values_fixed']} nulls fixed, "
                   f"{results['quote_issues_fixed']} quote issues fixed, "
                   f"{results['string_issues_fixed']} string issues fixed, "
                   f"{results['date_issues_fixed']} date issues fixed")
        
    except Exception as e:
        error_msg = f"CSV cleaning failed: {str(e)}"
        logger.error(error_msg)
        results['error_message'] = error_msg
        results['success'] = False
    
    return results

def _fix_csv_content(csv_file_path: str) -> Dict[str, Any]:
    """Fix content-level CSV issues like malformed quotes and encoding"""
    result = {
        'content': '',
        'quotes_fixed': 0
    }
    
    try:
        # Try different encodings
        encodings = ['utf-8', 'utf-8-sig', 'latin-1', 'cp1252']
        content = None
        
        for encoding in encodings:
            try:
                with open(csv_file_path, 'r', encoding=encoding) as f:
                    content = f.read()
                break
            except UnicodeDecodeError:
                continue
        
        if content is None:
            raise Exception("Could not decode file with any common encoding")
        
        # Fix common quote issues
        original_content = content
        
        # Fix the specific issue mentioned in logs: quotes followed by content
        # Pattern: "text"extra_content -> "text extra_content"
        pattern = r'"([^"]*)"([^",\n\r]+)'
        matches = re.findall(pattern, content)
        result['quotes_fixed'] = len(matches)
        content = re.sub(pattern, r'"\1 \2"', content)
        
        # Fix triple quotes and other malformed patterns
        content = re.sub(r'"""', r'""', content)
        result['quotes_fixed'] += original_content.count('"""')
        
        # Remove BOM if present
        if content.startswith('\ufeff'):
            content = content[1:]
        
        result['content'] = content
        
    except Exception as e:
        logger.error(f"Error fixing CSV content: {str(e)}")
        # Return original content if fixing fails
        try:
            with open(csv_file_path, 'r', encoding='utf-8') as f:
                result['content'] = f.read()
        except:
            result['content'] = ''
    
    return result

def _read_csv_safely(csv_file_path: str, fixed_content: str) -> Optional[pd.DataFrame]:
    """Safely read CSV with multiple fallback strategies"""
    
    # Strategy 1: Try reading original file
    try:
        df = pd.read_csv(
            csv_file_path,
            dtype=str,  # Read all as strings to avoid type issues
            na_values=['', 'NULL', 'null', 'None', 'none', 'N/A', 'n/a', 'NaN', 'nan'],
            keep_default_na=True,
            on_bad_lines='skip',
            quoting=csv.QUOTE_MINIMAL
        )
        return df
    except Exception as e:
        logger.warning(f"Standard CSV read failed: {str(e)}")
    
    # Strategy 2: Try with fixed content
    try:
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as temp_file:
            temp_file.write(fixed_content)
            temp_path = temp_file.name
        
        try:
            df = pd.read_csv(
                temp_path,
                dtype=str,
                na_values=['', 'NULL', 'null', 'None', 'none', 'N/A', 'n/a', 'NaN', 'nan'],
                keep_default_na=True,
                on_bad_lines='skip',
                quoting=csv.QUOTE_MINIMAL
            )
            return df
        finally:
            os.unlink(temp_path)
    except Exception as e:
        logger.warning(f"Fixed content CSV read failed: {str(e)}")
    
    # Strategy 3: Try with different parameters
    try:
        df = pd.read_csv(
            csv_file_path,
            dtype=str,
            na_values=[''],
            keep_default_na=False,
            on_bad_lines='skip',
            quoting=csv.QUOTE_NONE,
            engine='python'
        )
        return df
    except Exception as e:
        logger.error(f"All CSV read strategies failed: {str(e)}")
    
    return None

def _clean_null_values(df: pd.DataFrame) -> pd.DataFrame:
    """Clean null values with smart defaults based on column names"""
    df_cleaned = df.copy()
    
    for column in df_cleaned.columns:
        if df_cleaned[column].isnull().sum() == 0:
            continue
        
        column_lower = column.lower()
        
        # Smart defaults based on column names
        if any(keyword in column_lower for keyword in ['id', 'profile', 'appl']):
            # ID columns - use placeholder
            df_cleaned[column] = df_cleaned[column].fillna('UNKNOWN_ID')
        
        elif any(keyword in column_lower for keyword in ['name', 'title', 'term', 'description', 'text']):
            # Text columns - use placeholder
            df_cleaned[column] = df_cleaned[column].fillna('NOT_SPECIFIED')
        
        elif any(keyword in column_lower for keyword in ['date', 'year', 'start', 'end', 'time']):
            # Date columns - use placeholder date
            df_cleaned[column] = df_cleaned[column].fillna('1900-01-01')
        
        elif any(keyword in column_lower for keyword in ['amount', 'cost', 'budget', 'funding', 'total']):
            # Financial columns - use 0
            df_cleaned[column] = df_cleaned[column].fillna('0')
        
        elif any(keyword in column_lower for keyword in ['active', 'status', 'flag', 'is_']):
            # Boolean-like columns
            df_cleaned[column] = df_cleaned[column].fillna('false')
        
        else:
            # Default: empty string for unknown columns
            df_cleaned[column] = df_cleaned[column].fillna('')
    
    return df_cleaned

def _sanitize_strings_for_cypher(df: pd.DataFrame) -> tuple[pd.DataFrame, int]:
    """
    Sanitize string values to prevent Cypher syntax errors
    
    Args:
        df: DataFrame to sanitize
        
    Returns:
        Tuple of (sanitized_dataframe, number_of_fixes)
    """
    df_sanitized = df.copy()
    total_fixes = 0
    
    for column in df_sanitized.columns:
        if df_sanitized[column].dtype == 'object':  # String columns
            # Count original problematic strings
            original_values = df_sanitized[column].fillna('')
            
            # Apply sanitization
            sanitized_values = original_values.apply(_sanitize_string_value)
            
            # Count fixes
            fixes = sum(1 for orig, clean in zip(original_values, sanitized_values) if orig != clean)
            total_fixes += fixes
            
            # Update column
            df_sanitized[column] = sanitized_values
    
    return df_sanitized, total_fixes

def _sanitize_string_value(value: str) -> str:
    """
    Sanitize a single string value for Cypher compatibility
    
    Args:
        value: String value to sanitize
        
    Returns:
        Sanitized string safe for Cypher queries
    """
    if not isinstance(value, str) or not value:
        return value
    
    # Convert possessives to non-possessive form
    sanitized = re.sub(r"(\w)'s\b", r"\1s", value)  # "Women's" -> "Womens"
    
    # Fix other problematic characters
    sanitized = sanitized.replace('"', '"')  # Replace with curly quotes 
    sanitized = sanitized.replace('\\', '/')  # Replace backslashes
    
    # Remove or replace other special characters that might cause issues
    sanitized = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]', '', sanitized)  # Remove control characters
    
    return sanitized

def _validate_and_fix_dates(df: pd.DataFrame) -> tuple[pd.DataFrame, int]:
    """
    Validate and fix date formats in the DataFrame
    
    Args:
        df: DataFrame to validate and fix dates
        
    Returns:
        Tuple of (date_fixed_dataframe, number_of_fixes)
    """
    df_fixed = df.copy()
    total_fixes = 0
    
    for column in df_fixed.columns:
        column_lower = column.lower()
        
        # Check if column is likely a date column
        if any(keyword in column_lower for keyword in ['date', 'time', 'created', 'updated', 'start', 'end', 'year', 'month', 'day']):
            logger.info(f"Processing date column: {column}")
            
            # Apply date validation and conversion
            original_values = df_fixed[column].copy()
            df_fixed[column] = df_fixed[column].apply(_validate_and_convert_date)
            
            # Count fixes
            fixes = sum(1 for orig, fixed in zip(original_values, df_fixed[column]) if orig != fixed)
            total_fixes += fixes
            
            if fixes > 0:
                logger.info(f"Fixed {fixes} date values in column '{column}'")
    
    return df_fixed, total_fixes

def _validate_and_convert_date(value: str) -> str:
    """
    Validate and convert a single date value to a standardized format
    
    Args:
        value: Date value to validate and convert
        
    Returns:
        Standardized date format (YYYY-MM-DD) or default value for invalid dates
    """
    if not value or pd.isna(value) or value == '' or str(value).strip() == '':
        return '1900-01-01'  # Default date for empty values
    
    # Convert to string if not already
    value_str = str(value).strip()
    
    # Handle common problematic values
    if value_str.lower() in ['null', 'none', 'n/a', 'na', 'undefined', 'no_value']:
        return '1900-01-01'
    
    # Try to parse various date formats
    date_formats = [
        '%Y-%m-%d',           # 2023-12-25
        '%Y/%m/%d',           # 2023/12/25
        '%m/%d/%Y',           # 12/25/2023
        '%d/%m/%Y',           # 25/12/2023
        '%m-%d-%Y',           # 12-25-2023
        '%d-%m-%Y',           # 25-12-2023
        '%Y%m%d',             # 20231225
        '%Y-%m-%d %H:%M:%S',  # 2023-12-25 10:30:00
        '%Y/%m/%d %H:%M:%S',  # 2023/12/25 10:30:00
        '%m/%d/%Y %H:%M:%S',  # 12/25/2023 10:30:00
        '%d/%m/%Y %H:%M:%S',  # 25/12/2023 10:30:00
        '%Y-%m-%dT%H:%M:%S',  # 2023-12-25T10:30:00 (ISO format)
        '%Y-%m-%dT%H:%M:%SZ', # 2023-12-25T10:30:00Z (ISO with Z)
    ]
    
    # Try parsing with each format
    for fmt in date_formats:
        try:
            parsed_date = datetime.strptime(value_str, fmt)
            return parsed_date.strftime('%Y-%m-%d')  # Return in standard format
        except ValueError:
            continue
    
    # Try parsing Unix timestamp (seconds or milliseconds)
    try:
        # Check if it's a numeric timestamp
        if value_str.isdigit():
            timestamp = int(value_str)
            
            # Handle milliseconds timestamp (typical range > 1e12)
            if timestamp > 1e12:
                timestamp = timestamp / 1000
            
            # Convert to datetime
            parsed_date = datetime.fromtimestamp(timestamp)
            return parsed_date.strftime('%Y-%m-%d')
    except (ValueError, OSError):
        pass
    
    # Try partial date parsing (e.g., "2023", "2023-12")
    try:
        # Handle year only
        if len(value_str) == 4 and value_str.isdigit():
            year = int(value_str)
            if 1900 <= year <= 2100:  # Reasonable year range
                return f"{year}-01-01"
        
        # Handle year-month format
        if re.match(r'^\d{4}-\d{1,2}$', value_str):
            parts = value_str.split('-')
            year, month = int(parts[0]), int(parts[1])
            if 1900 <= year <= 2100 and 1 <= month <= 12:
                return f"{year}-{month:02d}-01"
    except (ValueError, IndexError):
        pass
    
    # If all parsing attempts fail, log and return default
    logger.warning(f"Could not parse date value: '{value_str}', using default date")
    return '1900-01-01'

 