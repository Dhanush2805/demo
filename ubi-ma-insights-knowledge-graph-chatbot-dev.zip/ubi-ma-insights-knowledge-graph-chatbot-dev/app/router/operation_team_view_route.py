import json
from fastapi import APIRouter, HTTPException
from uuid import UUID
from app.core.logger import get_logger
from app.agents.postgresql_agent import postgresql_agent, init_db_connection

router = APIRouter(prefix="/api/v1/operations/rules", tags=["Operations Team Rules"])
logger = get_logger("operations_team_rules")

@router.get("/{user_id}")
def get_rules(user_id: UUID):
    """Get rules for a specific user."""
    try:
        if not postgresql_agent.connection_pool:
            init_db_connection()

        select_query = f"""
            SELECT 
                id,
                user_id,
                rules,
                created_at,
                updated_at
            FROM "{postgresql_agent.schema}".operations_team_view_rules
            WHERE user_id = %(user_id)s;
        """

        result = postgresql_agent.execute_query(select_query, {"user_id": str(user_id)})

        if not result.data:
            raise HTTPException(status_code=404, detail=f"No rules found for user {user_id}")

        return result.data[0]

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching rules for user {user_id}: {str(e)}")
        raise HTTPException(status_code=500, detail="Error fetching user rules")


@router.put("/{user_id}")
def upsert_rules(user_id: UUID, payload: dict):
    """
    Update or create rules object for the given user.
    Body: { "rules": { ... } }
    """
    try:
        if not postgresql_agent.connection_pool:
            init_db_connection()

        if "rules" not in payload:
            raise HTTPException(status_code=400, detail="`rules` object is required")

        # Convert dict → JSON string
        rules_json = json.dumps(payload["rules"])

        # Check existing row
        check_query = f"""
            SELECT id
            FROM "{postgresql_agent.schema}".operations_team_view_rules
            WHERE user_id = %(user_id)s;
        """

        existing = postgresql_agent.execute_query(
            check_query, {"user_id": str(user_id)}
        )

        # -------------------
        # UPDATE
        # -------------------
        if existing and existing.data:
            update_query = f"""
                UPDATE "{postgresql_agent.schema}".operations_team_view_rules
                SET rules = %(rules)s::jsonb,
                    updated_at = NOW()
                WHERE user_id = %(user_id)s
                RETURNING *;
            """

            params = {
                "rules": rules_json,
                "user_id": str(user_id)
            }

            result = postgresql_agent.execute_query(update_query, params)
            return result.data[0]

        # -------------------
        # INSERT
        # -------------------
        insert_query = f"""
            INSERT INTO "{postgresql_agent.schema}".operations_team_view_rules
                (user_id, rules)
            VALUES (
                %(user_id)s,
                %(rules)s::jsonb
            )
            RETURNING *;
        """

        params = {
            "user_id": str(user_id),
            "rules": rules_json
        }

        result = postgresql_agent.execute_query(insert_query, params)
        return result.data[0]

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating rules for user {user_id}: {str(e)}")
        raise HTTPException(status_code=500, detail="Error updating user rules")