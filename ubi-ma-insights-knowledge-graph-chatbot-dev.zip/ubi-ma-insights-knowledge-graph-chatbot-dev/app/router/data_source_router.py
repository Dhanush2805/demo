import json
from typing import Optional
from fastapi import APIRouter, Query
from app.core.logger import get_logger
from app.core.models import ListResponse, GenericResponse, IngestionCreateRequest, JobRequest, RunJobRequest
from app.agents.aws_s3_agent import s3_agent
from app.agents.data_bricks_agent import databricks
from app.agents.postgresql_agent import postgresql_agent, init_db_connection
from psycopg2.extras import Json

router = APIRouter(prefix="/api/v1", tags=["data_ingestions"])
logger = get_logger('data_ingestions_api')

def getErrorResponse(message: str = "An unexpected server error occurred. Please try again later."):
     return ListResponse(
        success=False,
        message=message,
        data=None,
        total_count=0
    )

@router.get("/s3-buckets")
def get_buckets():
    """Get all S3 buckets."""
    try:
        buckets = s3_agent.get_all_buckets()

        return ListResponse(
            success=True,
            message="Buckets retrieved successfully",
            data=buckets,
            total_count=len(buckets)
        )
    except Exception as e:
        logger.error(f"Error retrieving Buckets: {str(e)}")
        return getErrorResponse()
    
@router.get("/s3-buckets/file-columns")
def get_bucket_file_columns(
    bucket_name: Optional[str] = Query(None, description="S3 bucket name"),
    file_path: Optional[str] = Query(None, description="File path/key in the S3 bucket")
):
    """
    Get column names from a file stored in AWS S3.
    Supports CSV, XLSX, XLS, and Parquet formats.
    """
    try:
        columns = s3_agent.get_s3_file_columns(bucket_name, file_path)

        return ListResponse(
            success=True,
            message="File columns retrieved successfully",
            data=columns,
            total_count=len(columns)
        )
    except Exception as e:
        logger.error(f"Error while retrieving file columns from S3: {str(e)}", exc_info=True)
        return getErrorResponse()

@router.get("/s3-buckets/{bucket_name}")
def get_bucket_files(bucket_name: str):
    """Get recursive folder/file structure for a bucket."""
    try:
        keys = s3_agent.get_bucket_objects(bucket_name)
        data={
            "id": bucket_name,
            "name": bucket_name,
            "objectType": "folder",
            "children": [],
        }
        
        if keys:
            tree = s3_agent.build_tree_with_metadata(keys)
            data = {
                "id": bucket_name,
                "name": bucket_name,
                "objectType": "folder",
                "children": tree,
            }

        return GenericResponse(
            success=True,
            message="Bucket Details retrieved successfully",
            data=data
        )
    
    except Exception as e:
        logger.error(f"Error retrieving Bucket Details: {str(e)}")
        return GenericResponse(
            success=False,
            message=f"Failed to retrieve bucket '{bucket_name}' details. Please check logs for details.",
            data=None
        )


@router.get("/db/tables")
def get_tables():
    """Get all ."""
    try:
        if not postgresql_agent.connection_pool:
            init_db_connection()
        schema = postgresql_agent.data_ingestion_schema
        tables = postgresql_agent.get_all_tables(schema)
        return ListResponse(
            success=True,
            message="Tables retrieved successfully",
            data=tables,
            total_count=len(tables)
        )
    except Exception as e:
        logger.error(f"Error retrieving tables : {str(e)}")
        return getErrorResponse()

    
@router.get("/db/tables/{table_name}")
def get_table_info(table_name: str):
    try:
        if not postgresql_agent.connection_pool:
            init_db_connection()
        schema = postgresql_agent.data_ingestion_schema
        table = postgresql_agent.get_table_data(table_name, schema)
        return ListResponse(
            success=True,
            message="Table Details retrieved successfully",
            data=table,
            total_count=len(table)
        )
    except Exception as e:
        msg = f"Error while retrieving {table_name} Details"
        logger.error(f"{msg}: {str(e)}")
        return getErrorResponse(msg)
    
@router.get("/data_ingestions")
def get_all_ingestion_pipelines():
    """Get all active (non-deleted) ingestion pipelines."""
    try:
        select_query = f"""
            SELECT id, source, source_details, target, target_details,
                   mapping_data, status, last_run, created_at, updated_at, databricks_job_id, last_run_id, last_run_status 
            FROM "{postgresql_agent.schema}".data_ingestion_pipelines
            WHERE is_deleted = FALSE
            ORDER BY created_at DESC;
        """
        if not postgresql_agent.connection_pool:
            init_db_connection()

        result = postgresql_agent.execute_query(select_query)

        return ListResponse(
            success=True,
            message="Ingestion pipelines retrieved successfully.",
            data=result.data,
            total_count=len(result.data)
        )

    except Exception as e:
        msg = "Error retrieving ingestion pipeline"
        logger.error(f"{msg}: {str(e)}")
        return getErrorResponse(msg)


@router.post("/data_ingestions")
def create_ingestion_pipeline(request: IngestionCreateRequest):
    """Create a new data ingestion pipeline."""
    try:
        insert_query = f"""
            INSERT INTO "{postgresql_agent.schema}".data_ingestion_pipelines (
                source, source_details, target, target_details, mapping_data,
                status, last_run, is_deleted, databricks_job_id, last_run_id, last_run_status,updated_at
            )
            VALUES (
                %(source)s, %(source_details)s, %(target)s, %(target_details)s, %(mapping_data)s,
                %(status)s, %(last_run)s, %(is_deleted)s, %(databricks_job_id)s, %(last_run_id)s, %(last_run_status)s, %(updated_at)s
            )
            RETURNING id, created_at;
        """

        params = {
            "source": request.source,
            "source_details": Json(request.source_details),
            "target": request.target,
            "target_details": Json(request.target_details),
            "mapping_data": Json(request.mapping_data),
            "status": "Not Started",
            "last_run": None,
            "is_deleted": False,
            "databricks_job_id": request.databricks_job_id if hasattr(request, "databricks_job_id") else None ,
            "last_run_id":  request.last_run_id if hasattr(request, "last_run_id") else None , 
            "last_run_status":request.last_run_status if hasattr(request, "last_run_status") else None,
            "updated_at": None
        }

        if not postgresql_agent.connection_pool:
            init_db_connection()

        result = postgresql_agent.execute_query(insert_query, params)

        return GenericResponse(
            success = True,
            message = "Ingestion pipeline created successfully.",
            data = result.data
        )
    
    except Exception as e:
        msg = "Error inserting ingestion pipeline"
        logger.error(f"{msg}: {str(e)}")
        return getErrorResponse(msg)
    
@router.put("/data_ingestions/{ingestion_id}")
def update_ingestion_pipeline(ingestion_id: str, request: IngestionCreateRequest):
    """Update an existing data ingestion pipeline."""
    try:
        update_query = f"""
            UPDATE "{postgresql_agent.schema}".data_ingestion_pipelines
            SET
                source = %(source)s,
                source_details = %(source_details)s,
                target = %(target)s,
                target_details = %(target_details)s,
                mapping_data = %(mapping_data)s,
                updated_at = NOW()
            WHERE id = %(id)s
            RETURNING id, updated_at;
        """

        params = {
            "id": ingestion_id,
            "source": request.source,
            "source_details": Json(request.source_details),
            "target": request.target,
            "target_details": Json(request.target_details),
            "mapping_data": Json(request.mapping_data)
        }

        if not postgresql_agent.connection_pool:
            init_db_connection()

        result = postgresql_agent.execute_query(update_query, params)

        if not result.data:
            return getErrorResponse(f"Ingestion pipeline with id {ingestion_id} not found")

        return GenericResponse(
            success=True,
            message="Ingestion pipeline updated successfully.",
            data= result.data
        )

    except Exception as e:
        msg = "Error updating ingestion pipeline"
        logger.error(f"{msg}: {str(e)}")
        return getErrorResponse(msg)

@router.delete("/data_ingestions/{ingestion_id}")
def delete_ingestion_pipeline(ingestion_id: str):
    """Soft delete an ingestion pipeline (set is_deleted = true)."""
    try:
        delete_query = f"""
            UPDATE "{postgresql_agent.schema}".data_ingestion_pipelines
            SET is_deleted = TRUE,
                deleted_at = NOW()
            WHERE id = %(id)s
            RETURNING id, deleted_at;
        """

        params = {"id": ingestion_id}

        if not postgresql_agent.connection_pool:
            init_db_connection()

        result = postgresql_agent.execute_query(delete_query, params)

        if not result.data:
            return getErrorResponse(f"Ingestion pipeline with id {ingestion_id} not found")

        return GenericResponse(
            success=True,
            message=f"Ingestion pipeline with id {ingestion_id} deleted successfully.",
            data=result.data
        )

    except Exception as e:
        msg = "Error deleting ingestion pipeline"
        logger.error(f"{msg}: {str(e)}")
        return getErrorResponse(msg)
    

@router.post("/data_ingestions/run_job")
def run_databricks_job(request: RunJobRequest):
    """Trigger a specific Databricks job for given data ingestion ID."""
    try:
        ingestion_id = request.ingestion_id
        if not postgresql_agent.connection_pool:
            init_db_connection()

        query = f"""
            SELECT databricks_job_id
            FROM "{postgresql_agent.schema}".data_ingestion_pipelines
            WHERE id = %(id)s;
        """
        params = {"id": ingestion_id}
        result = postgresql_agent.execute_query(query, params)

        if not result.data:
            return getErrorResponse(f"Ingestion pipeline with id {ingestion_id} not found")

        job_id = result.data[0]["databricks_job_id"]
        run_id = None
        last_run_status = "UNKNOWN"

        if job_id:
            notebook_params = databricks.get_notebook_params(ingestion_id)
            payload =  {"job_id": job_id, "notebook_params": notebook_params }
            response = databricks.post(
            "/api/2.2/jobs/run-now",
               payload
            )
            logger.error(f"response:{response.json()}")

            if response.status_code != 200:
                return getErrorResponse(f"error while triggering job id: {job_id}")
            
            run_id = response.json().get("run_id")
            if run_id:
                last_run_status = "RUNNING"
        else:
            return clone_databricks_job(ingestion_id)

        update_query = f"""
            UPDATE "{postgresql_agent.schema}".data_ingestion_pipelines
            SET last_run_id = %(run_id)s,
                last_run_status = %(last_run_status)s,
                last_run = NOW()
            WHERE id = %(id)s
            RETURNING id, last_run_id, last_run_status, last_run;
        """
        update_params = {"id": ingestion_id, "run_id": run_id, "last_run_status": last_run_status}
        update_result = postgresql_agent.execute_query(update_query, update_params)

        return GenericResponse(
            success=True,
            message="Databricks job triggered successfully.",
            data=update_result.data
        )

    except Exception as e:
        msg = f"Error running Databricks job: {str(e)}"
        logger.error(msg)
        return getErrorResponse(msg)
    

@router.post("/data_ingestions/cancel_job")
def cancel_databricks_job(request: JobRequest):
    """Cancel an active Databricks job run."""
    try:
        ingestion_id = request.ingestion_id
        last_run_id = request.last_run_id

        if not postgresql_agent.connection_pool:
            init_db_connection()

        if not last_run_id:
            query = f"""
                SELECT last_run_id FROM "{postgresql_agent.schema}".data_ingestion_pipelines
                WHERE id = %(id)s;
            """
            params = {"id": ingestion_id}
            result = postgresql_agent.execute_query(query, params)
            if not result.data or not result.data[0]["last_run_id"]:
                return getErrorResponse(f"No last_run_id found for pipeline {ingestion_id}")
            last_run_id = result.data[0]["last_run_id"]

        response = databricks.post(
           "/api/2.2/jobs/runs/cancel",
            {"run_id": last_run_id}
        )
        logger.error(f"response:{response.json()}")

        last_run_status = "CANCELED"
        
        if response.status_code != 200:
            return getErrorResponse(f"error while Canceling last run id: {last_run_id}")
        
        if response.json().get("state", None):
            state = response.json().get("state", {})
            life_cycle_state = state.get("life_cycle_state", "UNKNOWN")
            result_state = state.get("result_state", None)
            last_run_status = result_state or life_cycle_state or "UNKNOWN"
            logger.info(f"Databricks job status response: {last_run_status}")

        update_query = f"""
            UPDATE "{postgresql_agent.schema}".data_ingestion_pipelines
            SET last_run_status = %(status)s
            WHERE id = %(id)s
            RETURNING id, last_run_id, last_run_status;
        """
        params = {"id": ingestion_id, "status": last_run_status}
        result = postgresql_agent.execute_query(update_query, params)

        return GenericResponse(
            success=True,
            message=f"Databricks job status: {last_run_status}.",
            data=result.data
        )

    except Exception as e:
        msg = f"Error canceling Databricks job: {str(e)}"
        logger.error(msg)
        return getErrorResponse(msg)


@router.post("/data_ingestions/job_status")
def check_job_status(request: JobRequest):
    """Fetch the latest Databricks job run status for a given ingestion pipeline."""
    try:
        ingestion_id = request.ingestion_id
        last_run_id = request.last_run_id
        if not postgresql_agent.connection_pool:
            init_db_connection()

        # Step 1: Fetch last_run_id from DB if not provided
        if not last_run_id:
            query = f"""
                SELECT last_run_id FROM "{postgresql_agent.schema}".data_ingestion_pipelines
                WHERE id = %(id)s;
            """
            params = {"id": ingestion_id}
            result = postgresql_agent.execute_query(query, params)
            if not result.data or not result.data[0]["last_run_id"]:
                return getErrorResponse(f"No last_run_id found for pipeline {ingestion_id}")
            last_run_id = result.data[0]["last_run_id"]

        # Step 2: Call Databricks API
        response = databricks.get(f"/api/2.2/jobs/runs/get", {"run_id": last_run_id})

        # Step 3: Parse response JSON
        data = response.json()
        logger.info(f"Databricks job status response: {data}")

        state = data.get("state", {})
        life_cycle_state = state.get("life_cycle_state", "UNKNOWN")
        result_state = state.get("result_state", None)

        # Step 4: Determine current status
        current_status = result_state or life_cycle_state or "UNKNOWN"

        # Step 6: Update DB and return success
        update_query = f"""
            UPDATE "{postgresql_agent.schema}".data_ingestion_pipelines
            SET last_run_status = %(status)s
            WHERE id = %(id)s
            RETURNING id, last_run_id, last_run_status;
        """
        update_params = {"id": ingestion_id, "status": current_status}
        update_result = postgresql_agent.execute_query(update_query, update_params)

        return GenericResponse(
            success=True,
            message="Job status fetched successfully.",
            data=update_result.data
        )

    except Exception as e:
        msg = f"Error fetching Databricks job status: {str(e)}"
        logger.error(msg)
        return getErrorResponse(msg)



@router.get("/data_ingestions/{ingestion_id}/clone_job", include_in_schema=False)
def clone_databricks_job(ingestion_id: str):
    """Clone a new Databricks job from the default job and trigger it."""
    try:
        if not postgresql_agent.connection_pool:
            init_db_connection()
        
        default_job = databricks.default_job

        logger.info(f"No job found for ingestion_id={ingestion_id}. Cloning from default job {default_job}")

        # Step 1: Fetch default job definition
        job_resp = databricks.get("/api/2.2/jobs/get", {"job_id": default_job})
        if job_resp.status_code != 200:
            return getErrorResponse(f"Failed to fetch default job {default_job}")

        job_def = job_resp.json()
        settings = job_def.get("settings", {})

        # Step 2: Modify job name for uniqueness
        settings["name"] = settings.get("name", "Default Job") + f" - clone-{ingestion_id}"

        # Step 3: Create a new job from default
        create_resp = databricks.post("/api/2.2/jobs/create", settings)
        if create_resp.status_code != 200:
            return getErrorResponse("Failed to create new Databricks job")

        new_job_id = create_resp.json().get("job_id")
        if not new_job_id:
            return getErrorResponse("New job creation failed — no job_id returned")

        logger.info(f"Created new job_id={new_job_id} for ingestion_id={ingestion_id}")

        # Step 4: Save new job_id in DB
        update_job_query = f"""
            UPDATE "{postgresql_agent.schema}".data_ingestion_pipelines
            SET databricks_job_id = %(job_id)s
            WHERE id = %(id)s;
        """
        postgresql_agent.execute_query(update_job_query, {"id": ingestion_id, "job_id": new_job_id})

        # Step 5: Trigger the new job immediately
        notebook_params = databricks.get_notebook_params(ingestion_id)
        payload =  {"job_id": new_job_id, "notebook_params": notebook_params }
        run_resp = databricks.post("/api/2.2/jobs/run-now", payload)
        if run_resp.status_code != 200:
            return getErrorResponse(f"Error while triggering newly created job id: {new_job_id}")

        run_id = run_resp.json().get("run_id")

        # Step 6: Update run_id and status
        update_query = f"""
            UPDATE "{postgresql_agent.schema}".data_ingestion_pipelines
            SET last_run_id = %(run_id)s,
                last_run_status = 'RUNNING',
                last_run = NOW()
            WHERE id = %(id)s
            RETURNING id, databricks_job_id, last_run_id, last_run_status, last_run;
        """
        update_params = {"id": ingestion_id, "run_id": run_id}
        update_result = postgresql_agent.execute_query(update_query, update_params)

        return GenericResponse(
            success=True,
            message=f"New Databricks job (ID: {new_job_id}) cloned and triggered successfully.",
            data=update_result.data
        )

    except Exception as e:
        msg = f"Error while cloning Databricks job: {str(e)}"
        logger.error(msg)
        return getErrorResponse(msg)
