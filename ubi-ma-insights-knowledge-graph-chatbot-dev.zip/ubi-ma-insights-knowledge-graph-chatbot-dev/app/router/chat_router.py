from fastapi import APIRouter, HTTPException
from typing import Dict, Any, Optional
from app.core.logger import get_logger
from app.core.models import ChatRequest, ChatResponse
from app.agents.chat_agent import ChatAgent
from app.services.config_service import config
from app.services.cache_service import CacheService

# Initialize logger and router
logger = get_logger('api')
router = APIRouter(prefix="/api/v1/chat", tags=["chat"])

# Initialize chat agent and cache service
chat_agent = ChatAgent()
cache_service = CacheService.get_instance()

@router.post("/query", response_model=ChatResponse)
async def process_chat_query(request: ChatRequest) -> ChatResponse:
    """
    Process a chat question and return an answer from the knowledge graph
    
    This endpoint:
    1. Searches vector database for relevant context (if requested)
    2. Retrieves current Neo4j schema information
    3. Generates appropriate Cypher query using LLM
    4. Executes query against Neo4j database
    5. Summarizes results into natural language response
    
    Args:
        request: ChatRequest containing the user's question and options
        
    Returns:
        ChatResponse with answer, sources, and metadata
        
    Note:
        LLM provider is configured via LLM_PROVIDER environment variable.
        For Azure OpenAI: No additional credentials needed (configured in AZURE_OPENAI_* variables)
        For AWS Bedrock: AWS credentials required (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY)
    """
    logger.info(f"Chat API endpoint called with question: '{request.question[:50]}...'")
    
    try:
        # Handle credentials based on LLM provider
        aws_credentials = None
        
        if config.llm.provider.lower() == "bedrock":
            # Only require AWS credentials for Bedrock
            aws_credentials = config.get_aws_credentials_from_env()
            
            if not aws_credentials:
                error_msg = "AWS credentials required for Bedrock provider. Please set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY environment variables."
                logger.error(error_msg)
                raise HTTPException(status_code=400, detail=error_msg)
        elif config.llm.provider.lower() == "azure_openai":
            # Azure OpenAI doesn't need AWS credentials
            logger.info("Using Azure OpenAI provider - no AWS credentials required")
        else:
            error_msg = f"Unsupported LLM provider: {config.llm.provider}"
            logger.error(error_msg)
            raise HTTPException(status_code=400, detail=error_msg)
        
        
        # Process the question
        logger.info(f"Starting chat processing with {config.llm.provider} provider")
        response = chat_agent.process_question(request, aws_credentials)
        
        if response.success:
            logger.info(f"Chat completed successfully in {response.processing_time:.2f}s")
        else:
            logger.error(f"Chat processing failed: {response.error}")
            # Return 422 for processing errors (valid request but processing failed)
            raise HTTPException(status_code=422, detail=response.answer)
        
        return response
        
    except HTTPException:
        # Re-raise HTTP exceptions
        raise
    except Exception as e:
        error_msg = f"Unexpected error in chat endpoint: {str(e)}"
        logger.error(error_msg, exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")



@router.get("/health", response_model=Dict[str, str])
async def health_check() -> Dict[str, str]:
    """
    Simple health check endpoint
    
    Returns:
        Dictionary with health status
    """
    return {
        "status": "healthy",
        "service": "chat-service",
        "message": "Chat service is running"
    }


@router.get("/cache/stats", response_model=Dict[str, Any])
async def get_cache_stats() -> Dict[str, Any]:
    """
    Get cache statistics
    
    Returns:
        Dictionary with cache statistics
    """
    try:
        stats = cache_service.get_cache_stats()
        return {
            "success": True,
            "cache_stats": stats
        }
    except Exception as e:
        logger.error(f"Failed to get cache stats: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get cache stats: {str(e)}")


@router.delete("/cache/clear")
async def clear_cache() -> Dict[str, Any]:
    """
    Clear all cached entries
    
    Returns:
        Dictionary with operation result
    """
    try:
        cache_service.clear_cache()
        return {
            "success": True,
            "message": "Cache cleared successfully"
        }
    except Exception as e:
        logger.error(f"Failed to clear cache: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to clear cache: {str(e)}")
