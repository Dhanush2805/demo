import time
import json
from typing import Dict, Any, Optional
from fastapi import APIRouter, HTTPException
from app.core.logger import get_logger
from app.core.models import CDPNLQRequest, CDPNLQResponse
from app.agents.postgresql_agent import PostgreSQLAgent
from app.agents.llm_agent import LLMAgent
from app.services.config_service import config

logger = get_logger('cdp_nlq_api')
router = APIRouter(prefix="/api/v1/cdp-nlq", tags=["cdp-nlq"])

postgres_agent = PostgreSQLAgent()
llm_agent = LLMAgent()

CDP_TABLES = [
    "test_nih_projects", "test_nih_publications", "test_nih_authors", "test_kol_master", "test_kol_congress",
     "g360_survey_insights" , "g360_interaction_insights"
]

def init_db_connection():
    """Initialize database connection"""
    success = postgres_agent.connect()
    if not success:
        logger.error("Failed to connect to PostgreSQL database")
        raise Exception("Database connection failed")
    logger.info("CDP NLQ API connected to PostgreSQL successfully")

@router.post("/query", response_model=CDPNLQResponse)
async def process_cdp_nlq_query(request: CDPNLQRequest) -> CDPNLQResponse:
    """Process natural language query against CDP data and return results with optional graph visualization"""
    start_time = time.time()
    logger.info(f"CDP NLQ API endpoint called with query: '{request.query[:100]}...'")
    
    try:
        if not postgres_agent.connection_pool:
            init_db_connection()
        
        schema_info = {}

        try:
            for table_name in CDP_TABLES:
                try:
                    table_schema = postgres_agent.get_table_data(table_name, postgres_agent.schema)
                    table_comment = postgres_agent.get_table_comment(table_name, postgres_agent.schema)
                    
                    row_count_query = f'SELECT COUNT(*) AS row_count FROM "{postgres_agent.schema}"."{table_name}"'
                    row_result = postgres_agent.execute_query(row_count_query)
                    row_count = row_result.data[0]["row_count"] if row_result.success and row_result.data else 0
                    
                    schema_info[table_name] = {
                        "table_comment": table_comment,
                        "row_count": row_count,
                        "column_count": len(table_schema),
                        "columns": table_schema
                    }
                except Exception as table_error:
                    logger.error(f"Failed to get schema for CDP table {table_name}: {str(table_error)}")
                    schema_info[table_name] = {"table_comment": "", "row_count": 0, "column_count": 0, "columns": []}
                
            
        except Exception as e:
            error_msg = f"Failed to retrieve database schema: {str(e)}"
            logger.error(error_msg)
            return CDPNLQResponse(
                success=False,
                message="Failed to retrieve database schema",
                query=request.query,
                error=error_msg,
                processing_time=time.time() - start_time
            )
        
        if not schema_info:
            return CDPNLQResponse(
                success=False,
                message="No tables found in ubi-ma-insights schema",
                query=request.query,
                error="Empty database schema",
                processing_time=time.time() - start_time
            )
        
        
        try:
            if config.llm.provider.lower() == "bedrock":
                aws_credentials = config.get_aws_credentials_from_env()
                if not aws_credentials:
                    error_msg = "AWS credentials required for Bedrock provider"
                    logger.error(error_msg)
                    raise HTTPException(status_code=400, detail=error_msg)
            
            sql_query = llm_agent.generate_sql_from_nlq(
                request.query, 
                schema_info, 
                request.max_results
            )
            
            if not sql_query:
                return CDPNLQResponse(
                    success=False,
                    message="Failed to generate SQL query from natural language",
                    query=request.query,
                    error="LLM failed to generate valid SQL",
                    processing_time=time.time() - start_time
                )

            # Qualify table names with schema
            sql_query = _qualify_table_names_with_schema(sql_query, CDP_TABLES, postgres_agent.schema)

        except Exception as e:
            error_msg = f"SQL generation failed: {str(e)}"
            logger.error(error_msg)
            return CDPNLQResponse(
                success=False,
                message="Failed to generate SQL query",
                query=request.query,
                error=error_msg,
                processing_time=time.time() - start_time
            )

        # Step 4: Execute SQL query
        logger.info(f"Executing generated SQL query: {sql_query[:100]}...")
        
        try:
            result = postgres_agent.execute_query(sql_query, None)
            
            if not result.success:
                error_msg = f"SQL execution failed: {result.error}"
                logger.error(error_msg)
                return CDPNLQResponse(
                    success=False,
                    message="Failed to execute generated SQL query",
                    query=request.query,
                    sql_query=sql_query,
                    error=error_msg,
                    processing_time=time.time() - start_time
                )
            
            query_data = result.data or []
            total_count = len(query_data)
            
            
        except Exception as e:
            error_msg = f"Query execution error: {str(e)}"
            logger.error(error_msg)
            return CDPNLQResponse(
                success=False,
                message="Error executing SQL query",
                query=request.query,
                sql_query=sql_query,
                error=error_msg,
                processing_time=time.time() - start_time
            )
        
        html_code = None
        is_graph = False

        if request.include_graph and query_data:
            try:
                graph_data = _generate_graph_from_data(query_data, request.query)
                
                if graph_data and graph_data.get('html_code'):
                    html_code = graph_data['html_code']
                    is_graph = bool(html_code and html_code.strip())
                    
                    if is_graph:
                        logger.info("Graph visualization generated successfully")
                    else:
                        logger.info("No meaningful graph could be generated from the data")
                        
            except Exception as e:
                logger.warning(f"Graph generation failed: {str(e)} - continuing without graph")
                html_code = None
                is_graph = False
        
        # Step 6: Create response
        processing_time = time.time() - start_time
        
        response = CDPNLQResponse(
            success=True,
            message=f"Query processed successfully, returned {total_count} results",
            query=request.query,
            sql_query=sql_query,
            data=query_data,
            total_count=total_count,
            is_graph=is_graph,
            html_code=html_code,
            processing_time=processing_time
        )
        
        logger.info(f"CDP NLQ query completed successfully in {processing_time:.2f}s")
        return response
        
    except HTTPException:
        # Re-raise HTTP exceptions
        raise
    except Exception as e:
        error_msg = f"Unexpected error in CDP NLQ endpoint: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return CDPNLQResponse(
            success=False,
            message="Internal server error during query processing",
            query=request.query,
            error=error_msg,
            processing_time=time.time() - start_time
        )

def _qualify_table_names_with_schema(sql_query: str, cdp_tables: list, schema: str) -> str:
    """Qualify table names in SQL query with proper schema prefix"""
    import re

    # Create a mapping of table names to qualified names
    qualified_tables = {}
    for table in cdp_tables:
        # Use regex to replace table names that are not already qualified
        # Match word boundaries around table names
        pattern = r'\b' + re.escape(table) + r'\b'
        qualified_name = f'"{schema}"."{table}"'
        sql_query = re.sub(pattern, qualified_name, sql_query)

    return sql_query

def _generate_graph_from_data(data: list, query: str) -> Optional[Dict[str, Any]]:
    try:
        if not data:
            return None

        data_text = f"Query: {query}\n\nResults:\n"
        for i, row in enumerate(data[:10]):
            data_text += f"Row {i+1}: {json.dumps(row, default=str)}\n"
        if len(data) > 10:
            data_text += f"... and {len(data) - 10} more rows\n"

        insights = llm_agent.generate_text_insights(data_text)
        
        if insights and insights.get('graph') and insights['graph'].get('html_code'):
            return {
                'html_code': insights['graph']['html_code'],
                'consolidated_insights': insights.get('consolidated_insights', '')
            }
        
        return None
        
    except Exception as e:
        logger.error(f"Error generating graph from data: {str(e)}")
        return None

@router.get("/health")
async def health_check():
    """Health check endpoint for CDP NLQ service"""
    try:
        # Test database connection
        if not postgres_agent.connection_pool:
            init_db_connection()
        
        # Test basic query
        test_result = postgres_agent.execute_query("SELECT 1 as test", None)
        
        if test_result.success:
            return {
                "status": "healthy",
                "service": "cdp-nlq",
                "database": "connected",
                "llm_provider": config.llm.provider
            }
        else:
            return {
                "status": "degraded",
                "service": "cdp-nlq",
                "database": "connection_failed",
                "error": test_result.error
            }
            
    except Exception as e:
        logger.error(f"Health check failed: {str(e)}")
        return {
            "status": "unhealthy",
            "service": "cdp-nlq",
            "error": str(e)
        }

@router.get("/schema")
async def get_schema_info():
    """Get available schema information for CDP tables"""
    try:
        if not postgres_agent.connection_pool:
            init_db_connection()
        
        schema_info = {}
        for table_name in CDP_TABLES:
            try:
                table_schema = postgres_agent.get_table_data(table_name, postgres_agent.schema)
                table_comment = postgres_agent.get_table_comment(table_name, postgres_agent.schema)

                row_count_query = f'SELECT COUNT(*) AS row_count FROM "{postgres_agent.schema}"."{table_name}"'
                row_result = postgres_agent.execute_query(row_count_query)
                row_count = row_result.data[0]["row_count"] if row_result.success and row_result.data else 0

                schema_info[table_name] = {
                    "table_comment": table_comment,
                    "row_count": row_count,
                    "column_count": len(table_schema),
                    "columns": table_schema
                }
            except Exception as table_error:
                logger.error(f"Failed to get schema for CDP table {table_name}: {str(table_error)}")
                schema_info[table_name] = {"table_comment": "", "row_count": 0, "column_count": 0, "columns": []}
            except Exception as table_error:
                logger.error(f"Failed to get schema for CDP table {table_name}: {str(table_error)}")
                schema_info[table_name] = {
                    "table_comment": "",
                    "row_count": 0,
                    "column_count": 0,
                    "columns": []
                }
        
        return {
            "success": True,
            "schema": postgres_agent.schema,
            "tables_count": len(schema_info),
            "total_tables": len(CDP_TABLES),
            "cdp_tables": CDP_TABLES,
            "tables": schema_info
        }
        
    except Exception as e:
        error_msg = f"Failed to retrieve schema information: {str(e)}"
        logger.error(error_msg, exc_info=True)
        raise HTTPException(status_code=500, detail=error_msg)
