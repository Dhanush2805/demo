from fastapi import APIRouter, HTTPException, Query, BackgroundTasks
from typing import List, Optional
import json
import asyncio
from app.core.logger import get_logger
from app.core.models import (
    InsightResponse, PublicationResponse, ProjectResponse,
    KOLResponse, KOLDetailResponse, KOLAdvisoryBoard,
    KOLSocialMedia, KOLCongress, KOLMaster, KOLPeerPortal, KOLMedscape, KOLCompProduct, KOLDoximity, SpeakerBureauEngagement, MSLKOLInteractionSummary, KOLPreCallInsights
)
from app.agents.postgresql_agent import PostgreSQLAgent
from app.services.metrics_service import MetricsService
from app.agents.llm_agent import LLMAgent
from app.core.models import ListResponse
# Initialize logger and router
logger = get_logger('dashboard_api')
router = APIRouter(prefix="/api", tags=["dashboard"])


pubmed_link = "https://pubmed.ncbi.nlm.nih.gov/{pmid}"
pubmed_cited_link= "https://pubmed.ncbi.nlm.nih.gov/?linkname=pubmed_pubmed_citedin&from_uid={pmc_id}"

# Initialize PostgreSQL agent
postgres_agent = PostgreSQLAgent()
llm_agent = LLMAgent()
def init_db_connection():
    """Initialize database connection"""
    success = postgres_agent.connect()
    if not success:
        logger.error("Failed to connect to PostgreSQL database")
        raise Exception("Database connection failed")
    logger.info("Dashboard API connected to PostgreSQL successfully")


def update_publication_insights_async(publication_id: str, insights: dict):
    """Background task to update publication insights in DB"""
    try:
        # Escape single quotes in insights to prevent SQL injection
        oneliner = insights.get('insights_one_liner', '').replace("'", "''")
        points = insights.get('insights_points', '').replace("'", "''")

        update_query = f"""
        UPDATE "ubi-ma-insights".test_nih_publications
        SET insights_one_liner = '{oneliner}',
            insights_points = '{points}'
        WHERE publication_id = '{publication_id}'
        """
        result = postgres_agent.execute_query(update_query, None)
        if result.success:
            logger.info(f"Updated insights for publication {publication_id}")
        else:
            logger.error(f"Failed to update publication {publication_id}: {result.error}")
    except Exception as e:
        logger.error(f"Exception updating publication insights: {e}")


def update_project_insights_async(project_id: str, insights: dict):
    """Background task to update project insights in DB"""
    try:
        # Escape single quotes in insights to prevent SQL injection
        oneliner = insights.get('insights_one_liner', '').replace("'", "''")
        points = insights.get('insights_points', '').replace("'", "''")

        update_query = f"""
        UPDATE "ubi-ma-insights".test_nih_projects
        SET insights_one_liner = '{oneliner}',
            insights_points = '{points}'
        WHERE project_id = '{project_id}'
        """
        result = postgres_agent.execute_query(update_query, None)
        if result.success:
            logger.info(f"Updated insights for project {project_id}")
        else:
            logger.error(f"Failed to update project {project_id}: {result.error}")
    except Exception as e:
        logger.error(f"Exception updating project insights: {e}")


def update_kol_pre_call_insights_async(researcher_id: str, insights_pointers: list):
    """Background task to update KOL pre-call insights in DB"""
    try:
        # Convert list to JSON string and escape single quotes
        insights_json = json.dumps(insights_pointers).replace("'", "''")

        update_query = f"""
        UPDATE "ubi-ma-insights".test_nih_authors
        SET pre_call_insights_pointers = '{insights_json}'
        WHERE researcher_id = '{researcher_id}'
        """
        result = postgres_agent.execute_query(update_query, None)
        if result.success:
            logger.info(f"Updated pre-call insights for researcher {researcher_id}")
        else:
            logger.error(f"Failed to update researcher {researcher_id}: {result.error}")
    except Exception as e:
        logger.error(f"Exception updating KOL pre-call insights: {e}")


async def generate_insights_batch(items: List[dict], text_key: str, max_concurrent: int = 10) -> List[dict]:
    """Generate insights for a batch of items with concurrency limit"""
    semaphore = asyncio.Semaphore(max_concurrent)

    async def process_item(item: dict) -> dict:
        async with semaphore:
            text = item.get(text_key, '')
            if text:
                # Run synchronous LLM call in a thread to avoid blocking
                insights = await asyncio.to_thread(llm_agent.generate_insights_from_text, text)
                return {'id': item['id'], 'insights': insights, 'success': True}
            return {'id': item['id'], 'insights': {'insights_one_liner': '', 'insights_points': ''}, 'success': True}

    # Run all tasks concurrently
    results = await asyncio.gather(*[process_item(item) for item in items], return_exceptions=True)
    return [r for r in results if isinstance(r, dict) and r.get('success')]


async def process_items_with_insights(data_rows: List[dict], text_key: str, id_key: str,
                                     background_tasks: BackgroundTasks, update_func) -> tuple:
    """Generic function to process items that may need insight generation"""
    with_insights = []
    needing_insights = []

    for row in data_rows:
        if row['insights_one_liner'] and row['insights_points']:
            with_insights.append({'row': row, 'insights': (row['insights_one_liner'], row['insights_points'])})
        elif row[text_key]:
            needing_insights.append({'id': row[id_key], text_key: row[text_key], 'row': row})
        else:
            with_insights.append({'row': row, 'insights': ('', '')})

    # Generate insights in parallel
    insights_map = {}
    if needing_insights:
        insights_results = await generate_insights_batch(needing_insights, text_key)

        # Schedule background updates
        for result in insights_results:
            background_tasks.add_task(update_func, result['id'], result['insights'])
            insights_map[result['id']] = result['insights']

    return with_insights, needing_insights, insights_map


def generate_pre_call_insights_with_llm(
    researcher_data: dict,
    congresses: list,
    advisory_board: list,
    speaker_bureau: list,
    collaborations: list,
    background_tasks: BackgroundTasks = None
) -> list:
    """
    Generate pre-call insights using LLM
    """
    pre_call_insights_pointers = []
    
    if congresses or advisory_board or speaker_bureau or collaborations:
        # Prepare data for LLM
        llm_data = {
            "collaborations": [collab.__dict__ for collab in collaborations],
            "congresses": [congress.__dict__ for congress in congresses],
            "advisory_board": [advisory.__dict__ for advisory in advisory_board],
            "speaker_bureau": [speaker.__dict__ for speaker in speaker_bureau],
            "researcher_name": researcher_data.get('name', ''),
            "primary_therapeutic_area": researcher_data.get('primary_therapeutic_area', ''),
            "total_projects": researcher_data.get('total_projects', 0),
            "total_publications": researcher_data.get('total_publications', 0),
            "total_patents": researcher_data.get('total_patents', 0),
            "total_clinical_studies": researcher_data.get('total_clinical_studies', 0),
            "total_funding": researcher_data.get('total_funding', 0)
        }

        # Generate insights pointers
        insights_prompt = f"""
        You are a medical insights summarization assistant. Based on the following Key Opinion Leader (KOL) data, generate 4–5 concise "Pre-Call Insight" pointers for a sales representative.

        ### KOL Data
        {llm_data}


        ### Style & Structure Rules
        1. Each pointer should be a **complete, factual statement** (not a directive).
        2. Focus on **recent interactions, speaking roles, advisory board activity, and research leadership**.
        3. Write in a **neutral, insight-driven tone** — no "you", "your", or "discuss with".
        4. Avoid marketing or conversational phrasing such as "align your discussion" or "explore opportunities".
        5. Each pointer should start with a **verb in past tense** or a **noun phrase** (e.g., "Delivered keynote…", "Served on advisory board…").
        6. Limit each pointer to **one concise sentence** (max 25 words).
        7. Return only the JSON array with no extra explanation.


        ### Output
        Return only a JSON array like:
        ```json
        [
        "pointer 1",
        "pointer 2",
        "pointer 3",
        "pointer 4",
        "pointer 5"
        ]
        """

        try:
            llm_response = llm_agent.generate_insights_pointers(insights_prompt)
            print(f"\n LLM response: {llm_response}")
            if llm_response:
                pre_call_insights_pointers = llm_response
                
                # Schedule async DB update in background if background_tasks provided
                if background_tasks and researcher_data.get('researcher_id'):
                    background_tasks.add_task(
                        update_kol_pre_call_insights_async,
                        researcher_data['researcher_id'],
                        pre_call_insights_pointers
                    )
                    logger.info(f"Scheduled DB update for pre-call insights for researcher {researcher_data['researcher_id']}")
        except Exception as e:
            logger.warning(f"Failed to generate pre-call insights: {str(e)}")
            pre_call_insights_pointers = []
    
    return pre_call_insights_pointers


@router.get("/insights")
async def get_insights(
    publication_ids: Optional[List[str]] = Query(None, description="Array of publication IDs"),
    project_ids: Optional[List[str]] = Query(None, description="Array of project IDs")
):
    """
    Get insights for publications and projects
    """
    logger.info(f"Get insights called with publication_ids: {publication_ids}, project_ids: {project_ids}")
    
    try:
        # Initialize database connection if needed
        if not postgres_agent.connection_pool:
            init_db_connection()
        # Build query based on filters
        base_query = """
        SELECT 
            p.publication_id,
            pr.project_id,
            p.insights_one_liner as oneliner_insight,
            p.insights_points as multiliner_insights
        FROM "ubi-ma-insights".test_nih_publications p
        JOIN "ubi-ma-insights".test_nih_projects pr ON p.publication_id = ANY(pr.linked_publication_ids)
        WHERE 1=1
        """
        
        conditions = []
        if publication_ids:
            pub_ids_str = "', '".join(publication_ids)
            conditions.append(f"p.publication_id IN ('{pub_ids_str}')")
        if project_ids:
            proj_ids_str = "', '".join(project_ids)
            conditions.append(f"pr.project_id IN ('{proj_ids_str}')")
        
        if conditions:
            base_query += " AND " + " AND ".join(conditions)
        
        result = postgres_agent.execute_query(base_query, None)
        
        if not result.success:
            logger.error(f"Query failed: {result.error}")
            raise HTTPException(status_code=500, detail="Database query failed")
        
        insights = []
        for row in result.data:
            insights.append(InsightResponse(
                publication_id=row['publication_id'],
                project_id=row['project_id'],
                oneliner_insight=row['oneliner_insight'] or "",
                multiliner_insights=row['multiliner_insights'] or ""
            ))
        
        return ListResponse(
            success=True,
            message="Insights fetched successfully",
            data=insights,
            total_count=len(insights)
        )
    except Exception as e:
        logger.error(f"Error in get_insights: {str(e)}")
        return ListResponse(
            success=False,
            message=f"Error in get_insights: {str(e)}",
            data=None,
            total_count=0
        )


@router.get("/publications")
async def get_publications(
    publication_ids: Optional[str] = Query(None, description="List of publication IDs"),
    year: Optional[str] = Query(None, description="Year"),
    TA: Optional[str] = Query(None, description="Therapeutic Area"),
    background_tasks: BackgroundTasks = BackgroundTasks()
):
    """
    Get publications with optional filters
    """
    logger.info(f"Get publications called with publication_ids: {publication_ids}, years: {year}, TA: {TA}")
    
    try:
        # Initialize database connection if needed
        if not postgres_agent.connection_pool:
            init_db_connection()
        base_query = """
        SELECT 
            publication_id,
            pmid,
            title,
            journal,
            journal_abbr,
            year,
            pmc_id,
            total_authors,
            therapeutic_area,
            insights_one_liner,
            insights_points,
            author_names as author_researcher_names,
            linked_project_ids,
            abstract
        FROM "ubi-ma-insights".test_nih_publications
        WHERE 1=1
        """
        
        conditions = []
        if publication_ids:
            pub_ids_str = publication_ids.split(';')
            pub_ids_str = ', '.join([f"'{id.strip()}'" for id in pub_ids_str])
            conditions.append(f"publication_id IN ({pub_ids_str})")
        if year:
            conditions.append(f"year = '{year}'")
        if TA:
            conditions.append(f"LOWER(therapeutic_area) = LOWER('{TA}')")

        if conditions:
            base_query += " AND " + " AND ".join(conditions)
        base_query += " LIMIT 20"   
        result = postgres_agent.execute_query(base_query, None)
        
        if not result.success:
            logger.error(f"Query failed: {result.error}")
            raise HTTPException(status_code=500, detail="Database query failed")
        
        # Process publications with parallel insight generation
        with_insights, needing_insights, insights_map = await process_items_with_insights(
            result.data, 'abstract', 'publication_id', background_tasks, update_publication_insights_async
        )

        # Build final publications list
        publications = []
        for item in with_insights:
            row = item['row']
            publications.append(PublicationResponse(
                publication_id=str(row['publication_id']),
                pmid=str(row['pmid']),
                title=row['title'],
                journal=row['journal'],
                journal_abbr=row['journal_abbr'],
                year=row['year'],
                pmc_id=str(row['pmc_id']) if row['pmc_id'] else "",
                total_authors=row['total_authors'],
                therapeutic_area=row['therapeutic_area'],
                author_researcher_names=row['author_researcher_names'] or "",
                oneliner_insight=item['insights'][0],
                multiliner_insights=item['insights'][1],
                linked_project_ids=row['linked_project_ids'] or "",
                abstract=row['abstract'] or "",
                pubmed_link=pubmed_link.format(pmid=str(row['pmid'])),
                pubmed_cited_link=pubmed_cited_link.format(pmc_id=str(row['pmc_id']).split('.')[0])
            ))

        # Add publications that had insights generated
        for item in needing_insights:
            row = item['row']
            insights = insights_map.get(item['id'], {'insights_one_liner': '', 'insights_points': ''})
            publications.append(PublicationResponse(
                publication_id=str(row['publication_id']),
                pmid=str(row['pmid']),
                title=row['title'],
                journal=row['journal'],
                journal_abbr=row['journal_abbr'],
                year=row['year'],
                pmc_id=str(row['pmc_id']) if row['pmc_id'] else "",
                total_authors=row['total_authors'],
                therapeutic_area=row['therapeutic_area'],
                author_researcher_names=row['author_researcher_names'] or "",
                oneliner_insight=insights.get('insights_one_liner', ''),
                multiliner_insights=insights.get('insights_points', ''),
                linked_project_ids=row['linked_project_ids'] or "",
                abstract=row['abstract'] or "",
                pubmed_link=pubmed_link.format(pmid=str(row['pmid'])),
                pubmed_cited_link=pubmed_cited_link.format(pmc_id=str(row['pmc_id']).split('.')[0])
            ))

        return ListResponse(
            success=True,
            message="Publications fetched successfully",
            data=publications,
            total_count=len(publications)
        )
        
    except Exception as e:
        logger.error(f"Error in get_publications: {str(e)}")
        return ListResponse(
            success=False,
            message=f"Error in get_publications: {str(e)}",
            data=None,
            total_count=0
        )


@router.get("/projects")
async def get_projects(
    project_ids: str = Query(..., description="Array of project IDs"),
    background_tasks: BackgroundTasks = BackgroundTasks()
):
    """
    Get projects by project IDs
    """
    logger.info(f"Get projects called with project_ids: {project_ids}")
    
    try:
        # Initialize database connection if needed
        if not postgres_agent.connection_pool:
            init_db_connection()
        # Convert project_ids list to SQL IN clause
        project_ids_str = project_ids.split(';')
        project_ids_str = ', '.join([f"'{id.strip()}'" for id in project_ids_str])
        conditions = f"project_id IN ({project_ids_str})"

        query = f"""
        SELECT 
            project_id,
            application_ids,
            title,
            funding_mechanism,
            fiscal_year,
            organization,
            org_city,
            org_state,
            start_date::text,
            end_date::text,
            total_cost,
            direct_cost,
            therapeutic_area,
            funding_ics,
            linked_publication_ids,
            insights_one_liner,
            insights_points,
            abstract_text
        FROM "ubi-ma-insights".test_nih_projects
        WHERE {conditions}
        """
        
        result = postgres_agent.execute_query(query, None)
        
        if not result.success:
            logger.error(f"Query failed: {result.error}")
            raise HTTPException(status_code=500, detail="Database query failed")
        
        # Process projects with parallel insight generation
        with_insights, needing_insights, insights_map = await process_items_with_insights(
            result.data, 'abstract_text', 'project_id', background_tasks, update_project_insights_async
        )

        # Build final projects list
        projects = []
        for item in with_insights:
            row = item['row']
            projects.append(ProjectResponse(
                project_id=row['project_id'],
                application_ids=row['application_ids'] or "",
                title=row['title'],
                pi_name="",
                funding_mechanism=row['funding_mechanism'],
                fiscal_year=row['fiscal_year'],
                organization=row['organization'],
                org_city=row['org_city'],
                org_state=row['org_state'],
                start_date=row['start_date'] or "",
                end_date=row['end_date'] or "",
                total_cost=row['total_cost'],
                direct_cost=row['direct_cost'],
                therapeutic_area=row['therapeutic_area'],
                funding_ics=row['funding_ics'] or "",
                linked_publication_ids=row['linked_publication_ids'] or "",
                oneliner_insight=item['insights'][0],
                multiliner_insights=item['insights'][1],
                abstract=row['abstract_text'] or ""
            ))

        # Add projects that had insights generated
        for item in needing_insights:
            row = item['row']
            insights = insights_map.get(item['id'], {'insights_one_liner': '', 'insights_points': ''})
            projects.append(ProjectResponse(
                project_id=row['project_id'],
                application_ids=row['application_ids'] or "",
                title=row['title'],
                pi_name="",
                funding_mechanism=row['funding_mechanism'],
                fiscal_year=row['fiscal_year'],
                organization=row['organization'],
                org_city=row['org_city'],
                org_state=row['org_state'],
                start_date=row['start_date'] or "",
                end_date=row['end_date'] or "",
                total_cost=row['total_cost'],
                direct_cost=row['direct_cost'],
                therapeutic_area=row['therapeutic_area'],
                funding_ics=row['funding_ics'] or "",
                linked_publication_ids=row['linked_publication_ids'] or "",
                oneliner_insight=insights.get('insights_one_liner', ''),
                multiliner_insights=insights.get('insights_points', ''),
                abstract=row['abstract_text'] or ""
            ))
        
        return ListResponse(
            success=True,
            message="Projects fetched successfully",
            data=projects,
            total_count=len(projects)
        )
        
    except Exception as e:
        logger.error(f"Error in get_projects: {str(e)}")
        return ListResponse(
            success=False,
            message=f"Error in get_projects: {str(e)}",
            data=[],
            total_count=0
        )


@router.get("/kols")
async def get_kols(
    year: str = Query(..., description="Year"),
    TA: str = Query(..., description="Therapeutic Area"),
    page: int = Query(1, description="Page number", ge=1)
):
    """
    Get Key Opinion Leaders by year and therapeutic area
    """
    logger.info(f"Get KOLs called with year: {year}, TA: {TA}, page: {page}")
    
    try:
        # Initialize database connection if needed
        if not postgres_agent.connection_pool:
            init_db_connection()

        # Calculate pagination
        page_size = 20
        offset = (page - 1) * page_size

        # Query the nih_authors table for KOLs
        query = f"""
        SELECT 
            researcher_id,
            name,
            top_institution,
            last_project_year,
            primary_therapeutic_area ,
            project_ids,
            roles,
            org_city
        FROM "ubi-ma-insights".test_nih_authors
        WHERE LOWER(primary_therapeutic_area) = LOWER('{TA}')
        AND LOWER(project_years) = LOWER('{year}')
        ORDER BY total_projects DESC,
         total_publications DESC, 
         total_patents DESC, 
         total_clinical_studies DESC, 
         total_funding DESC,
         last_project_year DESC
        LIMIT {page_size} OFFSET {offset}
        """
        # profile_summary,

        
        logger.info(f"Executing query: {query}")
        logger.info(f"Parameters: TA={TA}, year={year}, page={page}")
        

        
        result = postgres_agent.execute_query(query, None)
        
        logger.info(f"Query execution result: success={result.success}, error={result.error}")
        logger.info(f"Result data type: {type(result.data)}")
        logger.info(f"Result data: {result.data}")
        
        if not result.success:
            logger.error(f"Query failed: {result.error}")
            raise HTTPException(status_code=500, detail="Database query failed")
        
        logger.info(f"Query result type: {type(result.data)}, content: {result.data}")
        
        kols = []
        if result.data:
            # Handle both list and dict cases
            if isinstance(result.data, list):
                data_to_process = result.data
            elif isinstance(result.data, dict):
                data_to_process = [result.data]
            else:
                logger.warning(f"Unexpected data type: {type(result.data)}")
                data_to_process = []
            
            for row in data_to_process:
                logger.info(f"Row type: {type(row)}, content: {row}")
                try:
                    kol = KOLResponse(
                        researcher_id=str(row.get('researcher_id', '')),
                        name=str(row.get('name', '')),
                        institution=str(row.get('top_institution', '')),
                        year=int(row.get('last_project_year', 0)),
                        project_ids=str(row.get('project_ids', '')),
                        therapeutic_area=str(row.get('primary_therapeutic_area', '')),
                        roles=str(row.get('roles', '')),
                        city=str(row.get('org_city', '')),
                        oneliner_insight='',
                        multiliner_insights=''
                    )

                    # Get project insights if project_ids exist
                    project_ids_str = row.get('project_ids', '')
                    if project_ids_str:
                        project_id = project_ids_str.split(';')[0]
                        for project_id in project_ids_str.split(';'):
                            project_query = f"""
                            SELECT project_id, insights_one_liner, insights_points
                            FROM "ubi-ma-insights".test_nih_projects
                            WHERE project_id = '{project_id}' 
                            """

                            project_result = postgres_agent.execute_query(project_query, None)

                            if not project_result.success:
                                logger.error(f"Query failed: {project_result.error}")

                            if project_result.data and len(project_result.data) > 0:
                                project_row = project_result.data[0]
                                kol.oneliner_insight = project_row.get('insights_one_liner', '')
                                kol.multiliner_insights = project_row.get('insights_points', '')
                                break
                    kols.append(kol)
                except Exception as row_error:
                    logger.error(f"Error processing row {row}: {str(row_error)}")
                    continue
        else:
            logger.warning(f"No data returned: {result.data}")
        
        return ListResponse(
            success=True,
            message="KOLs fetched successfully",
            data=kols,
            total_count=len(kols)
        )
        
    except Exception as e:
        logger.error(f"Error in get_kols: {str(e)}")
        return ListResponse(
            success=False,
            message=f"Error in get_kols: {str(e)}",
            data=None,
            total_count=0
        )


@router.get("/kol")
async def get_kol(
    researcher_id: str = Query(..., description="Researcher ID"),
    background_tasks: BackgroundTasks = BackgroundTasks()
):
    """
    Get individual KOL details
    """
    logger.info(f"Get KOL detail called with researcher_id: {researcher_id}")
    
    try:
        # Initialize database connection if needed
        if not postgres_agent.connection_pool:
            init_db_connection()
        # Query the nih_authors table for individual KOL details
        query = f"""
        SELECT 
            researcher_id,
            name,
            roles,
            primary_therapeutic_area,
            therapeutic_areas,
            project_ids,
            publication_ids,
            patent_ids,
            clinical_study_ids,
            sub_pi_authors,
            sub_publication_authors,
            total_projects,
            total_publications,
            total_patents,
            total_clinical_studies,
            total_funding,
            top_institution,
            org_city,
            org_state,
            is_pi,
            is_author,
            is_both,
            topics,
            pre_call_insights_pointers
        FROM "ubi-ma-insights".test_nih_authors
        WHERE researcher_id = '{researcher_id}'
        """
        
        result = postgres_agent.execute_query(query, None)
        
        if not result.success:
            logger.error(f"Query failed: {result.error}")
            raise HTTPException(status_code=500, detail="Database query failed")
        
        if not result.data:
            raise HTTPException(status_code=404, detail="Researcher not found")
        
        row = result.data[0]
        author_name = row['name']
        
        kol_master = None
        advisory_board = []
        congresses = []
        social_media = []
        peer_portals = []
        medscapes = []
        comp_products = []
        doximity = []
        speaker_bureau = []
        collaborations = []
        
        if author_name:
            try:
                master_query = f"""
                SELECT 
                    "kol_id",
                    "authorname",
                    "credentials",
                    "Specialty/Sub-TA",
                    "institution",
                    "primary_therapeutic_area",
                    "tier",
                    "is_principal_investigator",
                    "site_affiliation",
                    "avg_enrollment_rate_past_trials",
                    "data_quality_score",
                    "years_experience",
                    "research_focus",
                    "research_focus_snomed_ct_code",
                    "research_focus_icd9_code",
                    "research_focus_icd10_code",
                    "research_focus_icd11_code",
                    "last_contact_date"
                FROM "ubi-ma-insights".test_kol_master
                WHERE LOWER("authorname") = '{author_name.lower()}'
                LIMIT 1
                """
                
                master_result = postgres_agent.execute_query(master_query, None)
                
                if master_result.success and master_result.data and master_result.data[0].get('kol_id'):
                    master_row = master_result.data[0]
                    kol_id = master_row.get('kol_id', '')
                    
                    kol_master = KOLMaster.from_db_row(master_row)
                    
                    advisory_query = f"""
                    SELECT 
                        advisory_id,
                        advisory_meeting_date,
                        advisory_meeting_topic,
                        advisory_kol_contribution,
                        advisory_discussion_points,
                        advisory_action_items,
                        advisory_campaign_id,
                        advisory_strategic_flag,
                        advisory_pipeline_impact_score,
                        advisory_competitive_insight
                    FROM "ubi-ma-insights".test_kol_advisory_board
                    WHERE "kol_id" = '{kol_id}'
                    """
                    
                    advisory_result = postgres_agent.execute_query(advisory_query, None)
                    
                    if advisory_result.success and advisory_result.data:
                        for adv_row in advisory_result.data:
                            advisory_board.append(KOLAdvisoryBoard.from_db_row(adv_row))
                    
                    congress_query = f"""
                    SELECT 
                        congress_date,
                        congress_name,
                        congress_role,
                        congress_key_takeaways,
                        congress_impact_score,
                        congress_trend_keywords,
                        congress_audience_reception
                    FROM "ubi-ma-insights".test_kol_congress
                    WHERE "kol_id" = '{kol_id}'
                    """
                    
                    congress_result = postgres_agent.execute_query(congress_query, None)
                    
                    if congress_result.success and congress_result.data:
                        for cong_row in congress_result.data:
                            congresses.append(KOLCongress.from_db_row(cong_row))
                    
                    social_query = f"""
                    SELECT 
                        social_activity_date,
                        social_platform,
                        social_activity_type,
                        social_reach,
                        social_likes,
                        social_comments,
                        social_shares
                    FROM "ubi-ma-insights".test_kol_social_media
                    WHERE "kol_id" = '{kol_id}'
                    """
                    
                    social_result = postgres_agent.execute_query(social_query, None)
                    
                    if social_result.success and social_result.data:
                        for social_row in social_result.data:
                            social_media.append(KOLSocialMedia.from_db_row(social_row))

                    peer_portal_query = f"""
                    SELECT 
                        portal_name,
                        content_accessed,
                        time_spent_minutes,
                        access_date,
                        engagement_score 
                    FROM "ubi-ma-insights".test_kol_peer_portals
                    WHERE "kol_id" = '{kol_id}'
                    """
                    peer_portal_result = postgres_agent.execute_query(peer_portal_query, None)
                    
                    if peer_portal_result.success and peer_portal_result.data:
                        for peer_portal_row in peer_portal_result.data:
                            peer_portals.append(KOLPeerPortal.from_db_row(peer_portal_row))
                    
                    medscape_query = f"""
                    SELECT 
                        content_title,
                        completion_rate,
                        cme_credits_earned,
                        content_category,
                        activity_date 
                    FROM "ubi-ma-insights".test_kol_medscape
                    WHERE "kol_id" = '{kol_id}'
                    """
                    medscape_result = postgres_agent.execute_query(medscape_query, None)
                    
                    if medscape_result.success and medscape_result.data:
                        for medscape_row in medscape_result.data:
                            medscapes.append(KOLMedscape.from_db_row(medscape_row))

                    comp_products_query = f"""
                    SELECT
                        product_name,
                        interaction_type,
                        engagement_level,
                        source_platform,
                        interaction_date
                    FROM "ubi-ma-insights".test_kol_comp_products
                    WHERE kol_id = '{kol_id}'
                    """
                    
                    comp_products_result = postgres_agent.execute_query(comp_products_query, None)
                    
                    if comp_products_result.success and comp_products_result.data:
                        for comp_products_row in comp_products_result.data:
                            comp_products.append(KOLCompProduct.from_db_row(comp_products_row))
                    
                    doximity_query = f"""
                    SELECT 
                        activity_type,
                        content_title,
                        profile_views,
                        network_connections,
                        specialty_focus 
                    FROM "ubi-ma-insights".test_kol_doximity
                    WHERE "kol_id" = '{kol_id}'
                    """
                    doximity_result = postgres_agent.execute_query(doximity_query, None)
                    
                    if doximity_result.success and doximity_result.data:
                        for doximity_row in doximity_result.data:
                            doximity.append(KOLDoximity.from_db_row(doximity_row))


                    speaker_bureau_query = f"""
                    SELECT 
                        presentation_topic,
                        audience_size,
                        kol_event_performance_score,
                        event_type,
                        engagement_date,
                        attendees_reached_by_kol, 
                        event_description, 
                        honorarium_paid 
                    FROM "ubi-ma-insights".test_speaker_bureau
                    WHERE "kol_id" = '{kol_id}' LIMIT 9
                    """
                    speaker_bureau_result = postgres_agent.execute_query(
                        speaker_bureau_query, None
                    )

                    if speaker_bureau_result.success and speaker_bureau_result.data:
                        for speaker_bureau_row in speaker_bureau_result.data:
                            speaker_bureau.append(
                                SpeakerBureauEngagement.from_db_row(speaker_bureau_row)
                            )

                    collaborations_query = f"""
                    select
                    *
                    from
                    (
                        SELECT
                        mi.msl_name,
                        mi.region,
                        mi2.interaction_type,
                        mi.therapy_area_focus,
                        REPLACE(
                            REPLACE(
                            REPLACE(mi2.discussion_topics, '{{', ''),
                            '}}',
                            ''
                            ),
                            '"',
                            ''
                        ) AS discussion_topics,
                        mpp.key_meeting_objectives,
                        mpp.kol_publications_count,
                        mpp.kol_citations_count,
                        mi2.next_action_required,
                        row_number() over(partition by mi.msl_name) as msl_ranking
                        FROM
                        "ubi-ma-insights".test_msl_pre_planning AS mpp
                        LEFT JOIN "ubi-ma-insights".test_msl_interactions AS mi2 ON mpp.kol_id = mi2.kol_id
                        AND mpp.msl_id = mi2.msl_id
                        LEFT JOIN "ubi-ma-insights".test_msl_profiles AS mi ON mpp.msl_id = mi.msl_id
                        WHERE
                        mpp.kol_id = '{kol_id}'
                        AND mi2.interaction_type IS NOT NULL
                    )
                    where
                    msl_ranking in (1, 2) limit 4
                    """

                    collaborations_result = postgres_agent.execute_query(
                        collaborations_query, None
                    )

                    if collaborations_result.success and collaborations_result.data:
                        for collaborations_row in collaborations_result.data:
                            collaborations.append(
                                MSLKOLInteractionSummary.from_db_row(collaborations_row)
                            )
                    
                    
            except Exception as kol_error:
                logger.warning(f"Could not fetch additional KOL data for {author_name}: {str(kol_error)}")
        
        # Check and generate pre-call insights if empty or null
        pre_call_insights_pointers = []
        try:
            stored_insights = row.get('pre_call_insights_pointers', '')
            
            # Check if insights are empty or null
            if stored_insights and stored_insights != '' and stored_insights != 'null':
                # Try to parse if it's a JSON string
                if isinstance(stored_insights, str):
                    try:
                        pre_call_insights_pointers = json.loads(stored_insights)
                    except:
                        pre_call_insights_pointers = []
                else:
                    pre_call_insights_pointers = stored_insights
            
            # If still empty and we have kol data, generate new insights
            if not pre_call_insights_pointers and (congresses or advisory_board or speaker_bureau or collaborations):
                logger.info(f"Generating new pre-call insights for researcher {researcher_id}")
                
                # Prepare researcher data dict
                researcher_dict = {
                    'researcher_id': researcher_id,
                    'name': row['name'],
                    'primary_therapeutic_area': row['primary_therapeutic_area'],
                    'total_projects': row['total_projects'],
                    'total_publications': row['total_publications'],
                    'total_patents': row['total_patents'],
                    'total_clinical_studies': row['total_clinical_studies'],
                    'total_funding': row['total_funding']
                }
                
                # Use the reusable function with already-fetched data
                pre_call_insights_pointers = generate_pre_call_insights_with_llm(
                    researcher_data=researcher_dict,
                    congresses=congresses,
                    advisory_board=advisory_board,
                    speaker_bureau=speaker_bureau,
                    collaborations=collaborations,
                    background_tasks=background_tasks
                )
        except Exception as insights_error:
            logger.warning(f"Error processing pre-call insights: {str(insights_error)}")
            pre_call_insights_pointers = []
        
        kol_detail = KOLDetailResponse(
            researcher_id=row['researcher_id'],
            name=row['name'],
            roles=row['roles'] or "",
            therapeutic_areas=row['therapeutic_areas'] or "",
            project_ids=row['project_ids'] or "",
            publication_ids=row['publication_ids'] or "",
            patent_ids=row['patent_ids'] or "",
            clinical_study_ids=row['clinical_study_ids'] or "",
            sub_pi_authors=row['sub_pi_authors'] or "",
            sub_publication_authors=row['sub_publication_authors'] or "",
            total_projects=row['total_projects'] or 0,
            total_publications=row['total_publications'] or 0,
            total_patents=row['total_patents'] or 0,
            total_clinical_studies=row['total_clinical_studies'] or 0,
            total_funding=row['total_funding'] or 0,
            top_institution=row['top_institution'] or "",
            org_city=row['org_city'] or "",
            org_state=row['org_state'] or "",
            is_pi=row['is_pi'] or False,
            is_author=row['is_author'] or False,
            is_both=row['is_both'] or False,

            topics=row['topics'] or "",
            pre_call_insights_pointers=pre_call_insights_pointers,
            kol_master=kol_master,
            advisory_board=advisory_board,
            congresses=congresses,
            social_media=social_media,
            peer_portals=peer_portals,
            medscapes=medscapes,
            comp_products=comp_products,
            doximity=doximity,
            speaker_bureau=speaker_bureau,
            collaborations=collaborations
        )
        
        return kol_detail
        
    except Exception as e:
        logger.error(f"Error in get_kol: {str(e)}")
        return {"success": False, "message": f"Error in get_kol: {str(e)}"}


@router.get("/llm-metrics")
async def get_llm_metrics():
    """
    Returns current LLM usage metrics (accuracy, response time, token usage, call count, and cost)
    """
    return {
        "average_accuracy": MetricsService.get_average_accuracy(),
        "average_response_time": MetricsService.get_average_response_time(),
        "average_api_response_time": MetricsService.get_average_api_response_time(),
        "total_llm_calls": MetricsService.get_total_llm_calls(),
        "total_token_input": MetricsService.get_total_token_input(),
        "total_token_output": MetricsService.get_total_token_output(),
        "total_cost": MetricsService.get_total_cost(),
    }


@router.get("/health")
async def health_check():
    """
    Health check endpoint for dashboard API
    """
    return {
        "status": "healthy",
        "service": "dashboard-api",
        "message": "Dashboard API is running"
    } 


@router.get("/kol-pre-call-insights")
async def get_kol_pre_call_insights(
    researcher_id: str = Query(..., description="researcher_id ID"),
    background_tasks: BackgroundTasks = BackgroundTasks()
):
    """
    Get pre-call insights for a KOL
    """
    logger.info(f"Get KOL pre-call insights called with researcher_id: {researcher_id}")
    
    try:
        # Initialize database connection if needed
        if not postgres_agent.connection_pool:
            init_db_connection()
        # Query the nih_authors table for individual KOL details
        query = f"""
        SELECT
            researcher_id,
            name,
            roles,
            primary_therapeutic_area,
            total_projects,
            total_publications,
            total_patents,
            total_clinical_studies,
            total_funding
        FROM "ubi-ma-insights".test_nih_authors
        WHERE researcher_id = '{researcher_id}'
        """
            # profile_summary_pointers
            # profile_summary,
        
        result = postgres_agent.execute_query(query, None)
        
        if not result.success:
            logger.error(f"Query failed: {result.error}")
            raise HTTPException(status_code=500, detail="Database query failed")
        
        if not result.data:
            raise HTTPException(status_code=404, detail="Researcher not found")
        
        row = result.data[0]
        author_name = row['name']
        kol_master = None
        congresses = []
        advisory_board = []
        speaker_bureau = []
        collaborations = []
        
        if author_name:
            try:
                master_query = f"""
                SELECT 
                    "kol_id",
                    "authorname"

                FROM "ubi-ma-insights".test_kol_master
                WHERE LOWER("authorname") = '{author_name.lower()}'
                LIMIT 1
                """
                
                master_result = postgres_agent.execute_query(master_query, None)

                if master_result.success and master_result.data and master_result.data[0].get('kol_id'):
                    master_row = master_result.data[0]
                    kol_id = master_row.get('kol_id', '')

                    kol_master = KOLMaster.from_db_row(master_row)

                    # Fetch congresses data
                    congresses_query = f"""
                    SELECT
                        congress_role,
                        congress_key_takeaways,
                        congress_impact_score,
                        congress_trend_keywords,
                        congress_audience_reception
                    FROM "ubi-ma-insights".test_kol_congress
                    WHERE "kol_id" = '{kol_id}' LIMIT 2
                    """

                    congresses_result = postgres_agent.execute_query(congresses_query, None)

                    if congresses_result.success and congresses_result.data:
                        for congress_row in congresses_result.data:
                            congresses.append(KOLCongress.from_db_row(congress_row))

                    # Fetch advisory board data - Same query as /kol endpoint
                    advisory_query = f"""
                    SELECT 
                        advisory_id,
                        advisory_meeting_date,
                        advisory_meeting_topic,
                        advisory_kol_contribution,
                        advisory_discussion_points,
                        advisory_action_items,
                        advisory_campaign_id,
                        advisory_strategic_flag,
                        advisory_pipeline_impact_score,
                        advisory_competitive_insight
                    FROM "ubi-ma-insights".test_kol_advisory_board
                    WHERE "kol_id" = '{kol_id}' LIMIT 2
                    """

                    advisory_result = postgres_agent.execute_query(advisory_query, None)

                    if advisory_result.success and advisory_result.data:
                        for advisory_row in advisory_result.data:
                            advisory_board.append(KOLAdvisoryBoard.from_db_row(advisory_row))

                    # Fetch speaker bureau data - Same query as /kol endpoint
                    speaker_bureau_query = f"""
                    SELECT 
                        presentation_topic,
                        audience_size,
                        kol_event_performance_score,
                        event_type,
                        engagement_date,
                        attendees_reached_by_kol, 
                        event_description, 
                        honorarium_paid 
                    FROM "ubi-ma-insights".test_speaker_bureau
                    WHERE "kol_id" = '{kol_id}' LIMIT 2
                    """
                    speaker_bureau_result = postgres_agent.execute_query(speaker_bureau_query, None)

                    if speaker_bureau_result.success and speaker_bureau_result.data:
                        for speaker_bureau_row in speaker_bureau_result.data:
                            speaker_bureau.append(SpeakerBureauEngagement.from_db_row(speaker_bureau_row))

                    # Fetch collaborations data - Same query as /kol endpoint
                    collaborations_query = f"""
                    select
                    *
                    from
                    (
                        SELECT
                        mi.msl_name,
                        mi.region,
                        mi2.interaction_type,
                        mi.therapy_area_focus,
                        REPLACE(
                            REPLACE(
                            REPLACE(mi2.discussion_topics, '{{', ''),
                            '}}',
                            ''
                            ),
                            '"',
                            ''
                        ) AS discussion_topics,
                        mpp.key_meeting_objectives,
                        mpp.kol_publications_count,
                        mpp.kol_citations_count,
                        mi2.next_action_required,
                        row_number() over(partition by mi.msl_name) as msl_ranking
                        FROM
                        "ubi-ma-insights".test_msl_pre_planning AS mpp
                        LEFT JOIN "ubi-ma-insights".test_msl_interactions AS mi2 ON mpp.kol_id = mi2.kol_id
                        AND mpp.msl_id = mi2.msl_id
                        LEFT JOIN "ubi-ma-insights".test_msl_profiles AS mi ON mpp.msl_id = mi.msl_id
                        WHERE
                        mpp.kol_id = '{kol_id}'
                        AND mi2.interaction_type IS NOT NULL
                    )
                    where
                    msl_ranking in (1, 2) limit 4
                    """

                    collaborations_result = postgres_agent.execute_query(collaborations_query, None)

                    if collaborations_result.success and collaborations_result.data:
                        for collaborations_row in collaborations_result.data:
                            collaborations.append(MSLKOLInteractionSummary.from_db_row(collaborations_row))
            except Exception as e:
                logger.warning(f"Failed to fetch KOL interaction data: {str(e)}")
                # Continue with LLM generation even if some data fetch failed

            # Generate pre-call insights using LLM with reusable function
            researcher_dict = {
                'researcher_id': researcher_id,
                'name': row['name'],
                'primary_therapeutic_area': row['primary_therapeutic_area'],
                'total_projects': row['total_projects'],
                'total_publications': row['total_publications'],
                'total_patents': row['total_patents'],
                'total_clinical_studies': row['total_clinical_studies'],
                'total_funding': row['total_funding']
            }
            
            pre_call_insights_pointers = generate_pre_call_insights_with_llm(
                researcher_data=researcher_dict,
                congresses=congresses,
                advisory_board=advisory_board,
                speaker_bureau=speaker_bureau,
                collaborations=collaborations,
                background_tasks=background_tasks
            )

            # Return the response
            return  {"success": True, "message": "KOL pre-call insights fetched successfully", "data": pre_call_insights_pointers}

    except Exception as e:
        logger.error(f"Error in get_kol_pre_call_insights: {str(e)}")
        return {"success": False, "message": f"Error in get_kol_pre_call_insights: {str(e)}"}


@router.get("/search")
async def search(
    type: str = Query(..., description="Search type: author, publication, or project"),
    text: str = Query(..., description="Search text"),
    background_tasks: BackgroundTasks = BackgroundTasks()
):
    """
    Unified search API for authors, publications, and projects
    Searches in IDs and names/titles using exact match and ILIKE partial match
    Returns top 10 results in format compatible with existing APIs
    """
    logger.info(f"Search called with type: {type}, text: {text}")
    
    try:
        # Validate search type
        valid_types = ['author', 'publication', 'project']
        if type.lower() not in valid_types:
            raise HTTPException(
                status_code=400, 
                detail=f"Invalid search type. Must be one of: {', '.join(valid_types)}"
            )
        
        # Initialize database connection if needed
        if not postgres_agent.connection_pool:
            init_db_connection()
        
        # Route to appropriate search function
        if type.lower() == 'author':
            return await search_authors(text, background_tasks)
        elif type.lower() == 'publication':
            return await search_publications(text, background_tasks)
        elif type.lower() == 'project':
            return await search_projects(text, background_tasks)
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in search: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


async def search_authors(text: str, background_tasks: BackgroundTasks) -> List[KOLResponse]:
    """
    Search for authors by researcher_id or name
    Returns list of KOLResponse objects (same format as /api/kols)
    """
    logger.info(f"Searching authors with text: {text}")
    
    try:
        # Escape single quotes for SQL
        search_text = text.replace("'", "''")

        # Check if search text looks like a researcher ID (contains numbers or specific patterns)
        is_potential_id = any(char.isdigit() for char in search_text) or len(search_text) > 5

        # Build WHERE clause dynamically
        where_conditions = []
        if is_potential_id:
            where_conditions.append(f"researcher_id = '{search_text}'")
        where_conditions.append(f"LOWER(name) ILIKE LOWER('%{search_text}%')")

        where_clause = " OR ".join(where_conditions)

        # Query with exact and partial text search
        query = f"""
        SELECT
            researcher_id,
            name,
            top_institution,
            last_project_year,
            primary_therapeutic_area,
            project_ids,
            roles,
            org_city
        FROM "ubi-ma-insights".test_nih_authors
        WHERE {where_clause}
        ORDER BY
            CASE
                WHEN researcher_id = '{search_text}' THEN 1
                ELSE 2
            END,
            total_projects DESC,
            total_publications DESC
        LIMIT 10
        """
        
        result = postgres_agent.execute_query(query, None)
        
        if not result.success:
            logger.error(f"Query failed: {result.error}")
            raise HTTPException(status_code=500, detail="Database query failed")
        
        authors = []
        if result.data:
            for row in result.data:
                authors.append(KOLResponse(
                    researcher_id=str(row.get('researcher_id', '')),
                    name=str(row.get('name', '')),
                    institution=str(row.get('top_institution', '')),
                    year=int(row.get('last_project_year', 0)),
                    project_ids=str(row.get('project_ids', '')),
                    therapeutic_area=str(row.get('primary_therapeutic_area', '')),
                    roles=str(row.get('roles', '')),
                    city=str(row.get('org_city', '')),
                    oneliner_insight='',
                    multiliner_insights=''
                ))
        
        logger.info(f"Found {len(authors)} authors matching '{text}'")
        return ListResponse(
            success=True,
            message="Authors fetched successfully",
            data=authors,
            total_count=len(authors)
        )
    except Exception as e:
        logger.error(f"Error searching authors: {str(e)}")
        return ListResponse(
            success=False,
            message=f"Error searching authors: {str(e)}",
            data=None,
            total_count=0
        )


async def search_publications(text: str, background_tasks: BackgroundTasks) -> List[PublicationResponse]:
    """
    Search for publications by publication_id or title
    Returns list of PublicationResponse objects (same format as /api/publications)
    """
    logger.info(f"Searching publications with text: {text}")
    
    try:
        # Escape single quotes for SQL
        search_text = text.replace("'", "''")

        # Check if search text looks like a publication ID (contains numbers or specific patterns)
        is_potential_id = any(char.isdigit() for char in search_text) or len(search_text) > 5

        # Build WHERE clause dynamically
        where_conditions = []
        if is_potential_id:
            where_conditions.append(f"publication_id::text = '{search_text}'")
        where_conditions.append(f"LOWER(title) ILIKE LOWER('%{search_text}%')")

        where_clause = " OR ".join(where_conditions)

        # Query with exact and partial text search
        query = f"""
        SELECT
            publication_id,
            pmid,
            title,
            journal,
            journal_abbr,
            year,
            pmc_id,
            total_authors,
            therapeutic_area,
            insights_one_liner,
            insights_points,
            author_names as author_researcher_names,
            linked_project_ids,
            abstract
        FROM "ubi-ma-insights".test_nih_publications
        WHERE {where_clause}
        ORDER BY
            CASE
                WHEN publication_id::text = '{search_text}' THEN 1
                ELSE 2
            END,
            year DESC
        LIMIT 10
        """
        
        result = postgres_agent.execute_query(query, None)
        
        if not result.success:
            logger.error(f"Query failed: {result.error}")
            raise HTTPException(status_code=500, detail="Database query failed")
        
        # Process publications with parallel insight generation
        with_insights, needing_insights, insights_map = await process_items_with_insights(
            result.data or [], 'abstract', 'publication_id', background_tasks, update_publication_insights_async
        )

        # Build final publications list
        publications = []
        for item in with_insights:
            row = item['row']
            publications.append(PublicationResponse(
                publication_id=str(row['publication_id']),
                pmid=str(row['pmid']),
                title=row['title'],
                journal=row['journal'],
                journal_abbr=row['journal_abbr'],
                year=row['year'],
                pmc_id=str(row['pmc_id']) if row['pmc_id'] else "",
                total_authors=row['total_authors'],
                therapeutic_area=row['therapeutic_area'],
                author_researcher_names=row['author_researcher_names'] or "",
                oneliner_insight=item['insights'][0],
                multiliner_insights=item['insights'][1],
                linked_project_ids=row['linked_project_ids'] or "",
                abstract=row['abstract'] or "",
                pubmed_link=pubmed_link.format(pmid=str(row['pmid'])),
                pubmed_cited_link=pubmed_cited_link.format(pmc_id=str(row['pmc_id']).split('.')[0])
            ))

        # Add publications that had insights generated
        for item in needing_insights:
            row = item['row']
            insights = insights_map.get(item['id'], {'insights_one_liner': '', 'insights_points': ''})
            publications.append(PublicationResponse(
                publication_id=str(row['publication_id']),
                pmid=str(row['pmid']),
                title=row['title'],
                journal=row['journal'],
                journal_abbr=row['journal_abbr'],
                year=row['year'],
                pmc_id=str(row['pmc_id']) if row['pmc_id'] else "",
                total_authors=row['total_authors'],
                therapeutic_area=row['therapeutic_area'],
                author_researcher_names=row['author_researcher_names'] or "",
                oneliner_insight=insights.get('insights_one_liner', ''),
                multiliner_insights=insights.get('insights_points', ''),
                linked_project_ids=row['linked_project_ids'] or "",
                abstract=row['abstract'] or "",
                pubmed_link=pubmed_link.format(pmid=str(row['pmid'])),
                pubmed_cited_link=pubmed_cited_link.format(pmc_id=str(row['pmc_id']).split('.')[0])
            ))
        
        logger.info(f"Found {len(publications)} publications matching '{text}'")
        return ListResponse(
            success=True,
            message="Publications fetched successfully",
            data=publications,
            total_count=len(publications)
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error searching publications: {str(e)}")
        return ListResponse(
            success=False,
            message=f"Error searching publications: {str(e)}",
            data=None,
            total_count=0
        )


async def search_projects(text: str, background_tasks: BackgroundTasks) -> List[ProjectResponse]:
    """
    Search for projects by project_id or title
    Returns list of ProjectResponse objects (same format as /api/projects)
    """
    logger.info(f"Searching projects with text: {text}")
    
    try:
        # Escape single quotes for SQL
        search_text = text.replace("'", "''")

        # Check if search text looks like a project ID (contains numbers or specific patterns)
        is_potential_id = any(char.isdigit() for char in search_text) or len(search_text) > 5

        # Build WHERE clause dynamically
        where_conditions = []
        if is_potential_id:
            where_conditions.append(f"project_id::text = '{search_text}'")
        where_conditions.append(f"LOWER(title) ILIKE LOWER('%{search_text}%')")

        where_clause = " OR ".join(where_conditions)

        # Query with exact and partial text search
        query = f"""
        SELECT
            project_id,
            application_ids,
            title,
            funding_mechanism,
            fiscal_year,
            organization,
            org_city,
            org_state,
            start_date::text,
            end_date::text,
            total_cost,
            direct_cost,
            therapeutic_area,
            funding_ics,
            linked_publication_ids,
            insights_one_liner,
            insights_points,
            abstract_text
        FROM "ubi-ma-insights".test_nih_projects
        WHERE {where_clause}
        ORDER BY
            CASE
                WHEN project_id::text = '{search_text}' THEN 1
                ELSE 2
            END,
            fiscal_year DESC
        LIMIT 10
        """
        
        result = postgres_agent.execute_query(query, None)
        
        if not result.success:
            logger.error(f"Query failed: {result.error}")
            raise HTTPException(status_code=500, detail="Database query failed")
        
        # Process projects with parallel insight generation
        with_insights, needing_insights, insights_map = await process_items_with_insights(
            result.data or [], 'abstract_text', 'project_id', background_tasks, update_project_insights_async
        )

        # Build final projects list
        projects = []
        for item in with_insights:
            row = item['row']
            projects.append(ProjectResponse(
                project_id=row['project_id'],
                application_ids=row['application_ids'] or "",
                title=row['title'],
                pi_name="",
                funding_mechanism=row['funding_mechanism'],
                fiscal_year=row['fiscal_year'],
                organization=row['organization'],
                org_city=row['org_city'],
                org_state=row['org_state'],
                start_date=row['start_date'] or "",
                end_date=row['end_date'] or "",
                total_cost=row['total_cost'],
                direct_cost=row['direct_cost'],
                therapeutic_area=row['therapeutic_area'],
                funding_ics=row['funding_ics'] or "",
                linked_publication_ids=row['linked_publication_ids'] or "",
                oneliner_insight=item['insights'][0],
                multiliner_insights=item['insights'][1],
                abstract=row['abstract_text'] or ""
            ))

        # Add projects that had insights generated
        for item in needing_insights:
            row = item['row']
            insights = insights_map.get(item['id'], {'insights_one_liner': '', 'insights_points': ''})
            projects.append(ProjectResponse(
                project_id=row['project_id'],
                application_ids=row['application_ids'] or "",
                title=row['title'],
                pi_name="",
                funding_mechanism=row['funding_mechanism'],
                fiscal_year=row['fiscal_year'],
                organization=row['organization'],
                org_city=row['org_city'],
                org_state=row['org_state'],
                start_date=row['start_date'] or "",
                end_date=row['end_date'] or "",
                total_cost=row['total_cost'],
                direct_cost=row['direct_cost'],
                therapeutic_area=row['therapeutic_area'],
                funding_ics=row['funding_ics'] or "",
                linked_publication_ids=row['linked_publication_ids'] or "",
                oneliner_insight=insights.get('insights_one_liner', ''),
                multiliner_insights=insights.get('insights_points', ''),
                abstract=row['abstract_text'] or ""
            ))
        
        logger.info(f"Found {len(projects)} projects matching '{text}'")
        return ListResponse(
            success=True,
            message="Projects fetched successfully",
            data=projects,
            total_count=len(projects)
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error searching projects: {str(e)}")
        return ListResponse(
            success=False,
            message=f"Error searching projects: {str(e)}",
            data=None,
            total_count=0
        )