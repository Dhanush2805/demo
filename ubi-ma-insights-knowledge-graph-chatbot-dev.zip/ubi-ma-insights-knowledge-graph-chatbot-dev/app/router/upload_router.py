import os, io
from fastapi import APIRouter, HTTPException, BackgroundTasks, UploadFile, File, Form, Query
from fastapi.responses import JSONResponse
import json
from typing import Dict, Any, List, Optional
from app.core.logger import get_logger
from app.core.models import (
    S3UploadRequest, LocalUploadRequest, UploadResponse, 
    TextInsightsRequest, TextInsightsResponse,
    TempUploadResponse, FileUploadInfo,
    TempChatRequest, TempChatResponse,
    PPTAnalysisResponse
)
from app.agents.upload_agent import UploadAgent
from app.agents.local_file_agent import LocalFileAgent

# Initialize logger and router
logger = get_logger('api')
router = APIRouter(prefix="/api/v1/upload", tags=["upload"])

# Initialize upload agent
upload_agent = UploadAgent()
local_file_agent = LocalFileAgent()

@router.post("/s3-knowledge-graph", response_model=UploadResponse)
async def upload_s3_knowledge_graph(request: S3UploadRequest, iterative: bool = Query(False)) -> UploadResponse:
    """
    Upload and process files from S3 to create knowledge graph
    
    This endpoint downloads files from S3 and creates:
    1. Neo4j knowledge graph with nodes and relationships  
    2. Vector embeddings for semantic search
    3. Relations to existing data (when iterative mode is enabled)
    
    Args:
        request: S3UploadRequest containing S3 URL and credentials
        iterative: Whether to process files one by one (sharing schema between iterations)
        
    Returns:
        UploadResponse with processing results and schema information
    """
    mode = "iterative" if iterative else "standard"
    logger.info(f"S3 upload API endpoint called for URL: {request.s3_url} (mode: {mode})")
    
    try:
        # Validate request before processing
        logger.info("Validating upload request")
        validation_results = upload_agent.validate_upload_request(request)
        
        if not validation_results['valid']:
            error_msg = "Request validation failed: " + "; ".join(validation_results['errors'])
            logger.error(error_msg)
            raise HTTPException(status_code=400, detail=error_msg)
        
        # Log validation warnings if any
        if validation_results.get('warnings'):
            for warning in validation_results['warnings']:
                logger.warning(f"Upload validation warning: {warning}")
        
        # Process the upload (iterative or standard based on parameter)
        logger.info(f"Starting {mode} upload processing")
        if iterative:
            response = upload_agent.process_s3_upload_iterative(request)
        else:
            response = upload_agent.process_s3_upload(request)
        
        if response.success:
            logger.info(f"{mode.title()} upload completed successfully: {response.message}")
        else:
            logger.error(f"{mode.title()} upload failed: {response.message}")
            # Return 422 for processing errors (valid request but processing failed)
            raise HTTPException(status_code=422, detail=response.message)
        
        return response
        
    except HTTPException:
        # Re-raise HTTP exceptions
        raise
    except Exception as e:
        error_msg = f"Unexpected error in upload endpoint: {str(e)}"
        logger.error(error_msg)
        raise HTTPException(status_code=500, detail="Internal server error during upload processing")

@router.post("/local-knowledge-graph", response_model=UploadResponse)
async def upload_local_knowledge_graph(request: LocalUploadRequest, iterative: bool = Query(False)) -> UploadResponse:
    """
    Upload and process files from local file paths to create knowledge graph
    
    This endpoint processes local files and creates:
    1. Neo4j knowledge graph with nodes and relationships
    2. Vector embeddings for semantic search (optional)
    3. Relations to existing data (when iterative mode is enabled)
    
    Args:
        request: LocalUploadRequest containing file paths and processing options
        iterative: Whether to process files one by one (sharing schema between iterations)
        
    Returns:
        UploadResponse with processing results and schema information
    """
    mode = "iterative" if iterative else "standard"
    logger.info(f"Local upload API endpoint called for {len(request.file_paths)} files (mode: {mode})")
    
    try:
        # Validate request before processing
        logger.info("Validating local upload request")
        validation_results = upload_agent.validate_local_upload_request(request)
        
        if not validation_results['valid']:
            error_msg = "Request validation failed: " + "; ".join(validation_results['errors'])
            logger.error(error_msg)
            raise HTTPException(status_code=400, detail=error_msg)
        
        # Log validation warnings if any
        if validation_results.get('warnings'):
            for warning in validation_results['warnings']:
                logger.warning(f"Local upload validation warning: {warning}")
        
        # Process the upload (iterative or standard based on parameter)
        logger.info(f"Starting {mode} local upload processing")
        if iterative:
            response = upload_agent.process_local_upload_iterative(request)
        else:
            response = upload_agent.process_local_upload(request)
        
        if response.success:
            logger.info(f"{mode.title()} local upload completed successfully: {response.message}")
        else:
            logger.error(f"{mode.title()} local upload failed: {response.message}")
            raise HTTPException(status_code=422, detail=response.message)
        
        return response
        
    except HTTPException:
        # Re-raise HTTP exceptions
        raise
    except Exception as e:
        error_msg = f"Unexpected error in local upload endpoint: {str(e)}"
        logger.error(error_msg)
        raise HTTPException(status_code=500, detail="Internal server error during local upload processing")








@router.delete("/cleanup", response_model=Dict[str, Any])
async def cleanup_upload_data() -> Dict[str, Any]:
    """
    Clean up all upload data (USE WITH CAUTION)
    
    This endpoint will:
    1. Clear all data from Neo4j database
    2. Remove all vector embeddings
    3. Delete processed CSV files
    
    WARNING: This operation is irreversible!
    
    Returns:
        Dictionary with cleanup results
    """
    logger.info("Cleanup API endpoint called")
    
    try:
        cleanup_results = upload_agent.cleanup_upload_data()
        
        logger.info(f"Cleanup completed - Database cleared: {cleanup_results.get('database_cleared', False)}")
        return cleanup_results
        
    except Exception as e:
        error_msg = f"Error during cleanup: {str(e)}"
        logger.error(error_msg)
        raise HTTPException(status_code=500, detail=error_msg)

@router.get("/health", response_model=Dict[str, str])
async def health_check() -> Dict[str, str]:
    """
    Simple health check endpoint
    
    Returns:
        Dictionary with health status
    """
    return {
        "status": "healthy",
        "service": "upload-service",
        "message": "Upload service is running"
    }

@router.post("/local-knowledge-graph-chunked", response_model=UploadResponse)
async def upload_local_knowledge_graph_chunked(request: LocalUploadRequest) -> UploadResponse:
    """
    Upload and process local files using chunk-wise Cypher query generation
    
    This endpoint processes CSV files in configurable chunks for incremental knowledge graph building:
    1. Converts files to CSV format
    2. Processes each CSV in chunks of specified size (default: 10 rows)
    3. Generates Cypher queries using MERGE statements for each chunk
    4. Executes queries incrementally to build/update the knowledge graph
    5. Creates vector embeddings if requested
    
    Benefits:
    - Improved accuracy through incremental processing
    - Better error handling and recovery
    - Configurable chunk size for performance tuning
    - Uses MERGE to prevent duplicates and enable updates
    
    Args:
        request: LocalUploadRequest containing file paths and chunk_size
        
    Returns:
        UploadResponse with processing results and schema information
    """
    logger.info(f"Local chunked upload API endpoint called for {len(request.file_paths)} files "
                f"(chunk size: {request.chunk_size})")
    
    try:
        # Validate request before processing
        logger.info("Validating chunked local upload request")
        validation_results = upload_agent.validate_local_upload_request(request)
        
        if not validation_results['valid']:
            error_msg = "Request validation failed: " + "; ".join(validation_results['errors'])
            logger.error(error_msg)
            raise HTTPException(status_code=400, detail=error_msg)
        
        # Log validation warnings if any
        if validation_results.get('warnings'):
            for warning in validation_results['warnings']:
                logger.warning(f"Chunked local upload validation warning: {warning}")
        
        # Process the upload using chunk-wise processing
        logger.info(f"Starting chunked local upload processing with chunk size: {request.chunk_size}")
        response = upload_agent.process_local_upload_chunked(request)
        
        if response.success:
            logger.info(f"Chunked local upload completed successfully: {response.message}")
        else:
            logger.error(f"Chunked local upload failed: {response.message}")
            raise HTTPException(status_code=422, detail=response.message)
        
        return response
        
    except HTTPException:
        # Re-raise HTTP exceptions
        raise
    except Exception as e:
        error_msg = f"Unexpected error in chunked local upload endpoint: {str(e)}"
        logger.error(error_msg)
        raise HTTPException(status_code=500, detail="Internal server error during chunked local upload processing")

@router.post("/s3-knowledge-graph-chunked", response_model=UploadResponse)
async def upload_s3_knowledge_graph_chunked(request: S3UploadRequest) -> UploadResponse:
    """
    Upload and process S3 files using chunk-wise Cypher query generation
    
    This endpoint downloads files from S3 and processes them in configurable chunks:
    1. Downloads files from S3 URL
    2. Converts files to CSV format  
    3. Processes each CSV in chunks of specified size (default: 10 rows)
    4. Generates Cypher queries using MERGE statements for each chunk
    5. Executes queries incrementally to build/update the knowledge graph
    6. Creates vector embeddings for semantic search
    
    Benefits:
    - Improved accuracy through incremental processing
    - Better error handling and recovery
    - Configurable chunk size for performance tuning
    - Uses MERGE to prevent duplicates and enable updates
    
    Args:
        request: S3UploadRequest with S3 URL, credentials, and chunk_size
        
    Returns:
        UploadResponse with detailed chunk processing results
    """
    logger.info(f"Chunked S3 upload API endpoint called for URL: {request.s3_url} "
                f"(chunk size: {request.chunk_size})")
    
    try:
        # Validate request before processing
        logger.info("Validating chunked S3 upload request")
        validation_results = upload_agent.validate_s3_upload_request(request)
        
        if not validation_results['valid']:
            error_msg = "Request validation failed: " + "; ".join(validation_results['errors'])
            logger.error(error_msg)
            raise HTTPException(status_code=400, detail=error_msg)
        
        # Log validation warnings if any
        if validation_results.get('warnings'):
            for warning in validation_results['warnings']:
                logger.warning(f"Chunked S3 upload validation warning: {warning}")
        
        # Process the upload using chunk-wise processing
        logger.info(f"Starting chunked S3 upload processing with chunk size: {request.chunk_size}")
        response = upload_agent.process_s3_upload_chunked(request)
        
        if response.success:
            logger.info(f"Chunked S3 upload completed successfully: {response.message}")
        else:
            logger.error(f"Chunked S3 upload failed: {response.message}")
            raise HTTPException(status_code=422, detail=response.message)
        
        return response
        
    except HTTPException:
        # Re-raise HTTP exceptions
        raise
    except Exception as e:
        error_msg = f"Unexpected error in chunked S3 upload endpoint: {str(e)}"
        logger.error(error_msg)
        raise HTTPException(status_code=500, detail="Internal server error during chunked S3 upload processing")


@router.post("/temp-upload", response_model=TempUploadResponse)
async def temp_upload(
    files: List[UploadFile] = File(..., description="PDF and video files to upload")
) -> TempUploadResponse:
    """
    Upload PDF and Video files to S3 and create vectors for PDFs and video transcripts
    
    This endpoint:
    1. Accepts PDF and video files via multipart upload
    2. Uploads all files to a fixed S3 bucket/folder using AWS credentials
    3. For PDF files: extracts text and creates vector embeddings
    4. For video files: gets transcript via external API and creates vector embeddings
    
    **Supported file types:**
    - PDF files (.pdf) - uploaded to S3 and processed for vectors
    - Video files (.mp4) - uploaded to S3 and processed for transcript vectors
    
    **Requirements:**
    - AWS credentials configured (environment variables, IAM roles, or AWS CLI)
    - Uses fixed S3 bucket: json-data-storage
    - External transcript API access for video processing
    
    Args:
        files: List of uploaded files (PDFs and videos)
        
    Returns:
        TempUploadResponse with upload results and vector processing status
    """

    try:
        from app.agents.temp_upload_agent import TempUploadAgent
        
        temp_upload_agent = TempUploadAgent()
        
        # Validate request before processing
        logger.info("Validating temp upload request")
        validation_results = temp_upload_agent.validate_request(files)
        
        if not validation_results['valid']:
            error_msg = "Request validation failed: " + "; ".join(validation_results['errors'])
            logger.error(error_msg)
            raise HTTPException(status_code=400, detail=error_msg)
        
        if validation_results.get('warnings'):
            for warning in validation_results['warnings']:
                logger.warning(f"Temp upload validation warning: {warning}")
        
        logger.info("Starting temp upload processing")
        response = temp_upload_agent.process_temp_upload(files)
        
        if response.success:
            logger.info(f"Temp upload completed successfully: {response.message}")
        else:
            logger.error(f"Temp upload failed: {response.message}")
            raise HTTPException(status_code=422, detail=response.message)
        
        return response
        
    except HTTPException:

        raise
    except Exception as e:
        error_msg = f"Unexpected error in temp upload endpoint: {str(e)}"
        logger.error(error_msg)
        raise HTTPException(status_code=500, detail="Internal server error during temp upload processing")


def extract_docx_content(docx_file: UploadFile) -> str:
    """Extract text content from DOCX file"""
    try:
        from docx import Document
        
        # Read the file content
        file_content = docx_file.file.read()
        docx_file.file.seek(0)  # Reset file pointer
        
        # Parse the DOCX document
        document = Document(io.BytesIO(file_content))
        
        # Extract text from all paragraphs
        text_content = ""
        for paragraph in document.paragraphs:
            if paragraph.text.strip():
                text_content += paragraph.text + "\n"
        
        # Extract text from tables if present
        for table in document.tables:
            for row in table.rows:
                row_text = " | ".join([cell.text.strip() for cell in row.cells])
                if row_text.strip():
                    text_content += row_text + "\n"
        
        return text_content.strip()
        
    except Exception as e:
        logger.error(f"Error extracting content from DOCX file {docx_file.filename}: {str(e)}")
        raise Exception(f"Failed to extract DOCX content: {str(e)}")


@router.post("/analysis")
async def analyze_powerpoint_presentations(
    files: List[UploadFile] = File(..., description="PowerPoint files to analyze and compare"),
    analysis_criteria: UploadFile = File(..., description="DOCX file containing analysis criteria/template")
):
    """
    Analyze and compare PowerPoint presentations with customizable analysis criteria
    
    Takes PowerPoint files, extracts content, and returns summaries 
    and comparison analysis as formatted markdown based on the provided analysis criteria.
    
    Args:
        files: List of PowerPoint files to analyze
        analysis_criteria: DOCX file containing analysis criteria/template (e.g., grant review criteria)
        
    Returns:
        JSON with 'analysis' and 'graph' fields
    """
    import time
    from app.agents.llm_agent import LLMAgent
    from app.services.config_service import config
    
    # Extract analysis criteria from DOCX file
    # Validate file extension
    file_ext = os.path.splitext(analysis_criteria.filename)[1].lower()
    if file_ext not in ['.docx']:
        raise HTTPException(status_code=400, detail=f"Analysis criteria file must be .docx format, got: {file_ext}")
    
    try:
        analysis_type = extract_docx_content(analysis_criteria)
        logger.info(f"PPT Analysis API called for {len(files)} files with analysis criteria from: {analysis_criteria.filename}")
    except Exception as e:
        logger.error(f"Failed to extract analysis criteria from {analysis_criteria.filename}: {str(e)}")
        raise HTTPException(status_code=400, detail=f"Failed to process analysis criteria file: {str(e)}")
    
    start_time = time.time()
    
    try:
        # Initialize LLM agent
        aws_credentials = None
        if config.llm.provider.lower() == "bedrock":
            aws_credentials = config.get_aws_credentials_from_env()
            if not aws_credentials:
                raise HTTPException(status_code=400, detail="AWS credentials required for Bedrock provider")
        
        llm_agent = LLMAgent(aws_credentials)
        
        # Extract content from all PPT files
        ppt_contents = []
        errors = []
        
        for file in files:
            file_ext = os.path.splitext(file.filename)[1].lower()
            if file_ext not in ['.ppt', '.pptx']:
                errors.append(f"Unsupported file: {file.filename}")
                continue
                
            try:
                file_content = file.file.read()
                file.file.seek(0)
                
                full_content, slide_count = extract_complete_ppt_content(file_content, file.filename)
                
                if full_content.strip():
                    ppt_contents.append({
                        'filename': file.filename,
                        'content': full_content,
                        'slide_count': slide_count
                    })
                    logger.info(f"Extracted content from {file.filename} ({slide_count} slides)")
                else:
                    errors.append(f"No content extracted from {file.filename}")
                    
            except Exception as e:
                error_msg = f"Error processing {file.filename}: {str(e)}"
                logger.error(error_msg)
                errors.append(error_msg)
        
        if not ppt_contents:
            raise HTTPException(status_code=400, detail="No valid PowerPoint content found")
        
        # Generate analysis in single LLM call
        analysis_result = generate_ppt_analysis_markdown(llm_agent, ppt_contents, analysis_type)
        
        processing_time = time.time() - start_time
        
        # Try to parse the LLM output as JSON
        try:
            result_json = json.loads(analysis_result)
            # Optionally, add extra info if needed
            result_json['success'] = True
            result_json['files_processed'] = len(ppt_contents)
            result_json['processing_time'] = processing_time
            if errors:
                result_json['errors'] = errors
            return JSONResponse(content=result_json)
        except Exception as e:
            logger.error(f"Failed to parse LLM output as JSON: {str(e)} | Output: {analysis_result}")
            return JSONResponse(content={
                "success": False,
                "message": "Failed to parse LLM output as JSON",
                "raw_output": analysis_result,
                "files_processed": len(ppt_contents),
                "processing_time": processing_time,
                "errors": errors + [str(e)] if errors else [str(e)]
            }, status_code=500)
        
    except HTTPException:
        raise
    except Exception as e:
        error_msg = f"Unexpected error in PPT analysis: {str(e)}"
        logger.error(error_msg)
        return JSONResponse(content={
            "success": False,
            "message": error_msg
        }, status_code=500)


def extract_complete_ppt_content(ppt_content: bytes, filename: str) -> tuple:
    """Extract complete text content from PowerPoint file"""
    try:
        from pptx import Presentation
        
        presentation = Presentation(io.BytesIO(ppt_content))
        complete_content = ""
        slide_count = len(presentation.slides)
        
        for slide_num, slide in enumerate(presentation.slides, 1):
            slide_content = f"\n=== SLIDE {slide_num} ===\n"
            
            # Extract text from all shapes in the slide
            for shape in slide.shapes:
                if hasattr(shape, "text") and shape.text.strip():
                    slide_content += shape.text + "\n"
            
            # Extract text from tables if present
            if hasattr(slide, 'shapes'):
                for shape in slide.shapes:
                    if shape.has_table:
                        table = shape.table
                        for row in table.rows:
                            row_text = " | ".join([cell.text for cell in row.cells])
                            slide_content += row_text + "\n"
            
            complete_content += slide_content
        
        return complete_content.strip(), slide_count
        
    except Exception as e:
        logger.error(f"Error extracting content from {filename}: {str(e)}")
        raise Exception(f"Failed to extract PowerPoint content: {str(e)}")


def generate_ppt_analysis_markdown(llm_agent, ppt_contents: List[Dict], analysis_type: str = "") -> str:
    """Generate complete PPT analysis as markdown in single LLM call"""
    
    # Build content for all presentations
    presentations_text = ""
    for i, ppt_data in enumerate(ppt_contents, 1):
        presentations_text += f"\n\n{'='*60}\n"
        presentations_text += f"PRESENTATION {i}: {ppt_data['filename']}\n"
        presentations_text += f"Slides: {ppt_data['slide_count']}\n"
        presentations_text += f"{'='*60}\n"
        presentations_text += ppt_data['content']
    
    # Use custom analysis criteria from DOCX file
    prompt = f"""
IMPORTANT: The analysis and the graph must be generated independently.

- The **analysis** must be based ONLY on the provided analysis criteria (from the DOCX file) and the content of the presentations.
- The **graph** must be generated ONLY from the actual data/content found in the PowerPoint presentations, NOT from the analysis criteria.

**Do NOT use the analysis criteria to generate the graph.**
**Do NOT use the analysis criteria as data for the graph.**
**The graph should reflect real, extractable data from the presentations.**
**The analysis section should NOT reference or explain the graph in any way.**

---

Analyze these {len(ppt_contents)} PowerPoint presentation(s) according to the specified criteria below.

PRESENTATIONS:
{presentations_text}

ANALYSIS CRITERIA:
{analysis_type}

---

# OUTPUT INSTRUCTIONS
- First, provide a detailed analysis table and then markdown analysis of the presentations seperately, strictly following the analysis criteria above.
- Use only the criteria and the actual content of the presentations for this section.
- For each point in the analysis, give a short, concise explanation (avoid lengthy paragraphs) in markdown analysis.
- Do NOT mention, reference, or explain the graph in the analysis section.
- generate a complete HTML chart based ONLY on the data/content from the presentations. Do NOT use the analysis criteria for the graph.
- In the graph, if any values are much larger than others, scale them (e.g., show in thousands as 'K') so all values are visible and the chart is readable. 
- Below the chart, include a very short summary or insight (1–2 sentences) about what the graph shows. 
- Do NOT provide a detailed explanation, axis description, or bullet points for the graph.
- The graph and the analysis must be clearly separated in the output.

Create a grouped bar chart comparing key quantitative metrics between two grant applications. The metrics are:

Funding Requested ($1000s)
Sample Size (patients)
Duration (months)
PI Publications
Number of Clinics

Each metric should be represented by a different color, and bars grouped by grant application. Include the exact value as a label on top of each bar.
**DO NOT SHOW THE VALUES ON THE BARS**

Ensure the chart has a clean and professional look.
Please analyze each presentation according to the above criteria and provide your evaluation exactly as requested in the criteria.

Please answer using clean, readable Markdown.
Use ### or ## for section headers.
Use **bold** to highlight key topics, important points, scores and numbers.
Use bullet points or numbered lists where appropriate for clarity.
Do NOT wrap the output in code blocks (no triple backticks).
The final output should be ready to render in a Markdown viewer or save as a .md file with no extra formatting required.
response should start with table with recommendation and then the analysis.

#OUTPUT FORMAT:
Json with the following fields:
{{
    "analysis": "Always give table with recommendation in the start and then the Markdown analysis seperately(based on criteria, no graph explanation, concise points and )",
    "graph": "HTML chart (based on PPT data only, with short summary below, large values scaled if needed)"
}}
```

## HTML TEMPLATE EXAMPLE:
For graphs, use this Chart.js template structure:

```html
<!DOCTYPE html>
<html>
<head>
<script src=\"https://cdn.jsdelivr.net/npm/apexcharts\"></script>
<style>
        body {{
            font-family: Arial, sans-serif;
            padding: 20px;
        }}
        .chart-container {{
            width: 400px;
            margin: 0 auto;
        }}
</style>
</head>
<body>
<div class=\"chart-container\">
<div id=\"myChart\"></div>
</div>
 
    <script>
        var options = {{
            chart: {{
                type: 'bar',
                height: 200
            }},
            series: [{{
                name: 'Dataset Label',
                data: [12, 19, 3]
            }}],
            xaxis: {{
                categories: ['Label1', 'Label2', 'Label3']
            }},
            title: {{
                text: 'Chart Title',
                align: 'center'
            }},
            plotOptions: {{
                bar: {{
                    horizontal: false,
                    columnWidth: '50%',
                    borderRadius: 4,
                    endingShape: 'rounded'
                }}
            }},
            colors: ['#FF6384', '#36A2EB', '#FFCE56']
            dataLabels: {{
                enabled: false // **DO NOT SHOW THE VALUES ON THE BARS**
            }}
        }};
 
        var chart = new ApexCharts(document.querySelector("#myChart"), options);
        chart.render();
</script>
<!-- Short summary/insight about the graph goes here -->
</body>
</html>
```

"""
    try:
        markdown_response = llm_agent._generate_llm_response(prompt)
        return markdown_response.strip()
        
    except Exception as e:
        logger.error(f"Error generating markdown analysis: {str(e)}")
        analysis_info = "Custom criteria provided"
        
        return f"""# Analysis Error

An error occurred while generating the analysis: {str(e)}

## Files Processed
{chr(10).join([f"- {ppt['filename']} ({ppt['slide_count']} slides)" for ppt in ppt_contents])}

## Analysis Type
{analysis_info}
"""





@router.post("/temp-chat", response_model=TempChatResponse)
async def temp_chat(request: TempChatRequest) -> TempChatResponse:
    """
    Ask questions about uploaded PDF and video files using their content
    
    This endpoint:
    1. Takes a question and source filename
    2. Searches for vectors from the specified uploaded file
    3. Uses LLM to answer the question based on file content (PDF text or video transcript)
    4. Returns answer with context from the file
    
    Args:
        request: TempChatRequest with question and source filename
        
    Returns:
        TempChatResponse with answer based on file content
    """
    logger.info(f"Temp chat API endpoint called for file: {request.source_filename}")
    
    try:
        from app.agents.temp_chat_agent import TempChatAgent
        
        temp_chat_agent = TempChatAgent()
        
        # Process the chat request
        logger.info(f"Processing question: '{request.question}' for file: {request.source_filename}")
        response = temp_chat_agent.process_temp_chat(request)
        
        if response.success:
            logger.info(f"Temp chat completed successfully for {request.source_filename}")
        else:
            logger.error(f"Temp chat failed: {response.error}")
            raise HTTPException(status_code=422, detail=response.error)
        
        return response
        
    except HTTPException:
        # Re-raise HTTP exceptions
        raise
    except Exception as e:
        error_msg = f"Unexpected error in temp chat endpoint: {str(e)}"
        logger.error(error_msg)
        raise HTTPException(status_code=500, detail="Internal server error during temp chat processing")

@router.post("/text-insights", response_model=TextInsightsResponse)
async def analyze_text_insights(request: TextInsightsRequest) -> TextInsightsResponse:
    """
    Extract meaningful points from text content using LLM
    
    **Simple and Focused**: Give it any text (paragraphs, bullet points, notes) and get back clean, meaningful insights.
    
    **What it does**:
    - Takes your text input (any format)
    - Extracts the most important and meaningful points
    - Returns clear, actionable insights
    - Removes fluff and focuses on what matters
    
    **Perfect for**:
    - Meeting notes → Key takeaways
    - Email content → Action items  
    - Document text → Main points
    - Bullet lists → Consolidated insights
    - Research notes → Important findings
    
    **Input**: Any text content up to 50,000 characters
    **Output**: List of meaningful points (3-8 items)
    
    Args:
        request: TextInsightsRequest with your text content
        
    Returns:
        TextInsightsResponse with meaningful_points array
    """
    logger.info(f"Text insights API endpoint called for {len(request.text)} characters")
    
    try:
        # Import here to avoid circular imports
        from app.agents.text_insights_agent import TextInsightsAgent
        
        # Initialize text insights agent
        insights_agent = TextInsightsAgent()
        
        # Validate request before processing
        logger.info("Validating text insights request")
        validation_results = insights_agent.validate_request(request)
        
        if not validation_results['valid']:
            error_msg = "Request validation failed: " + "; ".join(validation_results['errors'])
            logger.error(error_msg)
            raise HTTPException(status_code=400, detail=error_msg)
        
        # Log validation warnings if any
        if validation_results.get('warnings'):
            for warning in validation_results['warnings']:
                logger.warning(f"Text insights validation warning: {warning}")
        
        # Process the text analysis
        logger.info("Starting text insights analysis")
        response = insights_agent.analyze_text(request)
        
        if response.success:
            logger.info(f"Text insights analysis completed successfully: {response.message}")
        else:
            logger.error(f"Text insights analysis failed: {response.message}")
            raise HTTPException(status_code=422, detail=response.message)
        
        return response
        
    except HTTPException:
        # Re-raise HTTP exceptions
        raise
    except Exception as e:
        error_msg = f"Unexpected error in text insights endpoint: {str(e)}"
        logger.error(error_msg)
        raise HTTPException(status_code=500, detail="Internal server error during text insights analysis") 