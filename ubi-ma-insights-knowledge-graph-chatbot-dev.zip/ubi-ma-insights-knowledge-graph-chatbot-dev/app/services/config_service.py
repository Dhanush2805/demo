import os
from dataclasses import dataclass
from typing import Optional
from app.core.logger import get_logger

logger = get_logger('config_service')

@dataclass
class Neo4jConfig:
    """Neo4j database configuration"""
    uri: str = "neo4j+s://1dbb7ea7.databases.neo4j.io"
    user: str = "neo4j"
    password: str ="QYmvzM6BcNNkhMfno3PyduZRskQ-QxUPzC9G1on-pn4"

@dataclass
class PostgreSQLConfig:
    """PostgreSQL database configuration"""
    host: str = "localhost"
    port: int = 5432
    database: str = "postgres"
    user: str = "postgres"
    password: str = "password"
    connection_timeout: int = 30
    max_connections: int = 20
    schema: str = "public"
    data_ingestion_schema: str = "data_ingestion"

@dataclass
class VectorConfig:
    """Vector database configuration"""
    vector_db_folder: str = "./vector_db"
    model_name: str = "all-MiniLM-L6-v2"

@dataclass
class FileConfig:
    """File processing configuration"""
    temp_folder: str = "./temp_files"
    csv_folder: str = "C:/neo4j-import"
    max_file_size_mb: int = 100

@dataclass
class LLMConfig:
    """LLM configuration for both Bedrock and Azure OpenAI"""
    # LLM Provider Selection
    provider: str = "azure_openai"  # Options: "bedrock", "azure_openai"
    
    # Bedrock configuration
    bedrock_model_id: str = "us.anthropic.claude-sonnet-4-20250514-v1:0"
    bedrock_region: str = "us-west-2"
    
    # Azure OpenAI configuration - Updated with working config from test script
    azure_endpoint: str = "https://ubi-coe-genai-studio.openai.azure.com/"
    azure_api_key: str = "BzxagG6fHvzGq1yuf8BffftQzy7bpAttwjIYfmvGEnB7buJoN54UJQQJ99BFAC77bzfXJ3w3AAABACOGWPWp"
    azure_model_name: str = "gpt-4.1-mini"  # Using the working model from test
    azure_api_version: str = "2024-10-21"  # Updated to the working version
    
    # Common configuration
    max_tokens: int = 4000
    temperature: float = 0

@dataclass
class AWSConfig:
    """AWS Client configuration"""

    aws_access_key_id: str =""
    aws_secret_access_key :str =""
    region_name: str = "ap-south-1"
@dataclass
class DatabricksConfig:
    """Databricks configuration"""
    base_url: str
    token: str
    api_version: str = "2.2"
@dataclass
class DatabricksConfig:
    """Databricks configuration"""
    base_url: str
    token: str
    api_version: str = "2.2"
    default_job: str = None

class ConfigService:
    """Service for managing application configuration"""
    
    def __init__(self):
        """Initialize configuration from environment variables or defaults"""
        logger.info("Initializing configuration service")
        
        # Neo4j configuration
        self.neo4j = Neo4jConfig(
            uri=os.getenv("NEO4J_URI", "neo4j+s://f718993b.databases.neo4j.io"),
            user=os.getenv("NEO4J_USER", "neo4j"),
            password=os.getenv("NEO4J_PASSWORD","G53U0JMeI5dObjyy8TapG-jqluAdBEQzZ7XsCfi0kEI")
        )
        
        
        # PostgreSQL configuration
        self.postgresql = PostgreSQLConfig(
            host=os.getenv("POSTGRESQL_HOST", "ubi-ma-insights.cxqua08ywknm.ap-south-1.rds.amazonaws.com"),
            port=int(os.getenv("POSTGRESQL_PORT", "5432")),
            database=os.getenv("POSTGRESQL_DATABASE", "postgres"),
            user=os.getenv("POSTGRESQL_USER", "mainsights"),
            password=os.getenv("POSTGRESQL_PASSWORD", "TSgg10rd[0pV.wDR#Sb]aJ]-lljG"),
            connection_timeout=int(os.getenv("POSTGRESQL_CONNECTION_TIMEOUT", "30")),
            max_connections=int(os.getenv("POSTGRESQL_MAX_CONNECTIONS", "20")),
            schema=os.getenv("POSTGRESQL_SCHEMA", "ubi-ma-insights"),
            data_ingestion_schema=os.getenv("POSTGRESQL_INGESTION_SCHEMA", "data_ingestion")
        )
        
        # Vector database configuration
        self.vector = VectorConfig(
            vector_db_folder=os.getenv("VECTOR_DB_FOLDER", "./vector_db"),
            model_name=os.getenv("VECTOR_MODEL_NAME", "all-MiniLM-L6-v2")
        )
        
        # File processing configuration
        self.files = FileConfig(
            temp_folder=os.getenv("TEMP_FOLDER", "./temp_files"),
            csv_folder=os.getenv("CSV_FOLDER", "C:/neo4j-import"),
            max_file_size_mb=int(os.getenv("MAX_FILE_SIZE_MB", "100"))
        )
        
        # LLM configuration
        self.llm = LLMConfig(
            provider=os.getenv("LLM_PROVIDER", "azure_openai"),
            bedrock_model_id=os.getenv("BEDROCK_MODEL_ID", "us.anthropic.claude-sonnet-4-20250514-v1:0"),
            bedrock_region=os.getenv("BEDROCK_REGION", "us-west-2"),
            azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", "https://ubi-coe-genai-studio.openai.azure.com/"),
            azure_api_key=os.getenv("AZURE_OPENAI_API_KEY", "BzxagG6fHvzGq1yuf8BffftQzy7bpAttwjIYfmvGEnB7buJoN54UJQQJ99BFAC77bzfXJ3w3AAABACOGWPWp"),
            azure_model_name=os.getenv("AZURE_OPENAI_MODEL_NAME", "gpt-4.1-mini"),
            azure_api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21"),
            max_tokens=int(os.getenv("LLM_MAX_TOKENS", "4000")),
            temperature=float(os.getenv("LLM_TEMPERATURE", "0.1"))
        )

        # Databricks configuration
        self.databricks = DatabricksConfig(
            api_version= "2.2",
            base_url=os.getenv("DATABRICKS_BASE_URL", "https://adb-759671377193455.15.azuredatabricks.net"),
            token=os.getenv("DATABRICKS_TOKEN", "dapia90f55a37f45e2176aec054f05781aaa"),
            default_job=os.getenv("DATABRICKS_DEFAULT_JOB_ID", "939247304710426")
        )

        # Create necessary directories
        self._create_directories()
        
        logger.info("Configuration service initialized successfully")
    
    def _create_directories(self):
        """Create necessary directories if they don't exist"""
        directories = [
            self.vector.vector_db_folder,
            self.files.temp_folder,
            self.files.csv_folder,
            "logs"
        ]
        
        for directory in directories:
            os.makedirs(directory, exist_ok=True)
            logger.info(f"Ensured directory exists: {directory}")
    
    def get_aws_credentials_from_env(self) -> Optional[dict]:
        """Get AWS credentials from environment variables"""
        
        aws_access_key_id = os.getenv("AWS_ACCESS_KEY_ID")
        aws_secret_access_key = os.getenv("AWS_SECRET_ACCESS_KEY")
        aws_session_token = os.getenv("AWS_SESSION_TOKEN")
        region_name = os.getenv("AWS_DEFAULT_REGION", "us-west-2")
        
        # Return None if no credentials provided (for public S3 access)
        if not aws_access_key_id or not aws_secret_access_key:
            logger.info("No AWS credentials found in environment variables - will use public S3 access")
            return None
        
        credentials = {
            'aws_access_key_id': aws_access_key_id,
            'aws_secret_access_key': aws_secret_access_key,
            'region_name': region_name
        }
        
        if aws_session_token:
            credentials['aws_session_token'] = aws_session_token
        
        logger.info(f"AWS credentials loaded from environment for region: {region_name}")
        return credentials
    
    def get_aws_credentials(self, aws_access_key_id: Optional[str], aws_secret_access_key: Optional[str], 
                          aws_session_token: Optional[str] = None, region_name: str = "us-west-2") -> Optional[dict]:
        """Format AWS credentials for boto3 - returns None for public access"""
        
        # Return None if no credentials provided (for public S3 access)
        if not aws_access_key_id or not aws_secret_access_key:
            logger.info("No AWS credentials provided - will use public S3 access")
            return None
        
        credentials = {
            'aws_access_key_id': aws_access_key_id,
            'aws_secret_access_key': aws_secret_access_key,
            'region_name': region_name
        }
        
        if aws_session_token:
            credentials['aws_session_token'] = aws_session_token
        
        logger.info(f"AWS credentials configured for region: {region_name}")
        return credentials

# Global configuration instance
config = ConfigService() 