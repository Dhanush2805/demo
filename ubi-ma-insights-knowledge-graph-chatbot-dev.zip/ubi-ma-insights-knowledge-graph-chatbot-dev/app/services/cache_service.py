import json
import os
import hashlib
from typing import Dict, Any, Optional
from app.core.logger import get_logger
from app.core.models import ChatRequest, ChatResponse

logger = get_logger('cache_service')

class CacheService:
    """
    In-memory cache for question-answer pairs
    Singleton pattern to ensure all parts of the application use the same cache instance
    """
    
    _instance = None
    _initialized = False
    
    def __new__(cls, cache_dir: str = "cache"):
        if cls._instance is None:
            cls._instance = super(CacheService, cls).__new__(cls)
        return cls._instance
    
    def __init__(self, cache_dir: str = "cache"):
        """
        Initialize cache service (only once due to singleton pattern)
        
        Args:
            cache_dir: Directory to store cache files
        """
        if not self._initialized:
            self.cache_dir = cache_dir
            self.cache_file = os.path.join(cache_dir, "chat_cache.json")
            
            # In-memory cache storage
            self._cache_data: Dict[str, Any] = {}
            
            # Create cache directory if it doesn't exist
            os.makedirs(cache_dir, exist_ok=True)
            
            # Load existing cache from disk to memory
            self._load_cache_from_disk()
            
            self._initialized = True
            logger.info(f"Cache service initialized with cache_dir: {cache_dir}")
        else:
            logger.debug("Cache service already initialized, reusing existing instance")
    
    def _generate_cache_key(self, request: ChatRequest) -> str:
        """
        Generate a unique cache key for the request
        
        Args:
            request: ChatRequest object
            
        Returns:
            Hash string to use as cache key
        """
        # Create a string representation of the request parameters
        request_str = f"{request.question.lower().strip()}"
        
        # Generate SHA-256 hash
        return hashlib.sha256(request_str.encode('utf-8')).hexdigest()
    
    def _load_cache_from_disk(self) -> None:
        """Load cache from JSON file to memory"""
        try:
            if os.path.exists(self.cache_file):
                with open(self.cache_file, 'r', encoding='utf-8') as f:
                    self._cache_data = json.load(f)
                logger.info(f"Loaded {len(self._cache_data)} cache entries from disk")
            else:
                self._cache_data = {}
                logger.info("No existing cache file found, starting with empty cache")
        except (FileNotFoundError, json.JSONDecodeError) as e:
            logger.warning(f"Failed to load cache from disk: {e}, starting with empty cache")
            self._cache_data = {}
    
    def _save_cache_to_disk(self) -> None:
        """Save in-memory cache to JSON file"""
        try:
            with open(self.cache_file, 'w', encoding='utf-8') as f:
                json.dump(self._cache_data, f, indent=2, ensure_ascii=False)
            logger.debug(f"Persisted {len(self._cache_data)} cache entries to disk")
        except Exception as e:
            logger.error(f"Failed to save cache to disk: {e}")
    
    def get_cached_response(self, request: ChatRequest) -> Optional[ChatResponse]:
        """
        Get cached response for a question if it exists
        
        Args:
            request: ChatRequest object
            
        Returns:
            ChatResponse if found, None otherwise
        """
        cache_key = self._generate_cache_key(request)
        
        if cache_key not in self._cache_data:
            return None
        
        cached_item = self._cache_data[cache_key]
        
        # Convert cached data back to ChatResponse
        try:
            response = ChatResponse(**cached_item['response'])
            logger.info(f"Cache hit for key: {cache_key[:8]}...")
            return response
        except Exception as e:
            logger.error(f"Failed to deserialize cached response: {e}")
            # Remove invalid entry
            del self._cache_data[cache_key]
            return None
    
    def cache_response(self, request: ChatRequest, response: ChatResponse) -> None:
        """
        Cache a question-answer pair
        
        Args:
            request: ChatRequest object
            response: ChatResponse object
        """
        # Only cache successful responses
        if not response.success:
            return
        
        cache_key = self._generate_cache_key(request)
        
        # Store response data in memory
        self._cache_data[cache_key] = {
            'response': response.model_dump()
        }
        
        # Save to disk immediately
        self._save_cache_to_disk()
        
        logger.info(f"Cached response for key: {cache_key[:8]}...")
    
    def clear_cache(self) -> None:
        """Clear all cached entries"""
        self._cache_data.clear()
        self._save_cache_to_disk()
        logger.info("Cache cleared")
    
    def reload_cache(self) -> None:
        """Reload cache from disk"""
        self._load_cache_from_disk()
        logger.info("Cache reloaded from disk")
    
    @classmethod
    def get_instance(cls, cache_dir: str = "cache") -> 'CacheService':
        """Get the singleton instance of CacheService"""
        return cls(cache_dir)
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """
        Get cache statistics
        
        Returns:
            Dictionary with cache statistics
        """
        total_entries = len(self._cache_data)
        
        return {
            'total_entries': total_entries,
            'cache_file_size': os.path.getsize(self.cache_file) if os.path.exists(self.cache_file) else 0,
            'is_empty': total_entries == 0
        }
    