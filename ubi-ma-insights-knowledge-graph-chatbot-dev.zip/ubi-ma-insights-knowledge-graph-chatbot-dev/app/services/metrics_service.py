class MetricsService:
    total_accuracy = 150000
    total_response_time = 42000
    total_llm_calls = 6000
    total_token_input = 250000
    total_token_output = 120000
    total_cost = 248

    api_response_time_total = 12000
    api_response_count = 1500

    @classmethod
    def update_metrics(cls, accuracy, response_time, token_input, token_output):
        # Ensure all values are numeric, defaulting to 0 if not
        try:
            if accuracy is not None:
                cls.total_accuracy += float(accuracy)
        except Exception:
            pass
        try:
            if response_time is not None:
                cls.total_response_time += float(response_time)
        except Exception:
            pass
        cls.total_llm_calls += 1
        try:
            if token_input is not None:
                cls.total_token_input += int(token_input)
        except Exception:
            pass
        try:
            if token_output is not None:
                cls.total_token_output += int(token_output)
        except Exception:
            pass
        # Update total cost
        try:
            input_tokens = int(token_input) if token_input is not None else 0
            output_tokens = int(token_output) if token_output is not None else 0
            if input_tokens > 0 and output_tokens > 0:
                cls.total_cost += (input_tokens / 1000) * 0.01 + (output_tokens / 1000) * 0.03
        except Exception:
            pass

    @classmethod
    def update_api_response_time(cls, response_time):
        try:
            if response_time is not None:
                cls.api_response_time_total += float(response_time)
                cls.api_response_count += 1
        except Exception:
            pass

    @classmethod
    def get_average_accuracy(cls):
        if cls.api_response_count == 0 or cls.total_accuracy == 0:
            return 0.0
        return cls.total_accuracy / cls.api_response_count

    @classmethod
    def get_average_response_time(cls):
        if cls.total_llm_calls == 0:
            return 0.0
        return cls.total_response_time / cls.total_llm_calls

    @classmethod
    def get_total_llm_calls(cls):
        return cls.total_llm_calls

    @classmethod
    def get_total_token_input(cls):
        return cls.total_token_input

    @classmethod
    def get_total_token_output(cls):
        return cls.total_token_output

    @classmethod
    def get_total_cost(cls):
        return cls.total_cost 

    @classmethod
    def get_average_api_response_time(cls):
        if cls.api_response_count == 0:
            return 0.0
        return cls.api_response_time_total / cls.api_response_count 