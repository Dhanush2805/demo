import os
import json
import pandas as pd
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
from typing import List, Dict, Any
from app.core.logger import get_logger
from app.core.models import VectorSearchResult
from app.services.config_service import config

logger = get_logger('vector_service')

class VectorService:
    """
    Vector database service for creating and searching embeddings
    Adapted from the existing VectorDatabaseManager
    """
    
    def __init__(self):
        """Initialize vector service with configuration"""
        logger.info("Initializing Vector Service")
        
        self.vector_db_folder = config.vector.vector_db_folder
        self.model_name = config.vector.model_name
        self.embedding_model = None
        self.index = None
        self.chunks_metadata = []
        
        # File paths for persistence
        self.index_file = os.path.join(self.vector_db_folder, "faiss_index.bin")
        self.metadata_file = os.path.join(self.vector_db_folder, "chunks_metadata.json")
        self.embeddings_file = os.path.join(self.vector_db_folder, "embeddings.npy")
        
        self._initialize_model()
        logger.info("Vector Service initialized successfully")
    
    def _initialize_model(self):
        """Initialize the sentence transformer model"""
        try:
            logger.info(f"Loading embedding model: {self.model_name}")
            self.embedding_model = SentenceTransformer(self.model_name)
            logger.info(f"Embedding model loaded successfully: {self.model_name}")
        except Exception as e:
            logger.error(f"Failed to load embedding model: {str(e)}")
            raise Exception(f"Failed to load embedding model: {str(e)}")
    
    def create_csv_vectors(self, csv_files: List[str]) -> Dict[str, int]:
        """
        Create vector embeddings for CSV files
        Args:
            csv_files: List of CSV file paths
        Returns:
            Dictionary with creation statistics
        """
        logger.info(f"Creating vectors for {len(csv_files)} CSV files")
        
        chunks = []
        total_rows = 0
        
        for csv_file in csv_files:
            try:
                logger.info(f"Processing CSV file: {csv_file}")
                
                # Load the CSV data
                df = pd.read_csv(csv_file)
                logger.info(f"Loaded CSV with {len(df)} rows and {len(df.columns)} columns")
                
                # Create a chunk for each row
                for row_index, row in df.iterrows():
                    # Create content by combining all column values for this row
                    row_content_parts = []
                    row_metadata = {}
                    
                    for column_name, value in row.items():
                        if pd.notna(value):  # Only include non-null values
                            row_content_parts.append(f"{column_name}: {str(value)}")
                            row_metadata[column_name] = str(value)
                    
                    if row_content_parts:  # Only create chunk if row has values
                        content = f"Row {row_index + 1} from {os.path.basename(csv_file)}:\n"
                        content += "\n".join(row_content_parts)
                        
                        chunks.append({
                            'source': os.path.basename(csv_file),
                            'chunk_id': f"{os.path.basename(csv_file)}_row_{row_index}",
                            'chunk_type': 'csv_row',
                            'content': content,
                            'metadata': {
                                'file_type': 'csv',
                                'row_index': row_index,
                                'total_columns': len(df.columns),
                                'non_null_columns': len(row_content_parts),
                                'row_data': row_metadata
                            }
                        })
                        total_rows += 1
                
                logger.info(f"Created {total_rows} chunks from {csv_file}")
                
            except Exception as e:
                logger.error(f"Error processing CSV {csv_file}: {str(e)}")
                continue
        
        if not chunks:
            logger.error("No chunks created from CSV files")
            raise Exception("No chunks found in the CSV files")
        
        logger.info(f"Total chunks created: {len(chunks)}")
        
        # Create embeddings and index
        return self._create_embeddings_and_index(chunks)
    
    def _create_embeddings_and_index(self, chunks: List[Dict[str, Any]]) -> Dict[str, int]:
        """Create embeddings for chunks and build FAISS index"""
        logger.info(f"Creating embeddings for {len(chunks)} chunks")
        
        # Extract content for embedding
        texts = [chunk['content'] for chunk in chunks]
        
        # Create embeddings
        logger.info("Generating embeddings using sentence transformer")
        embeddings = self.embedding_model.encode(texts, show_progress_bar=False)
        embeddings = np.array(embeddings).astype('float32')
        logger.info(f"Generated embeddings with shape: {embeddings.shape}")
        
        # Create FAISS index
        dimension = embeddings.shape[1]
        self.index = faiss.IndexFlatIP(dimension)  # Inner product (cosine similarity)
        
        # Normalize embeddings for cosine similarity
        faiss.normalize_L2(embeddings)
        logger.info("Normalized embeddings for cosine similarity")
        
        # Add embeddings to index
        self.index.add(embeddings)
        logger.info(f"Added {embeddings.shape[0]} embeddings to FAISS index")
        
        # Store metadata
        self.chunks_metadata = chunks
        
        # Save to disk
        self._save_index_and_metadata(embeddings)
        
        logger.info(f"Vector database created successfully with {len(chunks)} chunks")
        
        return {
            'total_chunks': len(chunks),
            'embedding_dimension': dimension,
            'index_size': self.index.ntotal
        }
    
    def _save_index_and_metadata(self, embeddings: np.ndarray):
        """Save FAISS index and metadata to disk"""
        try:
            logger.info("Saving vector database to disk")
            
            # Save FAISS index
            faiss.write_index(self.index, self.index_file)
            logger.info(f"FAISS index saved to: {self.index_file}")
            
            # Save metadata
            with open(self.metadata_file, 'w', encoding='utf-8') as f:
                json.dump(self.chunks_metadata, f, indent=2, ensure_ascii=False)
            logger.info(f"Metadata saved to: {self.metadata_file}")
            
            # Save embeddings
            np.save(self.embeddings_file, embeddings)
            logger.info(f"Embeddings saved to: {self.embeddings_file}")
            
            logger.info("Vector database saved successfully")
        except Exception as e:
            logger.error(f"Error saving vector database: {str(e)}")
            raise
    
    def load_index_and_metadata(self) -> bool:
        """Load FAISS index and metadata from disk"""
        try:
            if not all(os.path.exists(f) for f in [self.index_file, self.metadata_file]):
                logger.warning("Vector database files not found")
                return False
            
            logger.info("Loading vector database from disk")
            
            # Load FAISS index
            self.index = faiss.read_index(self.index_file)
            logger.info(f"FAISS index loaded from: {self.index_file}")
            
            # Load metadata
            with open(self.metadata_file, 'r', encoding='utf-8') as f:
                self.chunks_metadata = json.load(f)
            logger.info(f"Metadata loaded from: {self.metadata_file}")
            
            logger.info(f"Vector database loaded with {len(self.chunks_metadata)} chunks")
            return True
        except Exception as e:
            logger.error(f"Error loading vector database: {str(e)}")
            return False
    
    def similarity_search(self, query: str, top_k: int = 5) -> List[VectorSearchResult]:
        """Find similar chunks based on query"""
        logger.info(f"VECTOR SEARCH START: query='{query}', top_k={top_k}")
        
        if self.index is None or not self.chunks_metadata:
            logger.info("Vector index not loaded, attempting to load from disk")
            # Try to load from disk
            if not self.load_index_and_metadata():
                logger.error("No vector database found")
                raise Exception("No vector database found. Please create embeddings first.")
        
        logger.info(f"Vector database loaded: {len(self.chunks_metadata)} chunks available")
        
        # Create query embedding
        logger.info("Creating query embedding...")
        query_embedding = self.embedding_model.encode([query])
        query_embedding = np.array(query_embedding).astype('float32')
        logger.info(f"Query embedding shape: {query_embedding.shape}")
        
        # Normalize for cosine similarity
        faiss.normalize_L2(query_embedding)
        logger.info("Query embedding normalized")
        
        # Search
        logger.info(f"Searching FAISS index with {self.index.ntotal} vectors...")
        scores, indices = self.index.search(query_embedding, top_k)
        logger.info(f"FAISS search completed. Scores: {scores[0]}, Indices: {indices[0]}")
        
        # Prepare results
        results = []
        for i, (score, idx) in enumerate(zip(scores[0], indices[0])):
            if idx < len(self.chunks_metadata):
                chunk = self.chunks_metadata[idx].copy()
                chunk['similarity_score'] = float(score)
                chunk['rank'] = i + 1
                results.append(chunk)
                logger.info(f"Result {i+1}: score={score:.4f}, source={chunk.get('source')}, type={chunk.get('chunk_type')}")
        
        logger.info(f"VECTOR SEARCH COMPLETE: {len(results)} results returned")
        return results
    
    def similarity_search_by_source(self, query: str, source_filename: str, top_k: int = 5) -> List[VectorSearchResult]:
        """Find similar chunks based on query filtered by source filename"""
        logger.info(f"VECTOR SEARCH BY SOURCE START: query='{query}', source='{source_filename}', top_k={top_k}")
        
        if self.index is None or not self.chunks_metadata:
            logger.info("Vector index not loaded, attempting to load from disk")
            if not self.load_index_and_metadata():
                logger.error("No vector database found")
                raise Exception("No vector database found. Please create embeddings first.")
        
        # Filter chunks by source filename first
        source_chunks = []
        source_indices = []
        for i, chunk in enumerate(self.chunks_metadata):
            if chunk.get('source') == source_filename:
                source_chunks.append(chunk)
                source_indices.append(i)
        
        if not source_chunks:
            logger.warning(f"No chunks found for source file: {source_filename}")
            return []
        
        logger.info(f"Found {len(source_chunks)} chunks for source file: {source_filename}")
        
        # Create query embedding
        query_embedding = self.embedding_model.encode([query])
        query_embedding = np.array(query_embedding).astype('float32')
        faiss.normalize_L2(query_embedding)
        
        scores, indices = self.index.search(query_embedding, min(top_k * 10, self.index.ntotal))
        
        results = []
        found_count = 0
        for i, (score, idx) in enumerate(zip(scores[0], indices[0])):
            if idx < len(self.chunks_metadata):
                chunk = self.chunks_metadata[idx]
                if chunk.get('source') == source_filename:
                    result_chunk = chunk.copy()
                    result_chunk['similarity_score'] = float(score)
                    result_chunk['rank'] = found_count + 1
                    results.append(result_chunk)
                    found_count += 1
                    logger.info(f"Result {found_count}: score={score:.4f}, source={chunk.get('source')}")
                    
                    if found_count >= top_k:
                        break
        
        logger.info(f"VECTOR SEARCH BY SOURCE COMPLETE: {len(results)} results returned for {source_filename}")
        return results
    
    def append_chunks_to_index(self, new_chunks: List[Dict[str, Any]]) -> Dict[str, int]:
        """
        Add new chunks to existing vector database without replacing existing data
        Useful for adding PDF chunks to existing CSV vector database
        
        Args:
            new_chunks: List of chunk dictionaries to add
            
        Returns:
            Dictionary with statistics about chunks added
        """
        logger.info(f"Appending {len(new_chunks)} new chunks to existing vector database")
        
        try:
            if self.index is None or not self.chunks_metadata:
                logger.info("Loading existing vector database")
                self.load_index_and_metadata()
            
            # If no existing index, create new one
            if self.index is None:
                logger.info("No existing vector database found, creating new one")
                return self._create_embeddings_and_index(new_chunks)
            
            # Extract content for embedding
            texts = [chunk['content'] for chunk in new_chunks]
            
            # Create embeddings for new chunks
            logger.info("Generating embeddings for new chunks")
            new_embeddings = self.embedding_model.encode(texts, show_progress_bar=False)
            new_embeddings = np.array(new_embeddings).astype('float32')
            logger.info(f"Generated {new_embeddings.shape[0]} new embeddings with shape: {new_embeddings.shape}")
            
            # Normalize new embeddings
            faiss.normalize_L2(new_embeddings)
            logger.info("Normalized new embeddings for cosine similarity")
            
            # Add new embeddings to existing index
            self.index.add(new_embeddings)
            logger.info(f"Added {new_embeddings.shape[0]} new embeddings to FAISS index")
            
            # Append new chunks to metadata
            self.chunks_metadata.extend(new_chunks)
            logger.info(f"Updated metadata: now contains {len(self.chunks_metadata)} total chunks")
            
            # Load existing embeddings and combine with new ones
            try:
                existing_embeddings = np.load(self.embeddings_file)
                combined_embeddings = np.vstack([existing_embeddings, new_embeddings])
                logger.info(f"Combined embeddings shape: {combined_embeddings.shape}")
            except Exception as e:
                logger.warning(f"Could not load existing embeddings: {str(e)}")
                combined_embeddings = new_embeddings
            
            # Save updated index and metadata
            self._save_index_and_metadata(combined_embeddings)
            
            logger.info(f"Successfully appended {len(new_chunks)} chunks to vector database")
            
            return {
                'chunks_added': len(new_chunks),
                'total_chunks': len(self.chunks_metadata),
                'embedding_dimension': new_embeddings.shape[1],
                'index_size': self.index.ntotal
            }
            
        except Exception as e:
            logger.error(f"Error appending chunks to vector database: {str(e)}")
            raise Exception(f"Failed to append chunks: {str(e)}")

    
    def clear_database(self):
        """Clear the vector database"""
        logger.info("Clearing vector database")
        
        self.index = None
        self.chunks_metadata = []
        
        # Remove files
        for file_path in [self.index_file, self.metadata_file, self.embeddings_file]:
            if os.path.exists(file_path):
                os.remove(file_path)
                logger.info(f"Removed file: {file_path}")
        
        logger.info("Vector database cleared successfully") 