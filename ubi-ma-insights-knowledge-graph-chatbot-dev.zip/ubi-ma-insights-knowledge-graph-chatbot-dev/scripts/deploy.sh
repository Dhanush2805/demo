#!/bin/bash

# Exit on any error
set -e

# CONFIGURATION
BACKEND_REPO_DIR="/home/ubuntu/ubi-ma-insights/ubi-ma-insights-knowledge-graph-chatbot"

BACKEND_CONTAINER="ubi-ma-insights-knowledge-graph-chatbot"

BACKEND_PORT=8001

# === BACKEND DEPLOYMENT ===
echo "---- BACKEND DEPLOYMENT ----"
cd "${BACKEND_REPO_DIR}" || { echo "Backend directory not found"; exit 1; }

echo "Pulling latest backend code..."
git checkout dev
git pull origin dev || { echo "Failed to pull latest code"; exit 1; }

echo "Building backend Docker image..."
docker build -t "${BACKEND_CONTAINER}:latest" .

echo "Stopping old backend container..."
docker stop "${BACKEND_CONTAINER}" || echo "No existing backend container"

echo "Removing old backend container..."
docker rm "${BACKEND_CONTAINER}" || echo "No existing backend container"

echo "Running new backend container on port ${BACKEND_PORT}..."
docker run -d --name "${BACKEND_CONTAINER}" --restart always -p ${BACKEND_PORT}:8000 "${BACKEND_CONTAINER}:latest"

# === VERIFICATION ===
sleep 2

for container in $BACKEND_CONTAINER; do
  if [ "$(docker ps -q -f name=${container})" ]; then
    echo "${container} started successfully ✅"
  else
    echo "ERROR: ${container} failed to start. Check logs: docker logs ${container}"
    exit 1
  fi
done

echo "✅ Deployment completed successfully"
exit 0
